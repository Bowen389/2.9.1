/* Market Lens Buy — pure helpers for 今日买点 / 单品买点结论 / 我的持仓 (Lab 2.6).
   No DOM, no network. Turns the cross-sectional selection score into a plain
   buy-point recommendation:
     买点 = 选品分 ≥ P80（在可交易、符合筛选规则的商品里排前 20%）
     + 大盘不在显著弱势（否则只作观察名单）
     + 信号新鲜（信号在出现后 1–2 天最强，过期要重扫）
   The underlying model ranks items against each other; it does not predict
   absolute prices. Everything here is a research aid, not a trade signal. */
(function (root) {
  'use strict';
  const VERSION = 'buy-1.0.2';
  const DAY = 86400000;
  const DEFAULTS = {
    minPct: 80,        // 买点：选品分 ≥ P80
    watchPct: 60,      // 观察：P60–80
    avoidPct: 40,      // P40 以下：不建议
    tol: 0.02,         // 买入价上限 = 最近悠悠收盘 × (1 + tol)，避免追高
    validDays: 2,      // 信号日（最近收盘日）之后 2 天内有效
    cooldownDays: 7,   // CS2 饰品交易后通常约 7 天冷却，期间无法卖出
  };
  const isNum = v => typeof v === 'number' && Number.isFinite(v);
  const round2 = v => Math.round(v * 100) / 100;

  // Beijing calendar day of a timestamp (the site and the K bars use Beijing days).
  function bjDay(now) { return new Date((isNum(now) ? now : Date.now()) + 8 * 3600000).toISOString().slice(0, 10); }
  function addDays(day, n) { return new Date(Date.parse(day + 'T00:00:00Z') + n * DAY).toISOString().slice(0, 10); }
  function daysBetween(a, b) { return Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / DAY); }

  function fresh(day, today, validDays = 2) {
    const valid = d => typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d + 'T00:00:00Z')) && new Date(d + 'T00:00:00Z').toISOString().slice(0, 10) === d;
    if (!valid(day) || !valid(today)) return false;
    const age = daysBetween(day, today);
    return age >= 0 && age <= validDays;
  }

  // rows: scan rows after applyCross (sel7/sel14/sel30 percentiles, why7/…, close, price).
  // o: { h, signalDay, today, regime: {score,label}|null, gate, topN, minPct, tol, validDays }
  function recommend(rows, opts) {
    const o = Object.assign({}, DEFAULTS, { topN: 10 }, opts || {});
    const key = 'sel' + o.h;
    const ranked = (rows || []).filter(r => r && isNum(r[key]) && r.day === o.signalDay && fresh(r.day, o.today, o.validDays)).sort((a, b) => b[key] - a[key]);
    const picks = ranked.filter(r => r[key] >= o.minPct).map((r, i) => {
      const close = isNum(r.close) ? r.close : isNum(r.price) ? r.price : null;
      return {
        id: String(r.id), name: r.name, url: r.url, family: r.family, pct: r[key], close,
        limit: close ? round2(close * (1 + o.tol)) : null,
        why: (r['why' + o.h] || []).slice(0, 3), top: i < o.topN,
      };
    });
    const age = o.signalDay && o.today ? daysBetween(o.signalDay, o.today) : Infinity;
    const gateOn = !!(o.regime && isNum(o.regime.score) && o.regime.score < o.gate);
    return {
      h: o.h, signalDay: o.signalDay || null, today: o.today, ranked: ranked.length, picks,
      nTop: picks.filter(p => p.top).length, age, stale: !fresh(o.signalDay, o.today, o.validDays),
      unknown: !(o.regime && isNum(o.regime.score)),
      blocked: !fresh(o.signalDay, o.today, o.validDays) || !(o.regime && isNum(o.regime.score)) || gateOn || o.complete === false || ranked.length < 30,
      validTo: fresh(o.signalDay, o.signalDay, 0) ? addDays(o.signalDay, o.validDays) : null,
      holdTo: fresh(o.today, o.today, 0) && [7,14,30].includes(o.h) ? addDays(o.today, o.h) : null,
      gateOn, regime: o.regime || null, tooFew: ranked.length < 30,
    };
  }

  // Single-item verdict. o: { ok, reason, pct, tradable, ruleOk, ruleText, regime, gate, h, close, tol }
  function verdict(opts) {
    const o = Object.assign({}, DEFAULTS, opts || {});
    const mk = (level, title, text) => ({
      level, title, text, buy: level === 'yes' || level === 'wait',
      limit: isNum(o.close) ? round2(o.close * (1 + o.tol)) : null,
    });
    if (!o.ok) return mk('na', '无法判断', o.reason || '数据不足');
    if (!fresh(o.signalDay, o.today, o.validDays)) return mk('na', '信号过期或日期无效', '请刷新到有效收盘日后再判断。');
    if (!isNum(o.coverage) || o.coverage < 0.9) return mk('na', '因子数据不足', '有效因子权重覆盖率不足90%，仅供观察。');
    if (!(o.regime && isNum(o.regime.score))) return mk('na', '大盘数据不可用', '风险状态未知，暂不给出可买结论。');
    if (o.referenceOk === false) return mk('na', '参考截面过期或规则不匹配', '请完成一次同规则扫描后再判断。');
    if (!o.ruleOk) return mk('no', '不在你的筛选范围', (o.ruleText || '') + '。模型没有在这类商品上验证过，不给买点。');
    if (!o.tradable) return mk('no', '成交太少，不建议', '近 30 天成交偏少，买了可能不好卖；模型也没有在这类商品上训练。');
    if (!isNum(o.pct)) return mk('na', '无法判断', '没有可用的参考截面');
    const gateOn = !!(o.regime && isNum(o.regime.score) && o.regime.score < o.gate);
    if (o.pct >= o.minPct) {
      return gateOn
        ? mk('wait', '符合买点，但大盘弱势', '选品分 P' + Math.round(o.pct) + '，排在前 20%；但大盘分 ' + Math.round(o.regime.score) + ' 低于闸门 ' + o.gate + '，建议暂缓或减小仓位。')
        : mk('yes', '符合买点', '选品分 P' + Math.round(o.pct) + '，在同类里排前 20%。建议持有约 ' + o.h + ' 天，并和其它买点一起分散买。');
    }
    if (o.pct >= o.watchPct) return mk('watch', '接近买点，观望', '选品分 P' + Math.round(o.pct) + '，还没进前 20%。可以先放进观察名单。');
    if (o.pct >= o.avoidPct) return mk('watch', '一般，不是好买点', '选品分 P' + Math.round(o.pct) + '，排在中间。');
    return mk('no', '不建议现在买', '选品分 P' + Math.round(o.pct) + '，排名靠后（后 40%）。历史上这一档跑输的次数更多。');
  }

  // One holding -> display state. fee = round-trip cost charged on the sale.
  function holdingState(h, cur, today, opts) {
    const o = Object.assign({}, DEFAULTS, { fee: 0.01 }, opts || {});
    const qty = isNum(Number(h.qty)) && Number(h.qty) > 0 ? Number(h.qty) : 1;
    const buy = Number(h.buyPrice);
    const buyFee=isNum(h.buyFee)?h.buyFee:0;
    const out = { qty, buy, buyFee, cur: isNum(cur) ? cur : null, cost: isNum(buy) ? buy * qty+buyFee : null };
    if (h.status === 'sold') {
      const sp = Number(h.sellPrice);
      out.status = 'sold'; out.label = '已卖出';
      out.sellFeeEstimated=!isNum(h.sellFee);out.sellFee=out.sellFeeEstimated?qty*sp*o.fee:h.sellFee;
      out.pnl = isNum(sp) && isNum(buy) ? qty * sp-out.sellFee-out.cost : null;
      out.pnlPct = out.cost>0&&isNum(out.pnl) ? out.pnl/out.cost : null;
      out.heldDays = h.buyDay && h.sellDay ? daysBetween(h.buyDay, h.sellDay) : null;
      return out;
    }
    const held = h.buyDay ? daysBetween(h.buyDay, today) : 0;
    const left = h.sellBy ? daysBetween(today, h.sellBy) : null;
    out.heldDays = held; out.daysLeft = left;
    out.value = out.cur !== null ? out.cur * qty : null;
    out.pnl = out.cur !== null && isNum(buy) ? qty*out.cur*(1-o.fee)-out.cost : null;
    out.pnlPct = out.cost>0&&isNum(out.pnl) ? out.pnl/out.cost : null;
    if (left !== null && left <= 0) { out.status = 'due'; out.label = '已到期，建议卖出'; }
    else if (held < o.cooldownDays) { out.status = 'lock'; out.label = '冷却期，约 ' + (o.cooldownDays - held) + ' 天后可卖'; }
    else { out.status = 'open'; out.label = '持有中' + (left !== null ? '，剩 ' + left + ' 天' : ''); }
    return out;
  }

  function summarizeHoldings(list, prices, today, opts) {
    const s = { open: 0, due: 0, sold: 0, cost: 0, value: 0, pnl: 0, priced: 0, realized: 0, soldCost: 0 };
    for (const h of list || []) {
      const st = holdingState(h, prices ? prices[h.id] : null, today, opts);
      if (st.status === 'sold') { s.sold++; if (isNum(st.pnl)) { s.realized += st.pnl; s.soldCost += st.cost || 0; } continue; }
      s.open++; if (st.status === 'due') s.due++;
      if (isNum(st.cost)) s.cost += st.cost;
      if (isNum(st.pnl)) { s.priced++; s.value += st.value; s.pnl += st.pnl; }
    }
    s.pnlPct = s.cost > 0 && s.priced === s.open ? s.pnl / s.cost : null;
    s.realizedPct = s.soldCost > 0 ? s.realized / s.soldCost : null;
    return s;
  }

  const api = { VERSION, DEFAULTS, fresh, bjDay, addDays, daysBetween, recommend, verdict, holdingState, summarizeHoldings };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.MarketLensBuy = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
