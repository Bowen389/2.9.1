/* Experimental models never enter the formal registry. Fixed protocol, time purge,
   train-only transforms, validation-only tuning, untouched final test. No automatic promotion. */
(function (root) {
  "use strict";
  const F =
    root.MarketLensFactor ||
    (typeof require === "function" ? require("./factor-core.js") : null);
  const EX =
    root.MarketLensExecution ||
    (typeof require === "function" ? require("./execution-core.js") : null);
  const VERSION = "experiment-1.0",
    EXTRA = [
      "peer20",
      "peerBreadth",
      "flatRun",
      "jumpThin",
      "zeroVol",
      "liqDecay",
    ];
  const LABELS = {
    peer20: "同类20日相对动量",
    peerBreadth: "同类上涨宽度",
    flatRun: "连续不变价比例",
    jumpThin: "低量跳价占比",
    zeroVol: "30日零量比例",
    liqDecay: "近期量相对前期变化",
  };
  const finite = Number.isFinite,
    clip = (x, a, b) => Math.max(a, Math.min(b, x));
  const pause = async (signal) => {
    if (signal && signal.aborted)
      throw Object.assign(Error("实验已取消"), { name: "AbortError" });
    await new Promise((r) => setTimeout(r, 0));
  };
  function ownFeatures(s, i) {
    const r = [];
    for (let k = i - 59; k <= i; k++) r.push(Math.log(s.c[k] / s.c[k - 1]));
    const sigma = Math.max(0.004, F.std(r));
    const vols = Array.from(s.v.slice(i - 29, i + 1)),
      med = F.median(vols);
    let flat = 0,
      jumps = 0,
      zero = 0;
    for (let k = i; k > i - 30; k--) {
      if (s.c[k] === s.c[k - 1] && flat === i - k) flat++;
      if (s.v[k] === 0) zero++;
      if (
        Math.abs(Math.log(s.c[k] / s.c[k - 1])) > Math.max(0.05, 3 * sigma) &&
        s.v[k] < med * 0.5
      )
        jumps++;
    }
    return {
      ret20: Math.log(s.c[i] / s.c[i - 20]),
      sigma,
      flatRun: flat / 30,
      jumpThin: jumps / 30,
      zeroVol: zero / 30,
      liqDecay: Math.log(
        (F.median(Array.from(s.v.slice(i - 6, i + 1))) + 1) /
          (F.median(Array.from(s.v.slice(i - 36, i - 6))) + 1),
      ),
    };
  }
  function peerSet(rows) {
    const sorted = rows
      .slice()
      .sort((a, b) => a.f.ret20 - b.f.ret20 || a.id - b.id);
    return {
      sorted,
      index: new Map(sorted.map((r, i) => [r.id, i])),
      positive: sorted.filter((r) => r.f.ret20 > 0).length,
    };
  }
  function excluding(set, row) {
    const n = set.sorted.length - 1,
      at = set.index.get(row.id);
    if (n < 5 || at === undefined) return null;
    const val = (k) => set.sorted[k >= at ? k + 1 : k].f.ret20;
    const m = n >> 1;
    return {
      median: n % 2 ? val(m) : (val(m - 1) + val(m)) / 2,
      breadth: (set.positive - (row.f.ret20 > 0 ? 1 : 0)) / n - 0.5,
      n,
    };
  }
  async function augment(panel, signal, onProgress) {
    const keys = panel.keys.concat(
        EXTRA.filter((k) => !panel.keys.includes(k)),
      ),
      rows = panel.rows.map((r) => ({
        ...r,
        x: Float32Array.from(
          keys.map((k, i) => (i < panel.keys.length ? r.x[i] : NaN)),
        ),
      }));
    let fallback = 0,
      missing = 0;
    for (let di = 0; di < panel.days.length; di++) {
      const d = panel.days[di],
        members = (panel.byDay.get(d) || []).map((id) => {
          const row = rows[id],
            s = panel.sources[row.it],
            it = panel.items[row.it];
          return {
            id,
            row,
            f: ownFeatures(s, d - s.day0),
            family: EX.groupOf(it).family,
            kind: F.classifyName(it.name).kind,
          };
        });
      const build = (key) => {
        const m = new Map();
        for (const r of members) {
          const k = r[key];
          if (!m.has(k)) m.set(k, []);
          m.get(k).push(r);
        }
        return new Map(Array.from(m, ([k, a]) => [k, peerSet(a)]));
      };
      const families = build("family"),
        kinds = build("kind"),
        all = peerSet(members);
      for (const r of members) {
        let p = excluding(families.get(r.family), r);
        if (!p) {
          fallback++;
          p = excluding(kinds.get(r.kind), r) || excluding(all, r);
        }
        if (!p) missing++;
        const values = {
          ...r.f,
          peer20: p
            ? clip((r.f.ret20 - p.median) / (r.f.sigma * Math.sqrt(20)), -6, 6)
            : NaN,
          peerBreadth: p ? p.breadth : NaN,
        };
        for (const k of EXTRA) r.row.x[keys.indexOf(k)] = values[k];
      }
      if (di % 10 === 0) {
        if (onProgress) onProgress(di, panel.days.length);
        await pause(signal);
      }
    }
    return {
      ...panel,
      rows,
      keys,
      experimental: {
        version: VERSION,
        fallback,
        missing,
        peerMinimum: 5,
        peerDefinition:
          "武器/手套类别→类型→全池；排除自身，至少5个同伴；仅当日可见样本",
      },
    };
  }
  function splitDays(panel, h) {
    const dates = panel.days.filter(
        (d) => d + (panel.lag || 0) + h <= panel.asOf,
      ),
      v = dates[Math.floor(dates.length * 0.6)],
      t = dates[Math.floor(dates.length * 0.8)];
    const train = dates.filter((d) => d + h + (panel.lag || 0) < v),
      validation = dates.filter((d) => d >= v && d + h + (panel.lag || 0) < t),
      test = dates.filter((d) => d >= t);
    if (train.length < 45 || validation.length < 10 || test.length < 10)
      throw Error(
        "实验样本不足：隔离后至少45个训练日、10个验证日、10个测试日；请补充历史和商品。",
      );
    return {
      train,
      validation,
      test,
      purgeCalendarDays: h + (panel.lag || 0),
      protocol:
        "60/20/20 chronological anchors; label exit strictly before next window",
    };
  }
  function samplePanel(panel, days, h, cap = 128) {
    const byDay = new Map();
    for (const d of days) {
      const ids = (panel.byDay.get(d) || [])
        .filter((i) => finite(panel.rows[i].y[h]))
        .sort((a, b) =>
          String(panel.items[panel.rows[a].it].id).localeCompare(
            String(panel.items[panel.rows[b].it].id),
            "en",
          ),
        );
      const chosen =
        ids.length <= cap
          ? ids
          : Array.from(
              { length: cap },
              (_, i) => ids[Math.floor(((i + 0.5) * ids.length) / cap)],
            );
      if (chosen.length >= 20) byDay.set(d, chosen);
    }
    return { ...panel, byDay, days: days.filter((d) => byDay.has(d)) };
  }
  function transform(row, indices, stats) {
    return indices.map((i, k) =>
      finite(row.x[i])
        ? clip(
            (clip(row.x[i], stats[k].lo, stats[k].hi) - stats[k].mu) /
              stats[k].sd,
            -4,
            4,
          )
        : 0,
    );
  }
  function dataset(panel, days, h, keys, stats) {
    const indices = keys.map((k) => panel.keys.indexOf(k)),
      data = [];
    for (const d of days) {
      const ids = panel.byDay.get(d) || [];
      if (ids.length < 20) continue;
      const y = F.gaussRank(ids.map((i) => panel.rows[i].y[h]));
      for (let i = 0; i < ids.length; i++)
        data.push({
          x: transform(panel.rows[ids[i]], indices, stats),
          y: y[i],
          w: 1 / ids.length,
          d,
        });
    }
    return data;
  }
  function ridgeFit(data, keys, stats, lambda) {
    const K = keys.length,
      A = Array.from({ length: K }, () => new Float64Array(K)),
      b = new Float64Array(K);
    let W = 0;
    const byDay = new Map();
    for (const r of data) {
      if (!byDay.has(r.d)) byDay.set(r.d, []);
      byDay.get(r.d).push(r);
    }
    for (const group of byDay.values()) {
      const means = keys.map((_, i) => F.mean(group.map((r) => r.x[i])));
      for (const r of group) {
        W += r.w;
        for (let i = 0; i < K; i++) {
          const a = r.x[i] - means[i];
          b[i] += r.w * a * r.y;
          for (let j = 0; j < K; j++) A[i][j] += r.w * a * (r.x[j] - means[j]);
        }
      }
    }
    const coef = F.ridge({ XtX: A, Xty: b, n: W }, lambda);
    if (!coef) throw Error("实验岭回归求解失败");
    return { kind: "ridge", keys, stats, coef: Array.from(coef), lambda };
  }
  function treePredict(tree, x) {
    let node = tree;
    while (node.feature !== undefined)
      node = x[node.feature] <= node.threshold ? node.left : node.right;
    return node.value;
  }
  const CUTS = [-1.5, -1, -0.5, 0, 0.5, 1, 1.5];
  function fitTree(data, residual, ids, depth, minLeaf) {
    let weight = 0,
      sum = 0;
    for (const i of ids) {
      weight += data[i].w;
      sum += data[i].w * residual[i];
    }
    const leaf = { value: weight ? sum / weight : 0 };
    if (depth === 0 || ids.length < 2 * minLeaf) return leaf;
    let best = null;
    for (let k = 0; k < data[0].x.length; k++) {
      const c = new Float64Array(8),
        w = new Float64Array(8),
        y = new Float64Array(8);
      for (const i of ids) {
        let bin = 0;
        while (bin < 7 && data[i].x[k] > CUTS[bin]) bin++;
        c[bin]++;
        w[bin] += data[i].w;
        y[bin] += data[i].w * residual[i];
      }
      let lc = 0,
        lw = 0,
        ly = 0;
      for (let j = 0; j < 7; j++) {
        lc += c[j];
        lw += w[j];
        ly += y[j];
        if (
          lc < minLeaf ||
          ids.length - lc < minLeaf ||
          lw <= 0 ||
          weight - lw <= 0
        )
          continue;
        const gain =
          (ly * ly) / lw +
          ((sum - ly) * (sum - ly)) / (weight - lw) -
          (sum * sum) / weight;
        if (gain > 1e-8 && (!best || gain > best.gain))
          best = { feature: k, threshold: CUTS[j], gain };
      }
    }
    if (!best) return leaf;
    const l = [],
      r = [];
    for (const i of ids)
      (data[i].x[best.feature] <= best.threshold ? l : r).push(i);
    return {
      feature: best.feature,
      threshold: best.threshold,
      left: fitTree(data, residual, l, depth - 1, minLeaf),
      right: fitTree(data, residual, r, depth - 1, minLeaf),
    };
  }
  function scorer(panel, model) {
    if (model.kind === "builtin") return F.modelScorer(panel, model.model);
    const indices = model.keys.map((k) => panel.keys.indexOf(k));
    return (row) => {
      const x = transform(row, indices, model.stats);
      if (model.kind === "ridge")
        return model.coef.reduce((v, w, i) => v + w * x[i], 0);
      return model.trees.reduce(
        (v, t) => v + model.rate * treePredict(t, x),
        0,
      );
    };
  }
  async function fitBoost(train, val, keys, stats, signal, onProgress) {
    const trees = [],
      pred = new Float64Array(train.length),
      vpred = new Float64Array(val.length),
      ids = train.map((_, i) => i);
    let bestLoss = Infinity,
      bestN = 1;
    const rate = 0.05,
      minLeaf = Math.max(40, Math.floor(train.length * 0.02));
    for (let n = 0; n < 30; n++) {
      const residual = train.map((r, i) => r.y - pred[i]),
        tree = fitTree(train, residual, ids, 2, minLeaf);
      trees.push(tree);
      for (let i = 0; i < train.length; i++)
        pred[i] += rate * treePredict(tree, train[i].x);
      let loss = 0,
        weight = 0;
      for (let i = 0; i < val.length; i++) {
        vpred[i] += rate * treePredict(tree, val[i].x);
        loss += val[i].w * (val[i].y - vpred[i]) ** 2;
        weight += val[i].w;
      }
      loss /= weight;
      if (loss < bestLoss) {
        bestLoss = loss;
        bestN = n + 1;
      }
      if (onProgress) onProgress(n + 1, 30);
      await pause(signal);
    }
    return {
      kind: "boosted-depth2",
      keys,
      stats,
      rate,
      trees: trees.slice(0, bestN),
      validationLoss: bestLoss,
      minLeaf,
      maxTrees: 30,
      selectedTrees: bestN,
    };
  }
  async function hash(value) {
    const text = JSON.stringify(value),
      crypto =
        root.crypto ||
        (typeof require === "function"
          ? require("node:crypto").webcrypto
          : null);
    const bytes = new TextEncoder().encode(text);
    return Array.from(
      new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)),
      (b) => b.toString(16).padStart(2, "0"),
    ).join("");
  }
  function evaluate(panel, model, days, h, options) {
    const fn = scorer(panel, model),
      ic = F.crossIC(panel, fn, h, { days, minN: 20 });
    const metrics = {};
    for (const fee of [0.01, 0.03]) {
      const result = EX.simulate(panel, fn, {
        days,
        h,
        topN: options.topN || 10,
        minN: 20,
        cost: fee,
        buySlip: 0.003,
        sellSlip: 0.003,
        maxFamilyWeight: 0.3,
        maxSeriesWeight: 0.1,
      });
      const gains = result.positions
          .filter((p) => finite(p.ret) && p.ret > 0)
          .map((p) => p.amt * p.ret)
          .sort((a, b) => b - a),
        positive = gains.reduce((a, b) => a + b, 0);
      metrics[fee === 0.01 ? "base" : "stress"] = {
        positiveProfitTop3Share: positive
          ? gains.slice(0, 3).reduce((a, b) => a + b, 0) / positive
          : null,
        meanCashWeight: result.detail.length
          ? F.mean(result.detail.map((p) => p.cashWeight))
          : null,
        top: result.top,
        universe: result.universe,
        periods: result.periods,
        audit: result.audit,
        curve: result.curve,
        detail: result.detail,
        positions: result.positions,
      };
    }
    return {
      ic: {
        mean: ic.mean,
        t: ic.t,
        n: ic.n,
        nonOverlap: ic.nonOverlap,
        byYear: ic.byYear,
        ci: F.bootstrapMeanCI(
          ic.series.map((x) => x.ic),
          Math.max(1, Math.ceil(h / panel.step)),
          500,
        ),
      },
      ...metrics,
    };
  }
  async function run(panel, builtin, baseKeys, opts) {
    const o = Object.assign({ h: 30, topN: 10 }, opts || {}),
      signal = o.signal,
      progress = o.onProgress || (() => {});
    progress("同类与质量因子", 0);
    const P = await augment(panel, signal),
      split = splitDays(P, o.h),
      sample = samplePanel(P, split.train, o.h),
      valSample = samplePanel(P, split.validation, o.h),
      models = [
        {
          name: "原内置（训练重叠风险，仅参考）",
          kind: "builtin",
          model: builtin,
        },
      ],
      tuning = [];
    for (const [label, keys] of [
      ["原因子重训岭回归", baseKeys],
      [
        "新增因子岭回归",
        baseKeys.concat(EXTRA.filter((k) => !baseKeys.includes(k))),
      ],
    ]) {
      progress(label, 0.2);
      await pause(signal);
      const ids = sample.days.flatMap((d) => sample.byDay.get(d)),
        stats = F.fitStats(P, ids, keys),
        data = dataset(sample, sample.days, o.h, keys, stats);
      if (data.length < 500) throw Error("有效训练记录不足500条");
      let best = null;
      for (const lambda of [3, 30, 300]) {
        const m = ridgeFit(data, keys, stats, lambda),
          ic = F.crossIC(P, scorer(P, m), o.h, {
            days: split.validation,
            minN: 20,
          }).mean;
        tuning.push({ name: label, lambda, validationIC: ic });
        if (finite(ic) && (!best || ic > best.ic)) best = { m, ic };
        await pause(signal);
      }
      if (!best) throw Error("验证集无法计算有效IC");
      models.push({ ...best.m, name: label, validationIC: best.ic });
      if (label === "新增因子岭回归") {
        progress("浅层提升树（深度2）", 0.45);
        const vd = dataset(valSample, valSample.days, o.h, keys, stats);
        if (vd.length < 100) throw Error("验证数据不足");
        const tree = await fitBoost(data, vd, keys, stats, signal, (n, total) =>
          progress("浅层提升树 " + n + "/" + total, 0.45 + (0.25 * n) / total),
        );
        models.push({ ...tree, name: "新增因子浅层提升树" });
      }
    }
    const sourceHashes = [];
    for (let i = 0; i < P.sources.length; i++) {
      const s = P.sources[i];
      sourceHashes.push(
        await hash({
          item: P.items[i],
          day0: s.day0,
          c: Array.from(s.c),
          v: Array.from(s.v),
          real: Array.from(s.real),
        }),
      );
      if (i % 50 === 0) await pause(signal);
    }
    const m = P.marketSeries;
    const dataHash = await hash({
      version: VERSION,
      keys: P.keys,
      sourceHashes,
      market: m
        ? { day0: m.day0, c: Array.from(m.c), real: Array.from(m.real) }
        : null,
      labels: P.rows.map((r) => [r.d, r.it, r.y[o.h]]),
      rules: P.rules,
      h: o.h,
      step: P.step,
      asOf: P.asOf,
    });
    const modelHash = await hash(models),
      createdAt = new Date().toISOString();
    const reports = [];
    for (let i = 0; i < models.length; i++) {
      progress(
        "冻结测试 " + (i + 1) + "/" + models.length,
        0.72 + (0.25 * i) / models.length,
      );
      await pause(signal);
      reports.push({
        name: models[i].name,
        referenceOnly: i === 0,
        ...evaluate(P, models[i], split.test, o.h, o),
      });
    }
    const attempted = split.train.reduce(
        (n, d) => n + (P.byDay.get(d) || []).length,
        0,
      ),
      labelled = split.train.reduce(
        (n, d) =>
          n +
          (P.byDay.get(d) || []).filter((i) => finite(P.rows[i].y[o.h])).length,
        0,
      );
    const coverage = (days) => {
      const ids = days.flatMap((d) => P.byDay.get(d) || []);
      return ids.length
        ? ids.filter((i) => finite(P.rows[i].y[o.h])).length / ids.length
        : 0;
    };
    return {
      schema: 1,
      version: VERSION,
      id: "exp-" + modelHash.slice(0, 16) + "-" + dataHash.slice(0, 8),
      createdAt,
      h: o.h,
      rulesKey: F.rulesKey(P.rules || { enabled: false }),
      rules: P.rules,
      topN: o.topN,
      universe: P.items,
      sourceWindows: P.sources.map((s, i) => ({
        id: P.items[i].id,
        day0: s.day0,
        n: s.n,
        hash: sourceHashes[i],
      })),
      marketWindow: m ? { day0: m.day0, n: m.n } : null,
      protocol: {
        step: P.step,
        lag: P.lag,
        minItemsPerDay: 30,
        tradable: o.tradable || null,
        feeScenarios: [0.01, 0.03],
        buySlip: 0.003,
        sellSlip: 0.003,
        maxFamilyWeight: 0.3,
        maxSeriesWeight: 0.1,
      },
      models,
      reports,
      tuning,
      split: Object.fromEntries(
        Object.entries(split).map(([k, v]) => [
          k,
          Array.isArray(v) ? v.map(F.dayStr) : v,
        ]),
      ),
      provenance: {
        dataHash,
        modelHash,
        asOf: F.dayStr(P.asOf),
        items: P.nItems,
        rows: P.rows.length,
        trainingRows: sample.days.reduce(
          (n, d) => n + sample.byDay.get(d).length,
          0,
        ),
        trainingLabelCoverage: attempted ? labelled / attempted : 0,
        validationLabelCoverage: coverage(split.validation),
        testLabelCoverage: coverage(split.test),
        capPerDate: 128,
        trainOnlyTransforms: true,
        testNeverRefit: true,
        selection: "lambda by validation IC; tree count by validation rank-MSE",
      },
      features: LABELS,
      peer: P.experimental,
      warnings: [
        "当前白名单存在事后选池风险，不是历史全市场。",
        "日K为报价代理，非成交；手续费1%/3%，买卖各0.3%冲击为假设。",
        "IC只使用未来标签可观测的样本，需结合标签覆盖率阅读；执行模拟保留未来缺价。",
        "固定同类30%/同系列10%上限，未选满的份额留现金；未预测绝对收益。",
        "原内置权重可能已见过测试期，只能对照；用原因子重训岭回归隔离因子增益。",
        "测试集仅首次检验可称未触碰；重复运行/挑选会消耗独立性。",
        "没有自动启用实验模型的入口；先积累前向记录。",
      ],
    };
  }
  async function shadow(panel, experiment, quotes, signal) {
    const P = await augment(panel, signal),
      day = P.days[P.days.length - 1];
    if (!finite(day)) throw Error("没有当前截面");
    if (F.rulesKey(P.rules || { enabled: false }) !== experiment.rulesKey)
      throw Error("实验训练规则与当前扫描规则不同，请保持相同规则");
    const capturedAt = new Date().toISOString(),
      q = new Map((quotes || []).map((x) => [String(x.id), x]));
    const arms = experiment.models.map((model) => {
      const fn = scorer(P, model),
        arr = (P.byDay.get(day) || [])
          .map((i) => ({
            it: P.rows[i].it,
            row: P.rows[i],
            score: fn(P.rows[i]),
          }))
          .filter((x) => finite(x.score))
          .sort((a, b) => b.score - a.score || a.it - b.it);
      return {
        name: model.name,
        picks: EX.selectDiversified(arr, P.items, experiment.topN, {
          maxFamilyWeight: 0.3,
          maxSeriesWeight: 0.1,
        }).map((a) => {
          const it = P.items[a.it],
            ask = q.get(String(it.id)),
            valid =
              ask &&
              ask.ok &&
              finite(ask.price) &&
              Date.parse(ask.at) <= Date.parse(capturedAt) &&
              Date.parse(capturedAt) - Date.parse(ask.at) <= 20 * 60000;
          return {
            id: String(it.id),
            name: it.name,
            score: a.score,
            close: a.row.close,
            ask: valid ? ask.price : null,
            quoteAt: valid ? ask.at : null,
            ...EX.groupOf(it),
          };
        }),
      };
    });
    return {
      schema: 1,
      experimentId: experiment.id,
      modelHash: experiment.provenance.modelHash,
      capturedAt,
      day: F.dayStr(day),
      h: experiment.h,
      slots: experiment.topN,
      rulesKey: experiment.rulesKey,
      arms,
    };
  }
  function settleShadow(
    snap,
    byId,
    fee = 0.01,
    asOf = Math.floor(Date.now() / 86400000) - 1,
  ) {
    const entryDay = Math.ceil(Date.parse(snap.capturedAt) / 86400000),
      target = entryDay + snap.h;
    return {
      experimentId: snap.experimentId,
      capturedAt: snap.capturedAt,
      target: F.dayStr(target),
      arms: snap.arms.map((arm) => {
        let total = 0,
          pending = 0,
          missingAsk = 0,
          delayed = 0;
        for (const p of arm.picks) {
          if (!(p.ask > 0)) {
            missingAsk++;
            continue;
          }
          const s = byId.get(p.id);
          let d = target,
            price = null;
          while (d <= asOf) {
            price = EX.realClose(s, d);
            if (price !== null) break;
            d++;
          }
          if (price === null) {
            pending++;
            continue;
          }
          if (d > target) delayed++;
          total += EX.netReturn(price / p.ask - 1, fee) / snap.slots;
        }
        return {
          name: arm.name,
          n: arm.picks.length,
          pending,
          missingAsk,
          delayed,
          net: pending || missingAsk || target > asOf ? null : total,
        };
      }),
    };
  }
  const api = {
    VERSION,
    EXTRA,
    LABELS,
    ownFeatures,
    augment,
    splitDays,
    samplePanel,
    ridgeFit,
    fitTree,
    treePredict,
    scorer,
    run,
    shadow,
    settleShadow,
  };
  root.MarketLensExperiment = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
