> 历史版本文档。2.10.0的执行与实验协议以 EXPERIMENT_2.10.0.md 为准；内置历史研究数字未按新账务重算。

> 本文件为原版历史测试报告。2.9.1修复版的结果见 TEST_RESULTS_2.9.1.txt 和 FIXES_2.9.1.md。

# 测试记录 · 2.9.0（2026-09-26）

环境：Node 20、jsdom 24（仅 DOM 测试需要）。在插件目录执行。

| 套件 | 内容 | 结果 |
|---|---|---|
| `tests/run.js` | lab-2.1 规则（2.6.1 原样） | 20 / 20 |
| `tests/scanner.cjs` | 白名单解析 `resolvePlan` / `absorbSearch`、刷新计划 `kPlan`（fresh / tail / full 与天数）、时间估算、`buildUniverse`（规则排除、持仓优先、家族交错）、`mergeRow`、CSV（选品分 / 买入价上限 / 悠悠在售价 / 来源列）、排序、`summarize`（≥P80 件数）、报告 | 19 / 19 |
| `tests/factor.cjs` | factor-core 因子 / 模型 / 回测 / 筛选规则 / store（2.6.1 原样，含并发写入回归） | 28 / 28 |
| `tests/youpin.cjs` | `youpinQuote`（只取悠悠行、无在售拒绝）、`liquidityOf`、`youpinBasis`、CSV 悠悠列、store 1% 成本迁移 | 10 / 10 |
| `tests/buy.cjs` | `recommend`（P80 / 观察 / 过期 / 闸门）、`verdict`、`holdingState` / `summarizeHoldings`、store 持仓增删改与导入导出、**2.7 / 2.8 `lots` → 持仓一次性迁移** | 17 / 17 |
| `tests/panel.cjs` | 端到端（jsdom，mock 接口）：manifest 脚本顺序；今日买点 2.6.1 文案与 14/30 切换；扫描中清单实时出现；一次定向检索解析缺 ID 条目并写入目录；规则排除的名称不发请求；并发 3；扫描结束后只对 P80 买点读取在售价并标注 可买 / 高于上限；同日重扫 0 次日K请求且在售价按 TTL 复用；隔 10 天只补 60 天并合并回原长度；换周期不发请求、只补新买点的在售价；手动刷新在售价；记为已买入 → 2.6.1 持仓结构（买入价 = 在售价、h、sellBy、pctAtBuy）；持仓页现价 = 日K收盘、刷新现价走缓存、改数量 / 卖出 / 撤销 / 删除；扫盘明细列、CSV / JSON 导出；改规则即时重排不请求；速度设置持久化；连续 10 次失败自动暂停并可续扫；纸面快照 2.6.1 格式；学习页统计；2.8 导出文件导入为持仓；单品页结论卡 + 悠悠口径 + 720 天缓存 + 刷新命中缓存 + 记为已买入 + SPA 切换与非白名单提示 | 30 / 30 |

合计 **124 项通过**。`node --check` 全部脚本通过；`manifest.json` 为合法 JSON，脚本顺序 legacy-core → lab-core → whitelist → scanner-core → factor-core → model-builtin → store → buy-core → panel。

## 与 2.6.1 测试的对应
- 2.6.1 `tests/youpin.cjs` 里关于关键词清单预筛（`listOnly`）、`rankForDeep`、`estimatePlan`、`mergeRow` 报价字段的 5 项随代码移除，替换为 2.9 的 CSV / summarize / liquidity 3 项。
- 2.6.1 `tests/panel.cjs`（57 项）依赖关键词 / 样本池界面，已按 2.9 流程重写；覆盖了原有的一键扫描、清单规则、记为已买入、周期切换、持仓编辑 / 刷新 / 卖出 / 删除、单品结论卡等场景，并新增提速管线的验证。

## 线上核对（开发阶段实测）
- 白名单 816 个 `market_hash_name` 已全部解析到 FirePulse 商品 ID（263 次检索），抽查 4 个 ID 的 `skin_detail_base_info` 名称一致。
- 接口耗时：`skin_k_chart` 1440 天 ≈ 2–2.5 s（50–70 KB）、720 天 ≈ 1.4 s、60–90 天 ≈ 0.8–1.0 s；`detail_price_compare` ≈ 1 s；`skin_search` ≈ 1.5–2.5 s。时间估算与面板“本次预计”基于这些数值。
- 未做的事：没有在真实浏览器里跑完整的 812 件扫描计时（沙箱无浏览器），估算按上面的单请求耗时与并发推算。
