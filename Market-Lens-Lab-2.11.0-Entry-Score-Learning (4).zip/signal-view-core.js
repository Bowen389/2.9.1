/* 2.10.1 transparent display rule. Does NOT rank, train, or execute trades. */
(function(root){
'use strict';
const VERSION='display-2.10.1';
function evaluate(row,context={}){
 const r=row||{},c=context, now=c.now===undefined?Date.now():c.now;
 const reasons=[],risks=Array.isArray(r.risks)?r.risks.slice():[],conditions=Array.isArray(r.conditions)?r.conditions.slice():[];
 if(Array.isArray(c.rankReasons))reasons.push(...c.rankReasons);
 if(Array.isArray(r.reasons))reasons.push(...r.reasons);
 const result=(code,label,why)=>({version:VERSION,code,label,summary:why,reasons,risks,conditions,volumeBasis:'全平台日K成交量代理，非悠悠独立成交量'});
 if(!c.contextReady)return result('blocked','暂缓 / 仅观察',c.blockReason||'扫描、时效或大盘条件尚未通过；不确认买点。');
 if(!c.candidate)return result('outside','未入选原模型买点','未进入当前周期原模型 P80 候选清单；不因价格便宜或旧规则高分自动入选。');
 if(!r.deepOk)return result('insufficient','证据不足',r.deepReason||'日K深度复核不可用。');
 const q=c.quote,at=q&&Date.parse(q.at),ttl=c.quoteTtlMs;
 if(!q?.ok||!Number.isFinite(q.price)||q.price<=0||!Number.isFinite(at)||!Number.isFinite(now)||!Number.isFinite(ttl)||ttl<=0||now<at||now-at>ttl||(Number.isFinite(q.count)&&q.count<=0))return result('quote','待报价确认','缺少有效且未过期的悠悠在售价，不能确认价格触发。');
 if(!Number.isFinite(c.limit)||c.limit<=0)return result('insufficient','证据不足','原模型买入价上限不可用。');
 if(q.price>c.limit)return result('price','等待价格触发',`悠悠在售价 ${q.price.toFixed(2)} 高于原模型上限 ${c.limit.toFixed(2)}。`);
 const priceText=`原模型候选；悠悠在售价 ${q.price.toFixed(2)} 不高于上限 ${c.limit.toFixed(2)}。`;
 if(r.eligible!==true||!Number.isFinite(r.relativeVolume)||r.relativeVolume<1)return result('volume','价格触发，仍需量验证',priceText+` 相对量 ${Number.isFinite(r.relativeVolume)?r.relativeVolume.toFixed(2)+' 倍（需≥1倍）':'不可用'}；旧规则基础条件${r.eligible===true?'已通过':'未通过'}，仍须确认成交量代理与流动性。`);
 return result('trigger','触发买点（规则）',priceText+` 相对量 ${r.relativeVolume.toFixed(2)} 倍且旧规则基础条件通过；仅全平台量代理验证，不保证可成交或盈利。`);
}
const api={VERSION,evaluate};root.MarketLensSignalView=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
