/* Market Lens · FirePulse single-item observation model.
 *
 * v1.7.0: FirePulse-only. Snapshot ratios + youpin daily K (OHLC ask history
 * with global volume) feed a 5-factor model. See ITEM_MODEL.md.
 *
 * Pure functions, no DOM. Safe to require() in Node for tests.
 */
(function (root) {
  'use strict';

  var MODEL_ID = 'firepulse-youpin-observation-1.3';

  // -- scoring parameters (1.3 calibration, 2026-09-18, n=21 + synthetic) -----
  // F1 snapshot momentum (35): reference-basis d1/d7/d30, 7d-weighted.
  var MOMENTUM_PERIODS = [
    ['d1', 0.3, 1],
    ['d7', 0.4, Math.sqrt(7)],
    ['d30', 0.3, Math.sqrt(30)],
  ];
  var MOMENTUM_WIDTH = 4;
  // F2 youpin K trend (25): MA/RSI/slope composite on youpin daily closes.
  var K_MIN_ROWS = 60; // valid rows required
  var K_STALE_DAYS = 7; // last row older than this -> K unusable
  var RSI_PERIOD = 14;
  // F3 OBV agreement (15): directed-volume slope vs 20-row return.
  var OBV_WINDOW = 20;
  var OBV_NZ_MIN = 15; // nonzero-volume rows required in last 60
  var OBV_AGREE_SCALE = 3; // tanh scale on agreement
  var OBV_ADOPT_WIDTH = 8; // tanh width on (mom60-30) adoption
  var DIVERGE_LO = -0.2; // agreement at/below this -> divergence warning
  // F4 activity (15) / F5 turnover proxy (10): same anchors as 1.2, rescaled.
  var ACTIVITY_CAP = 501;
  var TURNOVER_LO = 0.0002,
    TURNOVER_HI = 0.02;
  // Bands on the 100 total; momentum gates on mom60 = F1+F2 (60 max).
  var BAND_HI = 65,
    BAND_LO = 40,
    MOM60_GATE_HI = 36,
    MOM60_GATE_LO = 24;
  var V0_CAP = 45; // zero daily trades -> total capped (ask-fiction guard)

  var clamp = function (x, a, b) {
    return Math.max(a, Math.min(b, x));
  };

  // Strict numeric parser: accepts numbers and numeric strings ("1691",
  // "1,691"), rejects everything else (booleans, objects, empty, NaN).
  var n = function (x) {
    if (x === null || x === undefined || typeof x === 'boolean' || typeof x === 'object')
      return null;
    var s = String(x).trim().replace(/,/g, '');
    if (!s || !/^[-+]?\d+(?:\.\d+)?$/.test(s)) return null;
    var v = Number(s);
    return Number.isFinite(v) ? v : null;
  };

  var clean = function (s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 180);
  };

  var finite = function (v, lower) {
    if (lower === undefined) lower = -Infinity;
    return typeof v === 'number' && Number.isFinite(v) && v >= lower;
  };

  // ---------------------------------------------------------------------------
  // Routing: FirePulse item pages only.
  // https://firepulse.com.cn/cs2/<numeric id>[?name=...]
  // ---------------------------------------------------------------------------
  function route(url) {
    try {
      var u = new URL(url);
      var h = u.hostname.replace(/^www\./, '');
      if (u.protocol !== 'https:' || h !== 'firepulse.com.cn') return null;
      var m = u.pathname.match(/^\/cs2\/(\d+)\/?$/);
      if (!m) return null;
      return { site: 'firepulse', id: m[1], key: 'firepulse:' + m[1], title: '商品 ' + m[1] };
    } catch (e) {
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // sanitize(): normalize one field-set into the canonical shape.
  //
  // Canonical fields:
  //   price       youpin ask (CNY). Required for scoring.
  //   d1/d7/d30   change %, FirePulse reference-price basis (NOT a youpin
  //               price series). At least one is required for a total score.
  //   d7youpin    youpin 7-point ask-series implied change %, display/cross-check
  //               only, never enters momentum.
  //   v           全平台24h trade count. turnover24: 24h turnover amount (CNY).
  //   s           current-wear total supply.
  //   changeBasis 'firepulse-ref' when d1/d7/d30 came from the quote API or the
  //               item page wording ('今日/近7天/近30天'), else 'none'.
  // ---------------------------------------------------------------------------
  function sanitize(f, identity) {
    if (!f || typeof f !== 'object') throw Error('无单品字段');
    if (!identity || identity.site !== 'firepulse' || !identity.id) throw Error('单品身份缺失');

    var source = f.source === 'firepulse-api' || f.source === 'page-text' ? f.source : 'page-text';
    var volumeBasis =
      f.volumeBasis === '全平台24h' || f.volumeBasis === '页面标注成交'
        ? f.volumeBasis
        : '页面标注成交';

    var out = {
      site: 'firepulse',
      id: String(identity.id),
      key: identity.key,
      title: clean(f.title || identity.title),
      source: source,
      currency: 'CNY',
      volumeBasis: volumeBasis,
      priceBasis: clean(f.priceBasis || '页面参考价'),
      changeBasis: f.changeBasis === 'firepulse-ref' ? 'firepulse-ref' : 'none',
      updatedAt: clean(f.updatedAt),
      quotes: [],
    };

    var keys = ['price', 'd1', 'd7', 'd30', 'd7youpin', 'v', 's', 'turnover24'];
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      var v = n(f[k]);
      if (v === null) {
        out[k] = null;
        continue;
      }
      if (k === 'd1' || k === 'd7' || k === 'd30' || k === 'd7youpin') {
        out[k] = v >= -100 && v <= 100000 ? v : null;
      } else {
        out[k] = v >= 0 ? v : null;
      }
    }
    if (out.price === 0) out.price = null;

    return out;
  }

  // Parse a display string like "+1.23%" / "-0.5 %" into a number.
  function parseSignedPct(s) {
    if (s === null || s === undefined) return null;
    var m = String(s)
      .trim()
      .match(/^([+-]?[\d,]+(?:\.\d+)?)\s*%$/);
    return m ? n(m[1]) : null;
  }

  // Implied change from a platform ask-price series (first point -> last point).
  // Returns null unless the series is sane AND its last point matches the live
  // price within 1% (guards against stale or mislabeled series).
  function trendImpliedChange(trend, livePrice) {
    if (!Array.isArray(trend) || trend.length < 2) return null;
    var pts = trend.map(n);
    if (
      pts.some(function (x) {
        return x === null || x <= 0;
      })
    )
      return null;
    var first = pts[0],
      last = pts[pts.length - 1];
    if (!finite(livePrice) || livePrice <= 0) return null;
    if (Math.abs(last - livePrice) / livePrice > 0.01) return null;
    return (last / first - 1) * 100;
  }

  // ---------------------------------------------------------------------------
  // firepulse(): adapt the two public quote/base responses.
  //
  // Endpoints (POST, JSON body {id}):
  //   /v1/market/facade/wiki/skin_detail_base_info  -> identity + wear list
  //   /v1/market/facade/quote/detail_price_compare  -> ratios, volume, supply,
  //                                                    per-platform sell rows
  //
  // Verified 2026-09-18 against the live API + item page wording:
  //   data.today_ratio / week_ratio / month_ratio are PERCENT values
  //   (1.23 means +1.23%), matching the page "今日/近7天/近30天".
  //   They track the FirePulse reference price (lowest-ask anchored), NOT the
  //   youpin ask series, so they are labeled changeBasis 'firepulse-ref'.
  //   data.sell[].trend is a 7-point ask series per platform; the youpin row's
  //   series is used to derive d7youpin as a cross-check, nothing more.
  // ---------------------------------------------------------------------------
  function firepulse(base, quote, id) {
    if (!base || base.code !== 200 || !quote || quote.code !== 200) {
      throw Error('商品公开响应未就绪');
    }
    var b = base.data,
      q = quote.data;
    if (!b || !q) throw Error('商品字段结构改变');
    if (String(b.id) !== String(id)) throw Error('商品身份或公开响应校验失败');
    if (!Array.isArray(b.list)) throw Error('商品字段结构改变');
    if (
      !b.list.some(function (x) {
        return String(x.id) === String(id);
      })
    ) {
      throw Error('未确认当前磨损');
    }

    // Price: exactly one youpin sell row. Never substitute another platform.
    var rows = (Array.isArray(q.sell) ? q.sell : []).filter(function (r) {
      return r && r.platform_key === 'youpin';
    });
    if (rows.length !== 1) throw Error('悠悠有品在售报价缺失或不唯一，不评分');
    var youpin = rows[0];
    var price = n(youpin.price);
    if (price === null || price <= 0) throw Error('悠悠有品在售报价无效，不评分');

    // Changes, reference-price basis. Missing ratios stay null (no guessing).
    var d1 = n(q.today_ratio),
      d7 = n(q.week_ratio),
      d30 = n(q.month_ratio);

    // Cross-check numeric ratios against the display strings the API ships
    // alongside them (today_ratio_str etc.). A mismatch means the schema or
    // the unit convention changed -> flag it instead of silently mis-scoring.
    var crossWarnings = [];
    var pairs = [
      ['d1', d1, q.today_ratio_str],
      ['d7', d7, q.week_ratio_str],
      ['d30', d30, q.month_ratio_str],
    ];
    for (var i = 0; i < pairs.length; i++) {
      var label = pairs[i][0],
        val = pairs[i][1],
        str = pairs[i][2];
      if (val === null || str === null || str === undefined) continue;
      var expect = parseSignedPct(str);
      if (expect !== null && Math.abs(val - expect) > 0.051) {
        crossWarnings.push(
          '接口' +
            label +
            '数值(' +
            val +
            ')与展示字符串(' +
            clean(str) +
            ')不一致，单位或口径可能已变化，请以页面为准核对',
        );
      }
    }

    // Youpin 7-point ask series -> implied 7d change, cross-check only.
    var d7youpin = trendImpliedChange(youpin.trend, price);
    if (d7youpin !== null && d7 !== null && Math.abs(d7youpin - d7) > 3) {
      crossWarnings.push(
        '悠悠在售价近7点涨跌(' +
          (d7youpin >= 0 ? '+' : '') +
          d7youpin.toFixed(2) +
          '%)与参考价近7天(' +
          (d7 >= 0 ? '+' : '') +
          d7 +
          '%)背离超过3个百分点，动量分仅反映参考价口径',
      );
    }

    var f = sanitize(
      {
        title: b.name,
        source: 'firepulse-api',
        price: price,
        d1: d1,
        d7: d7,
        d30: d30,
        d7youpin: d7youpin,
        v: q.trade_count_24,
        turnover24: q.trade_volume_24,
        s: q.total_supply,
        volumeBasis: '全平台24h',
        priceBasis: '悠悠有品在售报价 · CNY · FirePulse转述',
        changeBasis: d1 !== null || d7 !== null || d30 !== null ? 'firepulse-ref' : 'none',
        updatedAt: b.updated_at,
      },
      { site: 'firepulse', id: String(id), key: 'firepulse:' + id },
    );

    f.crossWarnings = crossWarnings;
    return f;
  }

  // ---------------------------------------------------------------------------
  // youpinBasis(f, k) (Lab 2.5): rebase the snapshot changes d1/d7/d30 onto the
  // 悠悠有品 price series. d1/d7/d30 = current youpin ask vs the youpin daily-K
  // close 1/7/30 calendar days before the last closed day's successor (i.e.
  // last closed day, day-6, day-29). k is kchart() output. The FirePulse
  // reference-price values are kept as f.ref for display only.
  // Returns a NEW object; never throws (missing K => changes null, basis 'none').
  // ---------------------------------------------------------------------------
  function youpinBasis(f, k) {
    if (!f || typeof f !== 'object') return f;
    var out = {};
    for (var key in f) if (Object.prototype.hasOwnProperty.call(f, key)) out[key] = f[key];
    out.ref = { d1: f.d1, d7: f.d7, d30: f.d30, basis: f.changeBasis };
    out.d1 = out.d7 = out.d30 = null;
    out.changeBasis = 'none';
    // Drop warnings that compared the youpin series against the reference price.
    out.crossWarnings = (Array.isArray(f.crossWarnings) ? f.crossWarnings : []).filter(function (w) {
      return String(w).indexOf('参考价') < 0;
    });
    // Only closed days: drop an in-progress bar (t >= today 00:00 UTC).
    var today0 = Math.floor((k && finite(k.observedAt) ? k.observedAt : Date.now()) / 86400000) * 86400000;
    var rows = (k && Array.isArray(k.rows) ? k.rows : []).filter(function (r) { return r.t < today0; });
    if (!finite(f.price, Number.MIN_VALUE) || !rows.length) return out;
    var last = rows[rows.length - 1];
    var lastDayMs = Date.parse(last.day + 'T00:00:00Z');
    // Close on or before a target calendar day (K rows may skip days).
    function closeOnOrBefore(ms) {
      for (var i = rows.length - 1; i >= 0; i--) {
        if (Date.parse(rows[i].day + 'T00:00:00Z') <= ms) return rows[i].c;
      }
      return null;
    }
    var spans = [['d1', 0], ['d7', 6], ['d30', 29]];
    for (var j = 0; j < spans.length; j++) {
      var c = closeOnOrBefore(lastDayMs - spans[j][1] * 86400000);
      out[spans[j][0]] = c && c > 0 ? (f.price / c - 1) * 100 : null;
    }
    if (out.d1 !== null || out.d7 !== null || out.d30 !== null) out.changeBasis = 'youpin-k';
    if (out.d7youpin !== null && out.d7youpin !== undefined && out.d7 !== null && Math.abs(out.d7youpin - out.d7) > 3) {
      out.crossWarnings.push(
        '悠悠7点在售走势(' + (out.d7youpin >= 0 ? '+' : '') + out.d7youpin.toFixed(2) +
          '%)与悠悠日K推算的近7天(' + (out.d7 >= 0 ? '+' : '') + out.d7.toFixed(2) + '%)相差超过3个百分点，请核对页面',
      );
    }
    return out;
  }

  function parseCount(s) {
    var m = String(s === null || s === undefined ? '' : s)
      .trim()
      .match(/^([\d,]+(?:\.\d+)?)\s*(万|亿|[kKmM])?$/);
    if (!m) return null;
    var base = n(m[1]);
    if (base === null) return null;
    var mult = { 万: 1e4, 亿: 1e8, k: 1e3, K: 1e3, m: 1e6, M: 1e6 }[m[2]] || 1;
    return base * mult;
  }

  // ---------------------------------------------------------------------------
  // dom(): fallback parser for the FirePulse item page wording. Used ONLY when
  // the structured API is unavailable. It never fabricates a youpin price:
  // price stays null, so the result can display fields but never scores.
  //
  // Page wording (verified 2026-09-18):
  //   参考价格￥33800 （+1.23%） / 今日 +410.01（+1.23%）/
  //   近7天 +401（+1.2%）/ 近30天 +1000（+3.05%）/
  //   24小时参考成交 3 / 存世量 1691
  // ---------------------------------------------------------------------------
  function dom(text, title, identity) {
    var t = String(text).replace(/\s+/g, ' ').slice(0, 60000);

    // Prefer the % inside parentheses: "近7天 +401（+1.2%）".
    var pctParen = function (labels) {
      var re = new RegExp(
        '(?:' + labels + ')[^%（）()]{0,40}[（(]\\s*([+-]?\\d+(?:\\.\\d+)?)\\s*%',
        'i',
      );
      var m = t.match(re);
      return m ? n(m[1]) : null;
    };
    var pctLoose = function (labels) {
      var re = new RegExp('(?:' + labels + ')[^%]{0,40}?([+-]?\\d+(?:\\.\\d+)?)\\s*%', 'i');
      var m = t.match(re);
      return m ? n(m[1]) : null;
    };
    var val = function (labels) {
      var m = t.match(
        new RegExp(
          '(?:' + labels + ')\\s*[:：]?\\s*([\\d,]+(?:\\.\\d+)?\\s*(?:万|亿|[kKmM])?)',
          'i',
        ),
      );
      return m ? parseCount(m[1]) : null;
    };

    /* v1.9.1: a 0% change is a legitimate value, but `||` treats it as
     * missing and falls through to the loose regex, which can then capture an
     * unrelated percentage nearby (e.g. 参考价格 +7.5% leaking into 今日 +0%).
     * Fallback must only happen on an explicit null (no match). */
    var d1 = pctParen('今日');
    if (d1 === null) d1 = pctLoose('今日|参考价格');
    var d7 = pctParen('近7天|近7日|7天涨跌');
    if (d7 === null) d7 = pctLoose('近7天|近7日|7天涨跌');
    var d30 = pctParen('近30天|近30日|近1个月|30天涨跌');
    if (d30 === null) d30 = pctLoose('近30天|近30日|近1个月|30天涨跌');

    return sanitize(
      {
        title: title,
        source: 'page-text',
        price: null, // page shows the reference price, never a youpin ask
        d1: d1,
        d7: d7,
        d30: d30,
        d7youpin: null,
        v: val('24小时参考成交(?!额)|24h成交量|日成交量'),
        turnover24: val('24小时参考成交额|24h成交额'),
        s: val('存世量|存世数量'),
        volumeBasis: '页面标注成交',
        priceBasis: '页面参考价（非悠悠，不评分）',
        changeBasis: d1 !== null || d7 !== null || d30 !== null ? 'firepulse-ref' : 'none',
      },
      identity,
    );
  }

  // -- small series helpers (local copies keep item-core standalone) ------------
  var mean = function (a) {
    return (
      a.reduce(function (s, x) {
        return s + x;
      }, 0) / a.length
    );
  };
  var sma = function (a, p) {
    return a.length >= p ? mean(a.slice(-p)) : null;
  };
  var squash = function (x) {
    return (1 + Math.tanh(x)) / 2;
  };

  function rsiCloses(closes, p) {
    if (closes.length <= p) return null;
    var gain = 0,
      loss = 0,
      i,
      d;
    for (i = 1; i <= p; i++) {
      d = closes[i] - closes[i - 1];
      gain += Math.max(d, 0);
      loss += Math.max(-d, 0);
    }
    gain /= p;
    loss /= p;
    for (i = p + 1; i < closes.length; i++) {
      d = closes[i] - closes[i - 1];
      gain = (gain * (p - 1) + Math.max(d, 0)) / p;
      loss = (loss * (p - 1) + Math.max(-d, 0)) / p;
    }
    if (gain === 0 && loss === 0) return 50;
    if (loss === 0) return 100;
    return 100 - 100 / (1 + gain / loss);
  }

  // ---------------------------------------------------------------------------
  // kchart(): adapt POST /v1/market/facade/quote/skin_k_chart
  //   {id, type:2, timestamp:<sec>, date_range:1440, platform:'youpin'}
  //
  // Rows are [t, o, c, l, h, volume, turnover] with t in SECONDS (string).
  // NOTE: the volume/turnover column order is the OPPOSITE of the category
  // k/data endpoint (verified: turnover/volume ~= close price on live data).
  // OHLC tracks the platform ask series; volume/turnover are GLOBAL
  // (identical across platform= param values, verified live).
  //
  // Cleaning (ask history has test-era artifacts, all observed pre-2024):
  // invalid rows are DROPPED, not fatal. Gaps are tolerated (platform
  // misses days); indicators use trailing-row windows, not calendar windows.
  // Returns flags; throws only when the payload itself is unusable.
  // ---------------------------------------------------------------------------
  function kchart(payload, now) {
    if (now === undefined) now = Date.now();
    if (!payload || payload.code !== 200 || !Array.isArray(payload.data)) {
      throw Error('悠悠日K响应未就绪');
    }
    var raw = payload.data;
    if (raw.length > 10000) throw Error('日K记录过多');
    var out = [],
      dropped = 0,
      i;
    var rawMaxT = -Infinity; // newest timestamp seen, valid or not
    for (i = 0; i < raw.length; i++) {
      var r = raw[i];
      if (!Array.isArray(r) || r.length < 7) {
        dropped++;
        continue;
      }
      var t = n(r[0]);
      if (t === null) {
        dropped++;
        continue;
      }
      if (t < 1e12) t *= 1000;
      if (t > rawMaxT) rawMaxT = t;
      var o = n(r[1]),
        c = n(r[2]),
        l = n(r[3]),
        h = n(r[4]),
        v = n(r[5]);
      if (
        o === null ||
        c === null ||
        l === null ||
        h === null ||
        v === null ||
        v < 0 ||
        Math.min(o, c, l, h) <= 0 ||
        l > Math.min(o, c) ||
        h < Math.max(o, c) ||
        h < l
      ) {
        dropped++;
        continue;
      }
      out.push({ t: t, o: o, c: c, l: l, h: h, v: v });
    }
    out.sort(function (a, b) {
      return a.t - b.t;
    });
    // Dedupe same UTC day, keep last (K timestamps are UTC midnights).
    var ded = [];
    for (i = 0; i < out.length; i++) {
      var d = new Date(out[i].t).toISOString().slice(0, 10);
      if (ded.length && ded[ded.length - 1].day === d) {
        ded[ded.length - 1] = {
          t: out[i].t,
          o: out[i].o,
          c: out[i].c,
          l: out[i].l,
          h: out[i].h,
          v: out[i].v,
          day: d,
        };
      } else {
        ded.push({
          t: out[i].t,
          o: out[i].o,
          c: out[i].c,
          l: out[i].l,
          h: out[i].h,
          v: out[i].v,
          day: d,
        });
      }
    }
    var lastT = ded.length ? ded[ded.length - 1].t : null;
    var staleDays =
      lastT === null ? Infinity : Math.floor(now / 86400000) - Math.floor(lastT / 86400000);
    // Tail integrity, two independent tripwires (either one kills ok2):
    // (a) the last two RAW positions fail full validation (time + OHLC);
    // (b) a dropped row carries a newer timestamp than the last valid row
    //     (unordered feed with a corrupt head: the "latest close" is a lie).
    var endBadPos = false;
    for (i = Math.max(0, raw.length - 2); i < raw.length; i++) {
      var pr = raw[i];
      if (!Array.isArray(pr) || pr.length < 7) {
        endBadPos = true;
        break;
      }
      var pt = n(pr[0]);
      var po = n(pr[1]),
        pc = n(pr[2]),
        pl = n(pr[3]),
        ph = n(pr[4]),
        pv = n(pr[5]);
      if (
        pt === null ||
        po === null ||
        pc === null ||
        pl === null ||
        ph === null ||
        pv === null ||
        pv < 0 ||
        Math.min(po, pc, pl, ph) <= 0 ||
        pl > Math.min(po, pc) ||
        ph < Math.max(po, pc) ||
        ph < pl
      ) {
        endBadPos = true;
        break;
      }
    }
    var endCorrupt = endBadPos || rawMaxT > (lastT === null ? -Infinity : lastT);
    var stale = staleDays > K_STALE_DAYS;
    var ok2 = ded.length >= K_MIN_ROWS && !endCorrupt && !stale;
    var nz60 = ded.slice(-60).filter(function (x) {
      return x.v > 0;
    }).length;
    var ok3 = ok2 && nz60 >= OBV_NZ_MIN;
    return {
      observedAt: now,
      rows: ded,
      ok2: ok2,
      ok3: ok3,
      nz60: nz60,
      asOf: ded.length ? ded[ded.length - 1].day : null,
      staleDays: staleDays === Infinity ? null : staleDays,
      dropped: dropped,
      endCorrupt: endCorrupt,
      stale: stale,
    };
  }

  // ---------------------------------------------------------------------------
  // score(f, k): F1 snapshot momentum 35 + F2 youpin K trend 25 +
  // F3 OBV agreement 15 + F4 activity 15 + F5 turnover proxy 10.
  //
  // k is kchart() output or null (K fetch failed). Missing/insufficient K
  // degrades F2/F3 to neutral placeholders with zero coverage for them.
  // No total without SOME momentum (snapshot changes or usable K).
  // ---------------------------------------------------------------------------
  function score(f, k) {
    // -- F1: snapshot momentum (35, reference basis) ---------------------------
    var periods = MOMENTUM_PERIODS;
    var available = periods.filter(function (p) {
      return finite(f[p[0]]);
    });
    var pw = available.reduce(function (s, p) {
      return s + p[1];
    }, 0);
    var momentum = pw
      ? available.reduce(function (s, p) {
          return s + (p[1] * f[p[0]]) / p[2];
        }, 0) / pw
      : null;
    var f1 = 17.5 + (pw ? (35 * pw * Math.tanh(momentum / MOMENTUM_WIDTH)) / 2 : 0);

    // -- F2: youpin K trend (25) ------------------------------------------------
    var kOk2 = !!(k && k.ok2);
    var f2 = 12.5,
      f2rsi = null;
    var f2note = '未读到可用悠悠日K，中性占位';
    if (kOk2) {
      var closes = k.rows.slice(-120).map(function (r) {
        return r.c;
      });
      var w31 = closes.slice(-31);
      var rets = w31.slice(1).map(function (x, i) {
        return Math.log(x / w31[i]);
      });
      var mu = mean(rets);
      var sigma = Math.max(
        0.0025,
        Math.sqrt(
          mean(
            rets.map(function (x) {
              return (x - mu) * (x - mu);
            }),
          ),
        ),
      );
      var lastC = closes[closes.length - 1];
      var ma5 = sma(closes, 5),
        ma20 = sma(closes, 20),
        ma20ago = sma(closes.slice(0, -5), 20);
      f2rsi = rsiCloses(closes.slice(-60), RSI_PERIOD);
      f2 =
        (25 *
          (squash(Math.log(lastC / ma20) / (sigma * 2)) +
            squash(Math.log(ma5 / ma20) / (sigma * 2)) +
            f2rsi / 100 +
            squash(Math.log(ma20 / ma20ago) / (sigma * 2)))) /
        4;
      f2note =
        '收盘' +
        (lastC >= ma20 ? '高于' : '低于') +
        'MA20；RSI(14) ' +
        f2rsi.toFixed(0) +
        '；日K截至 ' +
        k.asOf +
        '（T-1）';
    } else if (k) {
      f2note = k.stale
        ? '悠悠日K已过期' + k.staleDays + '天，中性占位'
        : k.endCorrupt
          ? '悠悠日K末端数据异常，中性占位'
          : '悠悠有效日K仅' + k.rows.length + '条，不足' + K_MIN_ROWS + '条，中性占位';
    }

    var mom60 = f1 + f2;

    // -- F3: OBV agreement (15) --------------------------------------------------
    // agree = OBV-slope sign vs price direction over the last OBV_WINDOW rows.
    // Adopted by established momentum: volume confirms but never invents trend.
    var kOk3 = !!(k && k.ok3);
    var f3 = 7.5,
      agree = null,
      obvSlope = null,
      priceRet = null;
    var f3note = '无可用量史，中性占位';
    if (kOk3) {
      var w = k.rows.slice(-60);
      var obv = 0,
        series = [0],
        j;
      for (j = 1; j < w.length; j++) {
        obv += (w[j].c > w[j - 1].c ? 1 : w[j].c < w[j - 1].c ? -1 : 0) * w[j].v;
        series.push(obv);
      }
      var volN = 0;
      for (j = w.length - OBV_WINDOW; j < w.length; j++) volN += w[j].v;
      priceRet = w[w.length - 1].c / w[w.length - OBV_WINDOW - 1].c - 1;
      obvSlope =
        volN <= 0 ? 0 : (series[series.length - 1] - series[series.length - OBV_WINDOW - 1]) / volN;
      agree = priceRet === 0 || obvSlope === 0 ? 0 : obvSlope * (priceRet > 0 ? 1 : -1);
      var adopt = Math.tanh((mom60 - 30) / OBV_ADOPT_WIDTH);
      f3 = 7.5 + 7.5 * Math.tanh(agree * OBV_AGREE_SCALE) * adopt;
      if (mom60 < 30) f3 = Math.min(f3, 7.5); // falling: volume adds no bullish points
      f3note =
        'OBV' +
        OBV_WINDOW +
        '斜率 ' +
        obvSlope.toFixed(2) +
        '，' +
        OBV_WINDOW +
        '行涨跌 ' +
        (priceRet * 100).toFixed(1) +
        '%，一致度 ' +
        agree.toFixed(2);
    } else if (k && k.ok2) {
      f3note = '近60行有量日仅' + k.nz60 + '天，不足' + OBV_NZ_MIN + '天，中性占位';
    }
    var diverged = agree !== null && agree <= DIVERGE_LO;

    // -- F4 activity (15) / F5 turnover proxy (10) -------------------------------
    var liq = finite(f.v, 0)
      ? 15 * clamp(Math.log10(1 + f.v) / Math.log10(ACTIVITY_CAP), 0, 1)
      : 7.5;
    var turnover =
      f.volumeBasis === '全平台24h' && finite(f.v, 0) && finite(f.s, 1) ? f.v / f.s : null;
    var supply;
    if (turnover === null) {
      supply = 5;
    } else if (turnover <= 0) {
      supply = 0;
    } else {
      supply =
        10 *
        clamp(
          (Math.log10(turnover) - Math.log10(TURNOVER_LO)) /
            (Math.log10(TURNOVER_HI) - Math.log10(TURNOVER_LO)),
          0,
          1,
        );
    }

    var coverage = Math.round(
      35 * pw +
        (kOk2 ? 25 : 0) +
        (kOk3 ? 15 : 0) +
        (finite(f.v, 0) ? 15 : 0) +
        (turnover !== null ? 10 : 0),
    );
    var valid = finite(f.price, Number.MIN_VALUE) && coverage > 0 && (pw > 0 || kOk2);
    var raw = f1 + f2 + f3 + liq + supply;

    var capped = false;
    if (valid && f.v === 0 && raw > V0_CAP) {
      raw = V0_CAP;
      capped = true;
    }

    var tierRaw = liq + supply; // 25 max, price/momentum independent
    var liquidityTier = tierRaw >= 20 ? '高' : tierRaw >= 12 ? '中' : '低';

    // Momentum-gated bands on mom60 = F1+F2: liquidity never overrules trend.
    var gatedHi = raw >= BAND_HI && mom60 < MOM60_GATE_HI;
    var gatedLo = raw >= BAND_LO && mom60 <= MOM60_GATE_LO;
    var regime = !valid
      ? '仅流动性观察'
      : raw >= BAND_HI && mom60 >= MOM60_GATE_HI
        ? '偏积极'
        : raw < BAND_LO || mom60 <= MOM60_GATE_LO
          ? '偏谨慎'
          : '中性观察';

    var conflict = kOk2 && pw > 0 && Math.abs(f1 / 35 - f2 / 25) > 0.35;

    var factors = [
      {
        name: '快照动量',
        points: f1,
        max: 35,
        note: pw
          ? '今日/7日/30日有' +
            available.length +
            '项，权重0.3/0.4/0.3；跨度缩放动量 ' +
            momentum.toFixed(2) +
            '%（参考价口径，含今日）'
          : '未读到涨跌，中性占位',
      },
      {
        name: '悠悠趋势',
        points: f2,
        max: 25,
        note: f2note,
      },
      {
        name: '量价配合',
        points: f3,
        max: 15,
        note: f3note,
      },
      {
        name: '成交活跃度',
        points: liq,
        max: 15,
        note: finite(f.v, 0)
          ? f.volumeBasis + ' ' + f.v + '；对数刻度，500件/24h记满分，未做品类校准'
          : '未读到成交量，中性占位7.5分',
      },
      {
        name: '成交/存世代理',
        points: supply,
        max: 10,
        note:
          turnover === null
            ? '缺少同口径数据，中性占位5分，不硬算换手'
            : '成交/存世 ' + (turnover * 100).toFixed(3) + '%；对数刻度0.02%→0分、2%→满分',
      },
    ];

    var warnings = [];
    if (f.source === 'firepulse-api') {
      warnings.push('价格为悠悠有品在售报价，不保证可成交、未计费用。');
    }
    if (f.changeBasis === 'youpin-k') {
      warnings.push('快照涨跌已按悠悠口径计算：当前悠悠在售价对比悠悠日K收盘（近1/7/30天）。');
    }
    if (f.changeBasis === 'firepulse-ref') {
      warnings.push(
        '快照涨跌为FirePulse参考价口径（含今日）；悠悠趋势来自悠悠日K收盘（T-1）。两者背离时以日K为准观察。',
      );
    }
    if (f.source === 'page-text') {
      warnings.push('页面文字备用解析：字段可能受网站布局影响，可信度较低，请核对原页面。');
    }
    if (Array.isArray(f.crossWarnings)) {
      for (var i = 0; i < f.crossWarnings.length; i++) warnings.push(f.crossWarnings[i]);
    }
    if (!k) {
      warnings.push('悠悠日K暂不可用，趋势与量价按中性占位；分数仅反映快照与流动性。');
    } else if (!k.ok2) {
      warnings.push(
        '悠悠日K' +
          (k.stale ? '已过期' + k.staleDays + '天' : '不足' + K_MIN_ROWS + '条有效记录') +
          '，趋势与量价按中性占位。',
      );
    } else if (!k.ok3) {
      warnings.push('近60行有量日仅' + k.nz60 + '天，量价按中性占位，不做无量推断。');
    }
    if (conflict) {
      warnings.push(
        '快照涨跌与悠悠日K趋势冲突（快照' +
          (f1 / 35 >= 0.5 ? '偏强' : '偏弱') +
          '、日K' +
          (f2 / 25 >= 0.5 ? '偏强' : '偏弱') +
          '），建议以日K为准观察。',
      );
    }
    if (diverged && mom60 >= 30) {
      warnings.push('量价顶背离：动量向上但OBV走弱，上涨缺量能确认，警惕假突破。');
    }
    if (diverged && mom60 < 30) {
      warnings.push('量价底背离：价格走弱但OBV相对坚挺，仅提示，不加分。');
    }
    if (f2rsi !== null && f2rsi > 70)
      warnings.push('悠悠RSI(14)偏热(' + f2rsi.toFixed(0) + ')：趋势强不等于追涨风险低');
    if (f2rsi !== null && f2rsi < 30)
      warnings.push(
        '悠悠RSI(14)超卖(' + f2rsi.toFixed(0) + ')：弱势中仍可能继续下跌，不加抄底奖励',
      );
    if (valid && gatedHi) {
      warnings.push('总分已达偏积极线，但双动量不足36分，流动性不替趋势背书，判中性观察。');
    }
    if (valid && gatedLo) {
      warnings.push('双动量跌破24分，趋势向下时流动性再好也不洗白，直接判偏谨慎。');
    }
    if (capped) {
      warnings.push('当前统计口径成交为0，无成交的趋势不可信，总分封顶' + V0_CAP + '分。');
    }
    if (!valid && pw === 0 && !kOk2) {
      warnings.push('快照与日K均无动量数据，不出总分；仅展示流动性观察。');
    } else if (coverage < 100) {
      warnings.push('缺失因子按中性占位，分数向50收缩；这不是完整模型结论。');
    }
    if (f.d1 > 8 || f.d30 > 25) warnings.push('近期涨幅较大，强势不等于适合追涨。');
    if (f.v === 0 && !capped) warnings.push('当前统计口径成交为0，需关注流动性。');

    return {
      model: MODEL_ID,
      total: valid ? Math.round(clamp(raw, 0, 100)) : null,
      coverage: coverage,
      liquidityTier: liquidityTier,
      quality:
        f.source === 'page-text'
          ? '低 · 页面字段待核验'
          : coverage >= 80
            ? '较高 · 接口结构化字段'
            : '中 · 部分字段缺失',
      regime: regime,
      factors: factors,
      warnings: warnings,
    };
  }

  // Entry suitability is separate from the unchanged observation model.
  // Every anchor is historical; a live quote is never inserted into the K series.
  function entry(f, k, strength) {
    var empty = {
      model: 'firepulse-entry-1.0',
      total: null,
      coverage: 0,
      reason: '需要有效悠悠报价、可用日K及原观察分',
      factors: [],
      windows: [],
      fibonacci: null,
    };
    if (
      !f ||
      !finite(f.price, Number.MIN_VALUE) ||
      !k ||
      !k.ok2 ||
      !strength ||
      !finite(strength.total, 0)
    )
      return empty;
    var rows = k.rows
        .filter(function (r) {
          return !k.observedAt || r.t < Math.floor(k.observedAt / 86400000) * 86400000;
        })
        .slice(-180),
      price = f.price;
    if (rows.length < 60) return empty;
    if (
      rows.some(function (r) {
        return (
          !finite(r.h, Number.MIN_VALUE) ||
          !finite(r.l, Number.MIN_VALUE) ||
          !finite(r.c, Number.MIN_VALUE)
        );
      })
    )
      return empty;
    if (
      k.observedAt &&
      Math.floor(k.observedAt / 86400000) - Math.floor(rows[rows.length - 1].t / 86400000) > 7
    ) {
      empty.reason = '已收盘日K超过7天未更新，暂不计算入场分';
      return empty;
    }
    for (var gi = 1; gi < rows.length; gi++) {
      if (rows[gi].t - rows[gi - 1].t > 3 * 86400000 || rows[gi].t <= rows[gi - 1].t) {
        empty.reason = '最近位置窗口存在超过3天断档或时间倒序，暂不计算入场分';
        return empty;
      }
    }
    function quantile(a, q) {
      var sorted = a.slice().sort(function (a, b) {
        return a - b;
      });
      var ix = (sorted.length - 1) * q,
        lo = Math.floor(ix),
        hi = Math.ceil(ix);
      return sorted[lo] + (sorted[hi] - sorted[lo]) * (ix - lo);
    }
    var windows = [],
      pos = 0,
      usedWeight = 0;
    [
      [30, 0.2],
      [90, 0.3],
      [180, 0.5],
    ].forEach(function (spec) {
      if (rows.length < spec[0]) return;
      var w = rows.slice(-spec[0]),
        cs = w.map(function (r) {
          return r.c;
        });
      var low = Math.min.apply(
        null,
        w.map(function (r) {
          return r.l;
        }),
      );
      var high = Math.max.apply(
        null,
        w.map(function (r) {
          return r.h;
        }),
      );
      var rank =
        cs.reduce(function (s, c) {
          return s + (c < price ? 1 : c === price ? 0.5 : 0);
        }, 0) / cs.length;
      var coordinate = high === low ? 0.5 : (price - low) / (high - low);
      windows.push({
        period: spec[0],
        low: low,
        high: high,
        percentile: rank,
        position: coordinate,
        drawdown: 100 * (price / high - 1),
      });
      pos += spec[1] * (1 - rank);
      usedWeight += spec[1];
    });
    // Missing periods remain neutral; they never masquerade as longer history.
    var posPoints = 20 * (pos + (1 - usedWeight) * 0.5);
    var recent = rows.slice(-60),
      closes = recent.map(function (r) {
        return r.c;
      });
    var support = quantile(closes, 0.1),
      resistance = quantile(closes, 0.9),
      spread = resistance - support;
    var returns = closes.slice(1).map(function (c, i) {
      return Math.abs(Math.log(c / closes[i]));
    });
    var tolerance = Math.min(0.03, Math.max(0.005, quantile(returns, 0.5)));
    var width = Math.min(price * tolerance, spread * 0.15);
    var buy = [support - width, support + width],
      sell = [resistance - width, resistance + width];
    var zone = '区间中部',
      zonePoints = 7.5;
    if (spread <= price * 0.001) {
      zone = '窄幅区间 · 无可靠买卖区';
      buy = null;
      sell = null;
    } else if (price < buy[0]) {
      zone = '跌破支撑';
      zonePoints = 0;
    } else if (price <= buy[1]) {
      zone = '买入观察区 · 需止跌确认';
      zonePoints = 15;
    } else if (price > sell[1]) {
      zone = '突破区 · 等待回踩';
      zonePoints = 4;
    } else if (price >= sell[0]) {
      zone = '卖出观察区 · 阻力附近';
      zonePoints = 0;
    } else {
      zonePoints = 15 * clamp((sell[0] - price) / (sell[0] - buy[1]), 0, 1);
    }

    // Three bars on both sides confirm a pivot. Anchors never include the
    // unconfirmed tail; insufficient swings produce no Fibonacci claim.
    var pivots = [];
    for (var i = 3; i < rows.length - 3; i++) {
      var isHigh = true,
        isLow = true;
      for (var j = i - 3; j <= i + 3; j++)
        if (j !== i) {
          if (rows[i].h <= rows[j].h) isHigh = false;
          if (rows[i].l >= rows[j].l) isLow = false;
        }
      if (isHigh === isLow) continue;
      var pivot = {
        t: rows[i].t,
        price: isHigh ? rows[i].h : rows[i].l,
        type: isHigh ? 'high' : 'low',
      };
      var prev = pivots[pivots.length - 1];
      if (prev && prev.type === pivot.type) {
        if ((isHigh && pivot.price > prev.price) || (!isHigh && pivot.price < prev.price))
          pivots[pivots.length - 1] = pivot;
      } else pivots.push(pivot);
    }
    var fib = null,
      fibPoints = 2.5;
    if (pivots.length >= 2) {
      var a = pivots[pivots.length - 2],
        b = pivots[pivots.length - 1];
      var up = a.type === 'low',
        amplitude = Math.abs(b.price - a.price);
      if (
        amplitude / a.price >= Math.max(0.03, tolerance * 3) &&
        (up ? b.price > a.price : b.price < a.price)
      ) {
        var levels = [0.236, 0.382, 0.5, 0.618, 0.786].map(function (r) {
          return { ratio: r, price: up ? b.price - amplitude * r : b.price + amplitude * r };
        });
        var nearest = levels.reduce(function (best, x) {
          return Math.abs(x.price - price) < Math.abs(best.price - price) ? x : best;
        });
        var retracement = up ? (b.price - price) / amplitude : (price - b.price) / amplitude;
        var near = Math.abs(price - nearest.price) / price <= tolerance;
        // Up-leg retracement can support entry, down-leg rebound is resistance.
        if (near && retracement >= 0 && retracement <= 1) fibPoints = up ? 5 : 0;
        if (retracement > 1) fibPoints = 0;
        fib = {
          direction: up ? '上涨波段回撤' : '下跌波段反弹',
          start: a,
          end: b,
          levels: levels,
          retracement: retracement,
          nearest: nearest,
          near: near,
          tolerance: tolerance,
        };
      }
    }
    var factors = [
      {
        name: '原强弱分',
        points: strength.total * 0.6,
        max: 60,
        note: '原观察分 × 60%；保留趋势和流动性约束',
      },
      {
        name: '多周期价格位置',
        points: posPoints,
        max: 20,
        note: '30/90/180根日K收盘价格分位，权重20%/30%/50%；缺失周期中性占位',
      },
      {
        name: '买卖区位置',
        points: zonePoints,
        max: 15,
        note: '近60根收盘10%/90%分位作支撑/阻力，动态容差带；' + zone,
      },
      {
        name: '斐波拉契位置',
        points: fibPoints,
        max: 5,
        note: fib
          ? fib.direction +
            '；最近 ' +
            (fib.nearest.ratio * 100).toFixed(1) +
            '% 档' +
            (fib.near ? '，处于容差内' : '，未接近')
          : '无有效已确认波段，中性占位',
      },
    ];
    var raw = factors.reduce(function (s, x) {
        return s + x.points;
      }, 0),
      result = raw,
      caps = [];
    function cap(limit, why) {
      if (result > limit) {
        result = limit;
        caps.push(why + '，封顶' + limit);
      }
    }
    var trend = strength.factors[0].points + strength.factors[1].points;
    if (trend <= 24) cap(49, '双动量仍弱，低位不等于止跌');
    else if (trend < 36) cap(64, '双动量尚未确认转强');
    if (zone === '跌破支撑') cap(39, '支撑失守');
    if (zone.indexOf('突破区') === 0) cap(64, '突破后等待回踩');
    if (zone.indexOf('卖出观察区') === 0) cap(59, '接近阻力，不追涨');
    if (f.v === 0) cap(45, '当前统计成交为零');
    var coverage = Math.round(
      strength.coverage * 0.6 + usedWeight * 20 + (spread > price * 0.001 ? 15 : 0) + (fib ? 5 : 0),
    );
    if (coverage < 80) cap(64, '入场因子覆盖不足80%');
    return {
      model: empty.model,
      total: Math.round(clamp(result, 0, 100)),
      raw: raw,
      coverage: coverage,
      regime: result >= 65 ? '可关注入场' : result >= 40 ? '等待确认' : '暂缓入场',
      price: price,
      asOf: new Date(rows[rows.length - 1].t).toISOString().slice(0, 10),
      zone: zone,
      buyZone: buy,
      sellZone: sell,
      windows: windows,
      fibonacci: fib,
      factors: factors,
      caps: caps,
      reason: '买卖区是历史价格观察带；未计手续费、滑点与7天交易锁，分数不是收益概率',
    };
  }

  // Reconstruct the chosen day's close using only rows available by that close.
  // No live quote, supply, current volume or current score enters this API.
  var HISTORY_DAY = 86400000;
  function historyDate(date) {
    if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
    var t = Date.parse(date + 'T00:00:00Z');
    return Number.isFinite(t) && new Date(t).toISOString().slice(0, 10) === date ? t : null;
  }
  function historyPrefix(payload, end) {
    if (!payload || payload.code !== 200 || !Array.isArray(payload.data))
      throw Error('没有可用的悠悠历史日K');
    if (payload.data.length > 10000) throw Error('历史日K记录过多');
    var selected = payload.data.filter(function (row) {
      if (!Array.isArray(row)) return false;
      var t = n(row[0]);
      if (t === null) return false;
      if (t < 1e12) t *= 1000;
      return t >= 0 && t < end;
    });
    // Keep bad dated rows so kchart's tail-integrity rejection still applies.
    selected.sort(function (a, b) {
      var x = n(a[0]),
        y = n(b[0]);
      return (x < 1e12 ? x * 1000 : x) - (y < 1e12 ? y * 1000 : y);
    });
    return kchart({ code: 200, data: selected }, end);
  }
  function historicalScore(payload, date, now) {
    if (now === undefined) now = Date.now();
    var fail = { ok: false, date: date, reason: '' },
      t = historyDate(date);
    if (t === null) {
      fail.reason = '请输入有效日期（YYYY-MM-DD）';
      return fail;
    }
    if (t + HISTORY_DAY > now) {
      fail.reason = '只能选择已收盘的UTC历史日期，不能选择今天或未来';
      return fail;
    }
    var k;
    try {
      k = historyPrefix(payload, t + HISTORY_DAY);
    } catch (e) {
      fail.reason = e.message;
      return fail;
    }
    if (!k.rows.length || k.asOf !== date) {
      fail.reason = '所选日期没有有效日K，不使用邻近日替代';
      return fail;
    }
    if (!k.ok2) {
      fail.reason = k.endCorrupt
        ? '所选日期末端日K异常，拒绝评分'
        : '截至所选日期不足60根有效日K，无法重建评分';
      return fail;
    }
    var last = k.rows[k.rows.length - 1],
      byDay = {};
    k.rows.forEach(function (r) {
      byDay[r.day] = r;
    });
    function change(days) {
      var prior = byDay[new Date(t - days * HISTORY_DAY).toISOString().slice(0, 10)];
      return prior ? (last.c / prior.c - 1) * 100 : null;
    }
    var fields = {
      source: 'historical-k',
      price: last.c,
      d1: change(1),
      d7: change(7),
      d30: change(30),
      s: null,
      v: last.v,
      volumeBasis: '历史日K成交量（全平台代理）',
      priceBasis: '所选日悠悠在售收盘价',
      changeBasis: 'historical-youpin-proxy',
    };
    var strength = score(fields, k);
    strength.quality = '历史重建 · 部分因子使用代理或缺失';
    strength.factors[0].name = '历史涨跌代理';
    strength.factors[0].note =
      '悠悠收盘重建1/7/30自然日涨跌；并非当时的FirePulse参考价快照；缺少对应日则中性占位';
    strength.factors[3].note = '历史日K成交 ' + last.v + '；代替实时滚动24h成交，时间口径不同';
    strength.factors[4].note = '历史存世量不可得，换手因子5分中性占位；不使用今天存世量';
    strength.warnings.unshift(
      '历史重建评分：公式与当前策略一致，但涨跌及成交使用历史日K代理，无法精确还原当时实盘分数。',
    );
    var e = entry(fields, k, strength);
    if (e.total === null) {
      fail.reason = e.reason;
      return fail;
    }
    e.factors[0].name = '重建强弱分';
    e.factors[0].note = '重建观察分 × 60%；历史参考价/滚动成交/存世量不完整';
    return {
      ok: true,
      mode: 'historical-reconstruction',
      date: date,
      evaluatedAt: new Date(t + HISTORY_DAY).toISOString(),
      timing: '所选UTC日期收盘后（次日北京时间08:00），非当天开盘前信号',
      strategy: { observation: MODEL_ID, entry: e.model },
      fields: fields,
      score: strength,
      entry: e,
      history: { firstDay: k.rows[0].day, lastDay: k.asOf, rows: k.rows.length },
      limitations: [
        '历史涨跌使用悠悠收盘代理，非历史参考价快照',
        '历史日K成交代替当时滚动24h成交，时间口径不同',
        '历史存世量缺失，换手因子中性占位',
        '历史K线可能被数据源事后修订，无法保证当时接口版本完全一致',
        '仅核验规则，不能从单个日期表现证明策略有效',
      ],
    };
  }

  // Deliberately separate from historicalScore: future prices are outcome-only.
  function historicalOutcomes(payload, date, now) {
    if (now === undefined) now = Date.now();
    var t = historyDate(date),
      empty = { date: date, periods: [], reason: '' };
    if (t === null || t + HISTORY_DAY > now) {
      empty.reason = '所选日期未收盘或无效';
      return empty;
    }
    var available;
    try {
      available = historyPrefix(payload, Math.floor(now / HISTORY_DAY) * HISTORY_DAY);
    } catch (e) {
      empty.reason = e.message;
      return empty;
    }
    var byDay = {};
    available.rows.forEach(function (r) {
      byDay[r.day] = r;
    });
    if (!byDay[date]) {
      empty.reason = '所选日缺少有效收盘价';
      return empty;
    }
    var base = byDay[date].c;
    return {
      date: date,
      baseline: base,
      priceBasis: '悠悠在售收盘价',
      note: '后续价格变化仅用于核验，不参与评分；不是可执行交易收益，未计成本与交易锁',
      periods: [7, 14, 30].map(function (days) {
        var target = t + days * HISTORY_DAY,
          key = new Date(target).toISOString().slice(0, 10);
        var row = byDay[key],
          mature = target + HISTORY_DAY <= now;
        var result = {
          days: days,
          targetDate: key,
          close: null,
          changePct: null,
          maxDrawdownPct: null,
          reason: '',
        };
        if (!mature) {
          result.reason = '观察期尚未结束';
          return result;
        }
        if (!row) {
          result.reason = '到期日缺少有效日K';
          return result;
        }
        result.close = row.c;
        result.changePct = (row.c / base - 1) * 100;
        var peak = base,
          dd = 0;
        for (var i = 1; i <= days; i++) {
          var r = byDay[new Date(t + i * HISTORY_DAY).toISOString().slice(0, 10)];
          if (!r) {
            result.reason = '区间存在缺日，不计算最大收盘回撤';
            return result;
          }
          peak = Math.max(peak, r.c);
          dd = Math.min(dd, (r.c / peak - 1) * 100);
        }
        result.maxDrawdownPct = dd;
        return result;
      }),
    };
  }

  // -- batch walk-forward validation (v1.9.1) --------------------------------
  // Replays historicalScore on every qualifying UTC close in the payload and
  // pairs each reconstructed score with the (outcome-only) forward 7/14/30-day
  // changes. A single replayed date can never answer "does this score have
  // any discrimination at all?" — these batch statistics can.

  function meanOf(a) {
    return (
      a.reduce(function (s, x) {
        return s + x;
      }, 0) / a.length
    );
  }
  function medianOf(a) {
    var sorted = a.slice().sort(function (x, y) {
      return x - y;
    });
    var mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
  }
  // Ranks with averaged ties; Spearman correlation = Pearson correlation on ranks.
  function rankOf(a) {
    var order = a
      .map(function (x, i) {
        return [x, i];
      })
      .sort(function (p, q) {
        return p[0] - q[0];
      });
    var ranks = new Array(a.length);
    for (var i = 0; i < order.length;) {
      var j = i;
      while (j + 1 < order.length && order[j + 1][0] === order[i][0]) j++;
      var avg = (i + j) / 2 + 1;
      for (var k = i; k <= j; k++) ranks[order[k][1]] = avg;
      i = j + 1;
    }
    return ranks;
  }
  function spearman(xs, ys) {
    if (xs.length < 3) return null;
    var rx = rankOf(xs),
      ry = rankOf(ys);
    var mx = meanOf(rx),
      my = meanOf(ry);
    var num = 0,
      dx = 0,
      dy = 0;
    for (var i = 0; i < rx.length; i++) {
      var a = rx[i] - mx,
        b = ry[i] - my;
      num += a * b;
      dx += a * a;
      dy += b * b;
    }
    if (dx <= 0 || dy <= 0) return null;
    return num / Math.sqrt(dx * dy);
  }
  function roundTo(x, digits) {
    if (x === null || x === undefined || !Number.isFinite(x)) return null;
    var p = Math.pow(10, digits);
    return Math.round(x * p) / p;
  }

  function backtest(payload, opts, now) {
    if (opts === undefined) opts = {};
    if (now === undefined) now = Date.now();
    var fail = { ok: false, reason: '' };
    var all;
    try {
      all = historyPrefix(payload, Math.floor(now / HISTORY_DAY) * HISTORY_DAY);
    } catch (e) {
      fail.reason = e.message;
      return fail;
    }
    var step = Math.max(1, Math.floor(n(opts.step) || 1));
    var samples = [],
      rejected = 0;
    for (var i = 0; i < all.rows.length; i += step) {
      var date = all.rows[i].day;
      var s = historicalScore(payload, date, now);
      if (!s.ok || !s.score || s.score.total === null || s.score.total === undefined) {
        rejected++;
        continue;
      }
      var o = historicalOutcomes(payload, date, now);
      var fwd = {},
        mature = true;
      o.periods.forEach(function (p) {
        if (p.changePct === null || p.changePct === undefined) mature = false;
        else fwd['d' + p.days] = p.changePct;
      });
      // Only fully matured observations are mutually comparable.
      if (!mature) {
        rejected++;
        continue;
      }
      samples.push({
        date: date,
        score: s.score.total,
        entry: s.entry ? s.entry.total : null,
        d7: fwd.d7,
        d14: fwd.d14,
        d30: fwd.d30,
      });
    }
    if (samples.length < 5) {
      fail.reason =
        '可比较的已到期样本不足（' +
        samples.length +
        '个）；需要60根有效日K的历史深度再加30天完整观察期';
      fail.samples = samples.length;
      fail.rejected = rejected;
      return fail;
    }
    function column(key) {
      return samples.map(function (s) {
        return s[key];
      });
    }
    function horizonStats(key) {
      var v = column(key);
      return {
        n: v.length,
        avg: roundTo(meanOf(v), 2),
        median: roundTo(medianOf(v), 2),
        winRate: roundTo(
          (100 *
            v.filter(function (x) {
              return x > 0;
            }).length) /
            v.length,
          1,
        ),
        ic: roundTo(spearman(column('score'), v), 3),
      };
    }
    var sorted = samples.slice().sort(function (a, b) {
      return a.score - b.score;
    });
    var third = Math.max(1, Math.floor(samples.length / 3));
    var lowAvg30 = meanOf(
      sorted.slice(0, third).map(function (s) {
        return s.d30;
      }),
    );
    var highAvg30 = meanOf(
      sorted.slice(-third).map(function (s) {
        return s.d30;
      }),
    );
    var edges = [
      { label: '<40', lo: null, hi: 40 },
      { label: '40-49', lo: 40, hi: 50 },
      { label: '50-59', lo: 50, hi: 60 },
      { label: '60-69', lo: 60, hi: 70 },
      { label: '≥70', lo: 70, hi: null },
    ];
    var buckets = edges.map(function (e) {
      var members = samples.filter(function (s) {
        return (e.lo === null || s.score >= e.lo) && (e.hi === null || s.score < e.hi);
      });
      function avgKey(key) {
        return members.length
          ? roundTo(
              meanOf(
                members.map(function (s) {
                  return s[key];
                }),
              ),
              2,
            )
          : null;
      }
      return {
        range: e.label,
        n: members.length,
        avgD7: avgKey('d7'),
        avgD14: avgKey('d14'),
        avgD30: avgKey('d30'),
        winRate30: members.length
          ? roundTo(
              (100 *
                members.filter(function (s) {
                  return s.d30 > 0;
                }).length) /
                members.length,
              1,
            )
          : null,
      };
    });
    return {
      ok: true,
      model: MODEL_ID,
      range: { first: samples[0].date, last: samples[samples.length - 1].date },
      step: step,
      sampleCount: samples.length,
      rejected: rejected,
      horizons: { d7: horizonStats('d7'), d14: horizonStats('d14'), d30: horizonStats('d30') },
      spread30TopBottomTercile: {
        bottomAvg: roundTo(lowAvg30, 2),
        topAvg: roundTo(highAvg30, 2),
        diff: roundTo(highAvg30 - lowAvg30, 2),
      },
      buckets: buckets,
      series: opts.keepSeries ? samples : null,
      note:
        '批量回放同一公式的历史重建分数，对照后续7/14/30天悠悠收盘涨跌。' +
        '相邻日期样本相关、观察窗重叠，统计量只供方向判断，不构成显著性检验。' +
        'Spearman秩相关IC接近0表示分数与未来收益没有单调关系；' +
        '不是可执行收益，未计手续费、滑点与7天交易锁。',
    };
  }

  var api = {
    MODEL_ID: MODEL_ID,
    PARAMS: {
      weights: {
        snapshotMomentum: 35,
        kTrend: 25,
        obvAgreement: 15,
        activity: 15,
        turnoverProxy: 10,
      },
      momentumWeights: MOMENTUM_PERIODS.map(function (p) {
        return [p[0], p[1]];
      }),
      momentumWidth: MOMENTUM_WIDTH,
      kMinRows: K_MIN_ROWS,
      kStaleDays: K_STALE_DAYS,
      rsiPeriod: RSI_PERIOD,
      obvWindow: OBV_WINDOW,
      obvNzMin: OBV_NZ_MIN,
      obvAgreeScale: OBV_AGREE_SCALE,
      obvAdoptWidth: OBV_ADOPT_WIDTH,
      divergeLo: DIVERGE_LO,
      activityCap: ACTIVITY_CAP,
      turnoverLo: TURNOVER_LO,
      turnoverHi: TURNOVER_HI,
      bandHi: BAND_HI,
      bandLo: BAND_LO,
      mom60GateHi: MOM60_GATE_HI,
      mom60GateLo: MOM60_GATE_LO,
      v0Cap: V0_CAP,
    },
    n: n,
    clean: clean,
    route: route,
    sanitize: sanitize,
    firepulse: firepulse,
    youpinBasis: youpinBasis,
    kchart: kchart,
    dom: dom,
    parseCount: parseCount,
    parseSignedPct: parseSignedPct,
    trendImpliedChange: trendImpliedChange,
    score: score,
    entry: entry,
    historicalScore: historicalScore,
    historicalOutcomes: historicalOutcomes,
    backtest: backtest,
  };
  root.MarketLensItem = api;
  if (typeof module !== 'undefined') module.exports = api;
})(globalThis);
