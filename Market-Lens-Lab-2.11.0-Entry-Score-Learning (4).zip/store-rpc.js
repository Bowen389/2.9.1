/* Chrome messaging uses JSON: explicitly preserve Maps, typed arrays, undefined and non-finite numbers. */
(function(root) {
  'use strict';
  const methods = ['learningData','saveLearningBatch','saveLearningOutcomes','clearLearning','entryStudies','saveEntryStudy','clearEntryStudies','researchState','saveExperiment','addResearchQuotes','addShadow','shadowRecords','exportResearch','clearResearch','bytesInUse','putK','getK','getKMany','flushIdx','allK','kIndex','isFresh','removeK','clearK','putMarket','getMarket','directory','putDirectory','settings','saveSettings','registry','addCandidate','activate','rollback','removeCandidate','addSnapshot','snapshots','addView','views','holdings','addHolding','updateHolding','removeHolding','putXsec','getXsec','exportAll','exportBackup','importAll','resetAll'];
  function encode(x) {
    if (x === undefined || typeof x === 'function') return ['u'];
    if (typeof x === 'number' && !Number.isFinite(x)) return ['n', String(x)];
    if (x === null || typeof x !== 'object') return ['v', x];
    if (ArrayBuffer.isView(x)) { const bytes=new Uint8Array(x.buffer,x.byteOffset,x.byteLength); let str=''; for(let i=0;i<bytes.length;i+=0x8000)str+=String.fromCharCode.apply(null,bytes.subarray(i,i+0x8000)); return ['b',x.constructor.name,btoa(str)]; }
    if (x instanceof Map) return ['m', Array.from(x, ([k,v]) => [encode(k),encode(v)])];
    if (Array.isArray(x)) return ['a', x.map(encode)];
    return ['o', Object.keys(x).filter(k => !['__proto__','constructor','prototype'].includes(k)).map(k => [k,encode(x[k])])];
  }
  function decode(x) {
    if (!Array.isArray(x)) throw Error('无效存储消息');
    switch(x[0]) {
      case 'u': return undefined;
      case 'v': return x[1];
      case 'n': return Number(x[1]);
      case 'a': return x[1].map(decode);
      case 'm': return new Map(x[1].map(([k,v]) => [decode(k),decode(v)]));
      case 'b': {
        const types = { Float32Array, Float64Array, Uint8Array, Uint16Array, Int32Array, Uint32Array };
        const Type=types[x[1]];if(!Type||typeof x[2]!=='string')throw Error('无效缓存数组类型');
        const str=atob(x[2]),bytes=Uint8Array.from(str,c=>c.charCodeAt(0));if(bytes.byteLength%Type.BYTES_PER_ELEMENT)throw Error('无效缓存字节长度');return new Type(bytes.buffer);
      }
      case 't': {
        const types = { Float32Array, Float64Array, Uint8Array, Uint16Array, Int32Array, Uint32Array };
        if (!types[x[1]]) throw Error('无效缓存数组类型');
        return types[x[1]].from(x[2].map(decode));
      }
      case 'o': return Object.fromEntries(x[1].filter(([k]) => !['__proto__','constructor','prototype'].includes(k)).map(([k,v]) => [k,decode(v)]));
      default: throw Error('无效存储消息');
    }
  }
  root.MarketLensStoreRPC = { methods, encode, decode };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.MarketLensStoreRPC;
})(typeof globalThis !== 'undefined' ? globalThis : this);
