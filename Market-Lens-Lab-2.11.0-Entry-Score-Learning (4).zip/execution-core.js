/* 2.10.0 quote-based execution accounting. NOT a fill simulator.
   Rank first using signal information; missing future prices never replace a selected item.
   Next book opens only after this book is liquidated; missing exits remain unresolved. */
(function (root) {
  "use strict";
  const DAY = 86400000,
    fin = Number.isFinite,
    mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
  const median = (a) => {
    a = a.slice().sort((x, y) => x - y);
    const m = a.length >> 1;
    return a.length ? (a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2) : null;
  };
  const date = (d) => new Date(d * DAY).toISOString().slice(0, 10);
  const netReturn = (gross, fee = 0.01, buySlip = 0, sellSlip = 0) =>
    ((1 + gross) * (1 - sellSlip) * (1 - fee)) / (1 + buySlip) - 1;
  function nonOverlap(days, h) {
    let last = -Infinity;
    return days.filter((d) => {
      if (d - last < h) return false;
      last = d;
      return true;
    });
  }
  function realClose(s, d) {
    const i = s ? d - s.day0 : -1;
    return s && s.ok && i >= 0 && i < s.n && s.real[i] && s.c[i] > 0
      ? s.c[i]
      : null;
  }
  function mark(s, d, fallback) {
    if (!s || !s.ok) return fallback;
    let i = Math.min(s.n - 1, d - s.day0);
    while (i >= 0 && !s.real[i]) i--;
    return i >= 0 ? s.c[i] : fallback;
  }
  function groupOf(item) {
    const name = String((item && item.name) || "");
    const family = String(
      (item && item.family) || name.split("|")[0] || "unknown",
    );
    return {
      family,
      series: name
        .replace(
          /\s*[（(](崭新出厂|略有磨损|久经沙场|破损不堪|战痕累累)[)）]\s*$/,
          "",
        )
        .trim(),
    };
  }
  function selectDiversified(arr, items, n, opts) {
    const o = opts || {},
      families = new Map(),
      series = new Map(),
      out = [];
    for (const a of arr) {
      const g = groupOf(items[a.it]),
        fc = families.get(g.family) || 0,
        sc = series.get(g.series) || 0;
      if (o.maxFamilyWeight && (fc + 1) / n > o.maxFamilyWeight + 1e-9)
        continue;
      if (o.maxSeriesWeight && (sc + 1) / n > o.maxSeriesWeight + 1e-9)
        continue;
      out.push(a);
      families.set(g.family, fc + 1);
      series.set(g.series, sc + 1);
      if (out.length >= n) break;
    }
    return out;
  }
  function simulate(panel, scoreFn, opts) {
    const o = Object.assign(
      {
        h: 14,
        topN: 10,
        cost: 0.01,
        buySlip: 0,
        sellSlip: 0,
        minN: 25,
        days: panel.days,
        lag: panel.lag === undefined ? 1 : panel.lag,
      },
      opts || {},
    );
    if (
      !Number.isInteger(o.h) ||
      o.h < 7 ||
      !Number.isInteger(o.topN) ||
      o.topN < 1 ||
      ![o.cost, o.buySlip, o.sellSlip].every((x) => fin(x) && x >= 0 && x < 1)
    )
      throw Error("执行参数无效");
    const days = Array.from(new Set(o.days)).sort((a, b) => a - b),
      sources = panel.sources || null;
    const asOf = fin(panel.asOf)
      ? panel.asOf
      : days.length
        ? days[days.length - 1] + o.lag + o.h
        : 0;
    const source = (i) => sources && sources[i];
    const ranked = (d) =>
      (panel.byDay.get(d) || [])
        .map((i) => panel.rows[i])
        .filter((r) => !o.filter || o.filter(r))
        .map((r) => ({ row: r, it: r.it, score: scoreFn(r) }))
        .filter((a) => fin(a.score))
        .sort((a, b) => b.score - a.score || a.it - b.it);
    function book(kind) {
      let equity = 1,
        available = -Infinity,
        inCash = 0,
        unfilled = 0,
        unresolved = 0,
        delayed = 0,
        wins = 0,
        picks = 0,
        missingMarks = 0;
      const periods = [],
        curve = [],
        positions = [];
      let curveLast = null;
      const point = (d, v) => {
        if (curveLast === d) {
          curve[curve.length - 1].v = v;
        } else {
          curve.push({ d, v });
          curveLast = d;
        }
      };
      for (const d of days) {
        const entry = d + o.lag,
          target = entry + o.h;
        if (entry < available || target > asOf) continue;
        const arr = ranked(d);
        if (arr.length < o.minN) continue;
        const chosen =
          kind === "top"
            ? o.select
              ? o.select(arr, d)
              : selectDiversified(arr, panel.items || [], o.topN, o)
            : arr;
        const slots = kind === "top" ? o.topN : chosen.length,
          invest = kind !== "top" || !o.gate || !!o.gate(d);
        const start = equity;
        let end = target,
          unknown = 0;
        const deals = [];
        if (invest) {
          for (const a of chosen) {
            const s = source(a.it),
              buy = s ? realClose(s, entry) : 1;
            const amt = start / slots;
            if (buy === null) {
              unfilled++;
              deals.push({ it: a.it, status: "unfilled", entry, target, amt });
              continue;
            }
            let exit = target,
              sell = null;
            if (s) {
              while (exit <= asOf) {
                sell = realClose(s, exit);
                if (sell !== null) break;
                exit++;
              }
            } else {
              const y = a.row.y && a.row.y[o.h];
              sell = fin(y) ? Math.exp(y) : null;
            }
            if (sell === null) {
              unknown++;
              unresolved++;
              exit = null;
              end = asOf;
            } else {
              end = Math.max(end, exit);
              if (exit > target) delayed++;
            }
            const ret =
              sell === null
                ? null
                : netReturn(sell / buy - 1, o.cost, o.buySlip, o.sellSlip);
            if (ret !== null) {
              picks++;
              if (ret > 0) wins++;
            }
            deals.push({
              it: a.it,
              status: exit === null ? "unresolved" : "sold",
              entry,
              target,
              exit,
              buy,
              sell,
              ret,
              amt,
              s,
            });
          }
        } else inCash++;
        if (curve.length) {
          for (let t = curveLast + 1; t < entry; t++) point(t, start);
        } else point(entry - 1, start);
        if (sources) {
          for (let t = entry; t <= end; t++) {
            let value = start;
            for (const x of deals) {
              if (x.status === "unfilled") continue;
              let gross;
              if (x.exit !== null && t >= x.exit) gross = 1 + x.ret;
              else {
                const px = mark(x.s, t, x.buy);
                if (realClose(x.s, t) === null) missingMarks++;
                gross =
                  1 + netReturn(px / x.buy - 1, o.cost, o.buySlip, o.sellSlip);
              }
              value += x.amt * (gross - 1);
            }
            point(t, value);
          }
        } else {
          let value = start;
          for (const x of deals)
            if (x.ret !== null && x.ret !== undefined) value += x.amt * x.ret;
          point(end, value);
        }
        equity = curve[curve.length - 1].v;
        const returns = deals.filter((x) => fin(x.ret)).map((x) => x.ret);
        periods.push({
          d: date(d),
          entry: date(entry),
          target: date(target),
          exit: unknown ? null : date(end),
          ret: unknown ? null : equity / start - 1,
          markedRet: equity / start - 1,
          med:
            returns.length === deals.length && returns.length
              ? median(returns)
              : null,
          invest,
          picks: chosen.map((a) => a.it),
          unresolved: unknown,
          unfilled: deals.filter((x) => x.status === "unfilled").length,
          cashWeight:
            1 - deals.filter((x) => x.status !== "unfilled").length / slots,
        });
        positions.push(...deals.map(({ s, ...x }) => x));
        available = unknown ? Infinity : end;
      }
      let peak = 1,
        dd = 0;
      for (const p of curve) {
        peak = Math.max(peak, p.v);
        dd = Math.min(dd, p.v / peak - 1);
      }
      const elapsed = curve.length ? curve[curve.length - 1].d - curve[0].d : 0;
      return {
        periods,
        curve,
        positions,
        inCash,
        unfilled,
        unresolved,
        delayed,
        missingMarks,
        stats: {
          total: unresolved ? null : equity - 1,
          markedTotal: equity - 1,
          annual:
            !unresolved && elapsed >= 30 && equity > 0
              ? Math.pow(equity, 365 / elapsed) - 1
              : null,
          maxDD: sources ? dd : null,
          endpointDD: dd,
          elapsedDays: elapsed,
          avg: mean(periods.map((p) => p.ret).filter(fin)),
          medianChain: null,
          pickWinRate: picks ? wins / picks : null,
        },
      };
    }
    const top = book("top"),
      uni = book("universe");
    const first = top.curve.length ? top.curve[0].d : null,
      last = top.curve.length ? top.curve[top.curve.length - 1].d : null;
    const market = panel.marketSeries;
    let mtotal = null;
    if (first !== null && market) {
      const a = realClose(market, first + 1),
        b = realClose(market, last);
      if (a && b) mtotal = b / a - 1;
    }
    const uc = new Map(uni.curve.map((p) => [p.d, p.v]));
    let uv = 1;
    const curve = top.curve.map((p) => {
      if (uc.has(p.d)) uv = uc.get(p.d);
      const base = market && realClose(market, first + 1),
        v = market && realClose(market, p.d);
      return {
        d: date(p.d),
        top: p.v,
        uni: uv,
        mkt: !market ? null : p.d < first + 1 ? 1 : base && v ? v / base : null,
      };
    });
    const um = new Map(uni.periods.map((p) => [p.d, p]));
    const comparable = top.periods.filter(
      (p) =>
        p.invest &&
        p.ret !== null &&
        um.has(p.d) &&
        um.get(p.d).ret !== null &&
        um.get(p.d).exit === p.exit,
    );
    return {
      version: "execution-2.10",
      basis: "日K报价代理，非真实成交回测",
      h: o.h,
      topN: o.topN,
      cost: o.cost,
      buySlip: o.buySlip,
      sellSlip: o.sellSlip,
      periods: top.periods.length,
      inCash: top.inCash,
      curve,
      detail: top.periods.map((p) => ({
        ...p,
        top: p.ret,
        uni: um.has(p.d) ? um.get(p.d).ret : null,
        mkt: null,
      })),
      positions: top.positions,
      top: top.stats,
      universe: uni.stats,
      market: {
        total: mtotal,
        annual:
          mtotal !== null && top.stats.elapsedDays >= 30
            ? Math.pow(1 + mtotal, 365 / top.stats.elapsedDays) - 1
            : null,
      },
      beatUniverseRate: comparable.length
        ? comparable.filter((p) => p.ret > um.get(p.d).ret).length /
          comparable.length
        : null,
      audit: {
        unresolved: top.unresolved,
        unfilled: top.unfilled,
        delayed: top.delayed,
        missingMarks: top.missingMarks,
        universeUnresolved: uni.unresolved,
        dailyMarks: !!sources,
        comparablePeriods: comparable.length,
        eligibility: "signal-only",
        missingExit: "delay-until-real-quote; unresolved blocks reinvestment",
        limitations:
          "报价不保证可成交；缺日估值沿用最近真实报价；等金额允许分数数量；未模拟盘口容量或涨跌停。",
      },
    };
  }
  const api = {
    netReturn,
    nonOverlap,
    realClose,
    groupOf,
    selectDiversified,
    simulate,
  };
  root.MarketLensExecution = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
