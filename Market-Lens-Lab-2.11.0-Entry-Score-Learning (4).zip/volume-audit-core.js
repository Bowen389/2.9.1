/* Audit existing parsed volume observations; never fills a missing observation. */
(function(root){
'use strict';
const day=d=>new Date(d*86400000).toISOString().slice(0,10);
function audit(s,asOf=Math.floor(Date.now()/86400000)-1){
 const info={source:'skin_k_chart 第6字段 / 已解析日K缓存',basis:'全平台成交量代理，非悠悠独立成交量',verification:'按现有字段解析；本商品量的完整统计范围未独立验证',asOf:day(asOf)};
 const fail=reason=>({...info,ok:false,reason});
 if(!s?.ok||!Number.isInteger(s.day0)||!s.v||!s.real)return fail('没有可审计的日K缓存。');
 const j=asOf-s.day0;if(j<32||j>=s.n)return fail('截至决策日不足33个日历日，不能计算完整基准。');
 const rows=[];for(let i=j-32;i<=j;i++){if(s.real[i]!==1||!Number.isFinite(s.v[i])||s.v[i]<0)return fail('33日量窗口包含缺日或无效量，未填零、未跨缺日拼接。');rows.push({day:day(s.day0+i),volume:s.v[i]});}
 const base=rows.slice(0,30).map(x=>x.volume).sort((a,b)=>a-b),baseMedian30=(base[14]+base[15])/2,recentMean3=rows.slice(-3).reduce((a,b)=>a+b.volume,0)/3;
 return {...info,ok:true,baseStart:rows[0].day,baseEnd:rows[29].day,recentStart:rows[30].day,recentEnd:rows[32].day,lastVolume:rows[32].volume,baseMedian30,recentMean3,relativeVolume:baseMedian30>=1?recentMean3/baseMedian30:null,zeroDays30:rows.slice(-30).filter(x=>x.volume===0).length,rows};
}
const api={audit};root.MarketLensVolumeAudit=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
