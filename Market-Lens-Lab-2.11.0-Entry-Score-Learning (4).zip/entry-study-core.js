/* Candidate entry conditions, not trained models. No returns or live trading. */
(function(root){
'use strict';
const VERSION='entry-abc-0.1',finite=x=>typeof x==='number'&&Number.isFinite(x);
function compare(row,signal){
 const ready=['trigger','volume','price','quote','insufficient'].includes(signal.code),priceOK=['trigger','volume'].includes(signal.code);
 const A={pass:priceOK,reason:priceOK?'原候选与价格门槛通过':'未通过完整候选/行情/价格条件，或旧规则数据不足'},B={pass:signal.code==='trigger',reason:signal.summary};
 // A does not require a successful lab evaluation: caller supplies independent price eligibility.
 if(typeof row.studyPriceReady==='boolean'){A.pass=row.studyPriceReady;A.reason=A.pass?'原排名/大盘/覆盖/有效报价及价格上限通过':'原排名/大盘/覆盖/有效报价或价格上限未通过';}
 const C={pass:false,reason:'研究条件未通过'},f=row.shapeEvidence?.features||{},branch=row.shapeEvidence?.branch;
 if(!A.pass||!ready){C.reason='先满足原候选与完整价格门槛。';}
 else if(!row.deepOk||!row.volumeEvidence?.ok||row.eligible!==true){C.reason='旧规则或33日量证据不足，不判定C通过。';}
 else if(branch==='breakout'){
  C.pass=finite(row.close)&&finite(f.high20)&&row.close>f.high20&&finite(row.relativeVolume)&&row.relativeVolume>=1.5;C.reason='突破候选：完整日收盘高于此前20根最高收盘，且相对量≥1.5。';
 }else if(branch==='pullback'){
  C.pass=finite(row.shapeEvidence.trend)&&row.shapeEvidence.trend>=50&&finite(f.ma5)&&finite(row.close)&&row.close>=f.ma5&&finite(f.r3)&&f.r3>0&&finite(row.relativeVolume)&&row.relativeVolume>=0.5&&row.relativeVolume<=1;C.reason='回调候选：趋势分≥50、收盘≥MA5、3日动量>0，且相对量在0.5–1之间。';
 }else if(branch==='reversal'){
  C.pass=f.confirmed===true&&finite(f.r3)&&finite(f.prior3)&&f.r3>f.prior3&&finite(row.relativeVolume)&&row.relativeVolume>=1;C.reason='止跌候选：旧规则恢复确认、3日动量改善，且相对量≥1。';
 }else C.reason='未知形态，不判定C通过。';
 return {version:VERSION,A,B,C,warning:'C阈值为预先写定的研究假设，未证明优于A/B；三组均不修改正式推荐或手动记账。'};
}
const api={VERSION,compare};root.MarketLensEntryStudy=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
