/* Frozen features and separate first-observed daily-close proxy outcomes. No training or network. */
(function(root){'use strict';
const VERSION='entry-learning-1.0',DAY=86400000,HS=[7,14,30];
const day=s=>Math.floor(Date.parse(s+'T00:00:00Z')/DAY),str=d=>new Date(d*DAY).toISOString().slice(0,10);
const POLICY='冻结日（北京时间日期）之后的下一自然日日K收盘作统一入场代理；第7/14/30自然日收盘退出；仅已结束UTC日且real=1；缺日不补价、不顺延；卖出单边费率冻结；非可执行收益';
function outcomes(batch,cache,now=Date.now()){
 const result=[],entry=day(batch.captureDay)+1,completed=Math.floor(now/DAY)-1;
 for(const row of batch.rows)for(const h of HS){
  const exit=entry+h,base={batchKey:batch.key,id:String(row.id),h,entryDay:str(entry),exitDay:str(exit),fee:batch.fee,policy:POLICY,status:'pending',net:null,gross:null,entryPrice:null,exitPrice:null,observedAt:new Date(now).toISOString()};
  if(exit>completed){result.push(base);continue;}
  const rec=cache instanceof Map?cache.get(String(row.id)):cache[String(row.id)],s=rec?.series||rec;
  const i=s?entry-s.day0:-1,j=s?exit-s.day0:-1;
  if(!s?.ok||i<0||j>=s.n||s.real[i]!==1||s.real[j]!==1||!(s.c[i]>0)||!(s.c[j]>0)||!Number.isFinite(s.c[i])||!Number.isFinite(s.c[j])){result.push({...base,status:'missing'});continue;}
  result.push({...base,status:'matured',entryPrice:s.c[i],exitPrice:s.c[j],gross:s.c[j]/s.c[i]-1,net:s.c[j]*(1-batch.fee)/s.c[i]-1,cacheFetchedAt:rec?.fetchedAt||null});
 }
 return result;
}
function csv(data){
 const cols=['batchKey','capturedAt','signalDay','modelId','id','name','score','state','reason','selPct','relativeVolume','quotePrice','quoteAt','h','status','entryDay','exitDay','entryPrice','exitPrice','gross','net','fee','scoreVersion'];
 const out=new Map(data.outcomes.map(o=>[o.batchKey+'|'+o.id+'|'+o.h,o]));
 const cell=v=>'"'+String(v??'').replace(/^[=+@\-\t\r]/,"'$&").replace(/"/g,'""')+'"';
 const lines=[cols.join(',')];for(const b of data.batches)for(const r of b.rows)for(const h of HS){const o=out.get(b.key+'|'+r.id+'|'+h)||{status:'not_settled'};const v={...o,batchKey:b.key,capturedAt:b.capturedAt,signalDay:b.signalDay,modelId:b.model.id,id:r.id,name:r.name,score:r.entry.score,state:r.entry.code,reason:r.entry.reason,selPct:r.selPct,relativeVolume:r.relativeVolume,quotePrice:r.quote?.price,quoteAt:r.quote?.at,h,fee:b.fee,scoreVersion:b.scoreRule.version};lines.push(cols.map(k=>cell(v[k])).join(','));}return '\ufeff'+lines.join('\r\n');
}
const api={VERSION,POLICY,HS,outcomes,csv};root.MarketLensLearning=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
