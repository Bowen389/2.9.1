/* Market Lens Lab storage (store-2.9.0 · 2.6.1 data model + 2.8 speed paths).
 * chrome.storage.local when available (manifest "storage" + "unlimitedStorage"),
 * otherwise an in-memory Map (tests / preview). Everything stays on this
 * computer; nothing is uploaded. All writes are serialized through one queue so
 * concurrent scan workers cannot clobber the index. */
(function (root) {
  'use strict';
  const VERSION = 'store-2.11.0';
  const DAY = 86400000;
  const area = (typeof chrome !== 'undefined' && chrome && chrome.storage && chrome.storage.local) ? chrome.storage.local : null;
  const mem = new Map();
  const clone = v => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
  let chain = Promise.resolve();
  const enqueue = fn => (chain = chain.then(fn, fn));

  async function rawGet(keys) {
    if (area) return (await area.get(keys)) || {};
    const out = {};
    for (const k of (Array.isArray(keys) ? keys : [keys])) if (mem.has(k)) out[k] = clone(mem.get(k));
    return out;
  }
  async function rawSet(obj) {
    if (area) return area.set(obj);
    for (const k of Object.keys(obj)) mem.set(k, clone(obj[k]));
  }
  async function rawRemove(keys) {
    if (area) return area.remove(keys);
    for (const k of (Array.isArray(keys) ? keys : [keys])) mem.delete(k);
  }
  async function get(key, dflt) { const r = await rawGet(key); return r[key] === undefined ? clone(dflt) : r[key]; }
  const set = (key, val) => enqueue(() => rawSet({ [key]: val }));
  // Atomic read-modify-write through the same queue (never call set() inside fn).
  const mutate = (key, dflt, fn) => enqueue(async () => {
    const cur = (await rawGet(key))[key];
    const next = fn(cur === undefined ? clone(dflt) : cur);
    await rawSet({ [key]: next });
    return next;
  });
  async function bytesInUse() {
    if (area && area.getBytesInUse) { try { return await area.getBytesInUse(null); } catch (e) { return null; } }
    let n = 0; for (const [k, v] of mem) n += k.length + JSON.stringify(v).length; return n;
  }

  // ---- typed-array packing --------------------------------------------------
  function b64(u8) {
    let s = '';
    for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return btoa(s);
  }
  function unb64(str) {
    const s = atob(str), u8 = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i);
    return u8;
  }
  const f32 = a => b64(new Uint8Array(Float32Array.from(a).buffer));
  const unf32 = s => Float64Array.from(new Float32Array(unb64(s).buffer));
  const dayStr = d => new Date(d * DAY).toISOString().slice(0, 10);
  function packSeries(s) {
    if (!s || !s.ok) return null;
    return { day0: s.day0, n: s.n, o: f32(s.o), h: f32(s.h), l: f32(s.l), c: f32(s.c), v: f32(s.v), real: b64(Uint8Array.from(s.real)), stale: b64(new Uint8Array(Uint16Array.from(s.stale).buffer)) };
  }
  function unpackSeries(p) {
    if (!p || !p.n) return { ok: false, reason: '缓存损坏' };
    const s = { ok: true, day0: p.day0, n: p.n, o: unf32(p.o), h: unf32(p.h), l: unf32(p.l), c: unf32(p.c), v: unf32(p.v), real: unb64(p.real), stale: new Uint16Array(unb64(p.stale).buffer), dropped: 0 };
    if (s.c.length !== s.n || s.real.length !== s.n) return { ok: false, reason: '缓存长度不一致' };
    s.firstDay = dayStr(s.day0); s.lastDay = dayStr(s.day0 + s.n - 1);
    return s;
  }

  // ---- K-line cache -----------------------------------------------------------
  // key 'k:<id>' -> {id,name,family,fetchedAt,lastDay,pack};  'kidx' -> {id: meta}
  let idxCache = null, idxDirty = false, idxTimer = null;
  async function loadIdx() { if (!idxCache) idxCache = await get('kidx', {}); return idxCache; }
  // Public view is a copy: callers must never mutate the shared cache.
  async function kIndex() { return Object.assign({}, await loadIdx()); }
  // The index is one object holding every item; rewriting it after each of
  // hundreds of scan writes is pure amplification. Writes are coalesced: the
  // record goes to storage immediately, the index at most every 600 ms and
  // always on flushIdx() (called when a scan batch ends).
  function scheduleIdxFlush() {
    idxDirty = true;
    if (idxTimer) return;
    idxTimer = setTimeout(() => { idxTimer = null; flushIdx().catch(() => {}); }, 600);
  }
  function flushIdx() {
    if (idxTimer) { clearTimeout(idxTimer); idxTimer = null; }
    if (!idxDirty || !idxCache) { idxDirty = false; return Promise.resolve(); }
    idxDirty = false;
    const snapshot = clone(idxCache);
    return enqueue(() => rawSet({ kidx: snapshot }));
  }
  async function putK(meta, series) {
    const pack = packSeries(series);
    if (!pack || !meta || !meta.id) return false;
    const id = String(meta.id);
    const rec = { id, name: meta.name || '', family: meta.family || '', fetchedAt: new Date().toISOString(), lastDay: series.lastDay, pack };
    await loadIdx();
    await enqueue(async () => {
      idxCache[id] = { name: rec.name, family: rec.family, lastDay: rec.lastDay, fetchedAt: rec.fetchedAt, n: series.n, price: meta.price || null };
      await rawSet({ ['k:' + id]: rec });
      scheduleIdxFlush();
    });
    return true;
  }
  const recToK = (id, rec) => {
    if (!rec) return null;
    let series; try { series = unpackSeries(rec.pack); } catch (e) { return null; }
    return series.ok ? { id: rec.id || id, name: rec.name, family: rec.family, fetchedAt: rec.fetchedAt, series } : null;
  };
  async function getK(id) {
    const r = await rawGet('k:' + id);
    return recToK(String(id), r['k:' + id]);
  }
  // Batch read (one storage round-trip per 50 ids) -> Map(id -> record|null).
  async function getKMany(ids, onProgress) {
    const out = new Map(), list = Array.from(new Set((ids || []).map(String)));
    for (let i = 0; i < list.length; i += 50) {
      const chunk = list.slice(i, i + 50), r = await rawGet(chunk.map(id => 'k:' + id));
      for (const id of chunk) out.set(id, recToK(id, r['k:' + id]));
      if (onProgress) onProgress(Math.min(list.length, i + 50), list.length);
    }
    return out;
  }
  // Fresh = contains the latest completed UTC day (data only changes once a day).
  function isFresh(meta, now) {
    if (!meta || !meta.lastDay) return false;
    const want = dayStr(Math.floor((now || Date.now()) / DAY) - 1);
    return meta.lastDay >= want;
  }
  async function allK(opts) {
    const o = opts || {};
    const idx = await kIndex(), ids = Object.keys(idx);
    const out = [];
    for (let i = 0; i < ids.length; i += 50) {
      const chunk = ids.slice(i, i + 50), r = await rawGet(chunk.map(id => 'k:' + id));
      for (const id of chunk) {
        const rec = r['k:' + id]; if (!rec) continue;
        let series; try { series = unpackSeries(rec.pack); } catch (e) { return null; }
        if (series.ok) out.push({ id, name: rec.name, family: rec.family, fetchedAt: rec.fetchedAt, series });
      }
      if (o.onProgress) o.onProgress(Math.min(ids.length, i + 50), ids.length);
    }
    return out;
  }
  async function removeK(ids) {
    await loadIdx();
    if (idxTimer) { clearTimeout(idxTimer); idxTimer = null; }
    idxDirty = false;
    await enqueue(async () => {
      for (const id of ids) delete idxCache[id];
      await rawRemove(ids.map(id => 'k:' + id));
      await rawSet({ kidx: idxCache });
    });
  }
  async function clearK() { const ids = Object.keys(await kIndex()); await removeK(ids); }

  // ---- market index cache ---------------------------------------------------
  async function putMarket(series) { if (series && series.ok) await set('market', { fetchedAt: new Date().toISOString(), lastDay: series.lastDay, pack: packSeries(series) }); }
  async function getMarket() { const r = await get('market', null); if (!r) return null; const s = unpackSeries(r.pack); return s.ok ? { fetchedAt: r.fetchedAt, lastDay: r.lastDay, series: s } : null; }

  // ---- settings -------------------------------------------------------------
  // rules: null = the default filter rules (MarketLensFactor.DEFAULT_RULES,
  // normalised by the panel with F.normRules).
  // fee: 1% round trip = 悠悠有品 seller fee. Change it in 高级 → 学习 → 设置 if
  // your real cost (spread, withdrawal, waiting to sell) is higher.
  // concurrency: parallel K requests during a scan (2–4). kDepth: days fetched
  // the first time an item is seen (later refreshes fetch only the missing tail).
  const DEFAULT_SETTINGS = { researchCapture: false, h: 30, fee: 0.01, topN: 10, gate: 30, minLiq: 2, maxZeroVol: 0.5, step: 3, logSignals: true, featureSet: 'LEAN', rules: null, concurrency: 3, kDepth: 720 };
  const OLD_DEFAULT_FEE = 0.02;
  // One-time migration: settings saved by ≤2.4 / 2.7 still carry the old 2% default.
  // Move them to 1% once (flag feeV25); a later manual 2% is left alone.
  async function settings() {
    let cur = await get('settings', {});
    if (cur && !cur.feeV25 && Object.keys(cur).length) {
      cur = await mutate('settings', {}, c => Object.assign({}, c, c.fee === OLD_DEFAULT_FEE ? { fee: DEFAULT_SETTINGS.fee } : {}, { feeV25: true }));
    }
    return Object.assign({}, DEFAULT_SETTINGS, cur);
  }
  async function saveSettings(patch) { const s = await mutate('settings', {}, cur => Object.assign({}, cur, patch || {}, { feeV25: true })); return Object.assign({}, DEFAULT_SETTINGS, s); }

  // ---- whitelist directory ------------------------------------------------
  // market_hash_name -> FirePulse item id learned at runtime (the shipped
  // whitelist already carries ids; this only holds additions / corrections).
  const directory = () => get('wdir', {});
  const putDirectory = entries => mutate('wdir', {}, cur => Object.assign({}, cur, entries || {}));

  // ---- model registry -------------------------------------------------------
  // active[h] = null means "builtin". Candidates are full model objects.
  const MAX_CANDIDATES = 12, MAX_HISTORY = 60;
  const normReg = r => ({ active: Object.assign({ h7: null, h14: null, h30: null }, (r && r.active) || {}), candidates: (r && r.candidates) || [], history: (r && r.history) || [] });
  async function registry() { return normReg(await get('registry', {})); }
  const mutateReg = fn => mutate('registry', {}, cur => { const reg = normReg(cur); fn(reg); return reg; }).then(normReg);
  function addCandidate(model) {
    return mutateReg(reg => {
      reg.candidates = reg.candidates.filter(m => m.id !== model.id);
      reg.candidates.unshift(model);
      const activeIds = new Set(Object.values(reg.active).filter(Boolean));
      while (reg.candidates.length > MAX_CANDIDATES) {
        let k = reg.candidates.length - 1;
        while (k >= 0 && activeIds.has(reg.candidates[k].id)) k--;   // oldest non-active
        if (k < 0) break;
        reg.candidates.splice(k, 1);
      }
    });
  }
  function activate(h, id, note) {
    return mutateReg(reg => {
      const key = 'h' + h;
      if (id && !reg.candidates.some(m => m.id === id)) throw new Error('找不到候选模型 ' + id);
      const from = reg.active[key];
      if (from === id) return;
      reg.active[key] = id;
      reg.history.unshift({ at: new Date().toISOString(), h, from, to: id, note: note || '' });
      reg.history = reg.history.slice(0, MAX_HISTORY);
    });
  }
  // Undo the most recent change for horizon h (repeatable: walks back in history).
  function rollback(h) {
    return mutateReg(reg => {
      const last = reg.history.find(e => e.h === h && !e.undone);
      if (!last) throw new Error(h + '日模型没有可回滚的记录');
      if (last.from && !reg.candidates.some(m => m.id === last.from)) throw new Error('上一个模型已被删除，无法回滚；可以“恢复内置”。');
      last.undone = true;
      reg.active['h' + h] = last.from;
      reg.history.unshift({ at: new Date().toISOString(), h, from: last.to, to: last.from, note: '回滚', undone: true });
      reg.history = reg.history.slice(0, MAX_HISTORY);
    });
  }
  function removeCandidate(id) {
    return mutateReg(reg => {
      if (Object.values(reg.active).includes(id)) throw new Error('该模型正在使用，请先切换或恢复内置。');
      reg.candidates = reg.candidates.filter(m => m.id !== id);
    });
  }

  // ---- signal snapshots (paper tracking) and item views ------------------------
  const MAX_SNAPS = 120, MAX_VIEWS = 600;
  function addSnapshot(snap) { // {day,h,modelId,items:[[id,score,close]]}
    return mutate('snaps', [], arr => {
      const k = arr.findIndex(x => x.day === snap.day && x.h === snap.h && x.modelId === snap.modelId);
      if (k >= 0) arr.splice(k, 1);
      arr.unshift(Object.assign({ at: new Date().toISOString() }, snap));
      return arr.slice(0, MAX_SNAPS);
    });
  }
  const snapshots = () => get('snaps', []);
  function addView(v) { // {day,id,name,h,modelId,score,pct,close}
    return mutate('views', [], arr => {
      const k = arr.findIndex(x => x.day === v.day && x.id === v.id && x.h === v.h);
      if (k >= 0) arr.splice(k, 1);
      arr.unshift(Object.assign({ at: new Date().toISOString() }, v));
      return arr.slice(0, MAX_VIEWS);
    });
  }
  const views = () => get('views', []);
  // ---- holdings (2.6 · 我的持仓) ------------------------------------------------
  // Manual buy/sell records kept on this computer only. Nothing is traded.
  // {hid, id, name, buyDay, buyPrice, qty, h, sellBy, pctAtBuy, modelId,
  //  status: 'open'|'sold', sellDay, sellPrice, createdAt}
  const MAX_HOLDINGS = 500;
  const round2 = v => Math.round(v * 100) / 100;
  const newHid = () => 'h' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  // 2.7 / 2.8 kept trades as ledger `lots` ({key,id,name,price,quantity,at,
  // targetDays,status,soldPrice,soldAt}). Convert them once (flag
  // 'holdingsFrom28') so a user coming from those versions keeps the records;
  // the old key stays untouched as a backup.
  function holdingsFromLots(list) {
    const out = [];
    for (const x of Array.isArray(list) ? list : []) {
      if (!x || !/^\d+$/.test(String(x.id))) continue;
      const price = Number(x.price), qty = Number(x.quantity) > 0 ? Math.round(Number(x.quantity)) : 1;
      if (!Number.isFinite(price) || price <= 0) continue;
      const day = iso => (iso && !isNaN(Date.parse(iso)) ? new Date(Date.parse(iso) + 8 * 3600000).toISOString().slice(0, 10) : null);
      const buyDay = day(x.at) || new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 10);
      const h = [7, 14, 30].includes(Number(x.targetDays)) ? Number(x.targetDays) : 30;
      const sold = x.status === 'sold' && Number.isFinite(Number(x.soldPrice)) && Number(x.soldPrice) > 0;
      out.push({ hid: 'h28-' + String(x.key || Math.random().toString(36).slice(2, 10)), id: String(x.id), name: String(x.name || '商品 ' + x.id).slice(0, 200), url: null,
        buyDay, buyPrice: round2(price), qty, h, sellBy: new Date(Date.parse(buyDay + 'T00:00:00Z') + h * DAY).toISOString().slice(0, 10),
        pctAtBuy: null, modelId: null, status: sold ? 'sold' : 'open', sellDay: sold ? (day(x.soldAt) || buyDay) : null, sellPrice: sold ? round2(Number(x.soldPrice)) : null,
        createdAt: x.at && !isNaN(Date.parse(x.at)) ? new Date(x.at).toISOString() : new Date().toISOString() });
    }
    return out;
  }
  async function holdings() {
    let l = await get('holdings', []);
    if (!Array.isArray(l)) l = [];
    if (await get('holdingsFrom28', false)) return l;
    const old = await get('lots', null);
    if (Array.isArray(old) && old.length) {
      const have = new Set(l.map(x => x.hid)), add = holdingsFromLots(old).filter(x => !have.has(x.hid));
      if (add.length) { l = l.concat(add); await enqueue(() => rawSet({ holdings: l, holdingsFrom28: true })); return l; }
    }
    await enqueue(() => rawSet({ holdingsFrom28: true }));
    return l;
  }
  function addHolding(rec) {
    return mutate('holdings', [], cur => {
      const list = Array.isArray(cur) ? cur : [];
      const h = Object.assign({ qty: 1, status: 'open', createdAt: new Date().toISOString() }, rec || {}, { hid: newHid() });
      validateHolding(h);
      const existing=h.recordToken&&list.find(x=>x.recordToken===h.recordToken);
      if(existing){const keys=['id','name','buyDay','buyPrice','buyFee','qty','h','userNote','entrySource'];if(keys.some(k=>existing[k]!==h[k]))throw Error('这次记账已保存，但重试内容不同；请先查看持仓，避免重复记账。');return list;}
      if (list.length >= MAX_HOLDINGS) throw Error('持仓记录已达500条，请先导出备份并手动整理历史记录；未删除任何记录。');
      return [h].concat(list);
    }).then(l => rec?.recordToken?l.find(x=>x.recordToken===rec.recordToken):l[0]);
  }
  function updateHolding(hid, patch) {
    return mutate('holdings', [], cur => (Array.isArray(cur) ? cur : []).map(h => { if (h.hid !== hid) return h; const next = Object.assign({}, h, patch || {}, { hid }); validateHolding(next); return next; }));
  }
  function removeHolding(hid) { return mutate('holdings', [], cur => (Array.isArray(cur) ? cur : []).filter(h => h.hid !== hid)); }
  // Latest cross-section per horizon (single-item percentile reference).
  const putXsec = (h, x) => set('xsec:h' + h, x);
  const getXsec = h => get('xsec:h' + h, null);

  // ---- export / import ------------------------------------------------------
  async function exportAll(opts) {
    const o = opts || {};
    const out = { app: 'market-lens-lab', store: VERSION, exportedAt: new Date().toISOString(), settings: await settings(), registry: await registry(), snaps: await snapshots(), views: await views(), holdings: await holdings(), wdir: await directory() };
    if (o.includeK) {
      const idx = await kIndex(), ids = Object.keys(idx), recs = {};
      for (let i = 0; i < ids.length; i += 50) Object.assign(recs, await rawGet(ids.slice(i, i + 50).map(id => 'k:' + id)));
      out.kidx = clone(idx); out.k = recs; out.market = await get('market', null);
    }
    if (o.includeBackup) out.previousImport = await get('previousImportBackup', null);
    return out;
  }
  const validDay = v => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && Number.isFinite(Date.parse(v + 'T00:00:00Z')) && new Date(v + 'T00:00:00Z').toISOString().slice(0, 10) === v;
  const plain = v => v && typeof v === 'object' && !Array.isArray(v);
  function validateTree(obj, depth = 0, state = { n: 0 }) {
    if (++state.n > 3000000 || depth > 35) throw Error('导入结构过大或过深');
    if (typeof obj === 'number' && !Number.isFinite(obj)) throw Error('导入包含非有限数值');
    if (!obj || typeof obj !== 'object') return;
    for (const k of Object.keys(obj)) {
      if (['__proto__', 'prototype', 'constructor'].includes(k)) throw Error('导入包含不允许的字段');
      validateTree(obj[k], depth + 1, state);
    }
  }
  function validateSettings(x) {
    if (!plain(x)) throw Error('设置结构无效');
    const out = {};
    const ranges = { fee: [0, .1], topN: [1, 100], gate: [0, 100], minLiq: [0, 1e9], maxZeroVol: [0, 1], step: [1, 30], concurrency: [2, 4] };
    for (const [k, bounds] of Object.entries(ranges)) if (x[k] !== undefined) {
      if (!Number.isFinite(x[k]) || x[k] < bounds[0] || x[k] > bounds[1] || (['topN','step','concurrency'].includes(k) && !Number.isInteger(x[k]))) throw Error('设置范围无效：' + k);
      out[k] = x[k];
    }
    for (const [k, values] of Object.entries({ h: [7,14,30], kDepth: [720,1440], featureSet: ['LEAN','CURATED','FULL'] })) if (x[k] !== undefined) {
      if (!values.includes(x[k])) throw Error('设置取值无效：' + k); out[k] = x[k];
    }
    for (const k of ['logSignals','useCache','feeV25','researchCapture']) if (x[k] !== undefined) { if (typeof x[k] !== 'boolean') throw Error('设置类型无效：' + k); out[k] = x[k]; }
    if (x.rules !== undefined) {
      if (x.rules !== null && !plain(x.rules)) throw Error('筛选规则无效');
      if (x.rules) {
        for (const [k,v] of Object.entries(x.rules)) {
          if (typeof v === 'number' && (v < 0 || v > 1e9)) throw Error('筛选规则数值无效');
          if (typeof v === 'string' && v.length > 2000) throw Error('筛选规则过长');
          if (Array.isArray(v) && (v.length > 100 || v.some(a => typeof a !== 'string' || a.length > 200))) throw Error('筛选规则列表无效');
          if (v && typeof v === 'object' && !Array.isArray(v)) throw Error('筛选规则结构无效');
        }
      }
      out.rules = x.rules;
    }
    return out;
  }
  function validateModel(m) {
    if (!plain(m) || typeof m.id !== 'string' || !m.id.length || m.id.length > 200 || !Array.isArray(m.features) || !m.features.length || m.features.length > 100) throw Error('模型结构无效');
    if (![7,14,30].includes(m.h || m.horizon)) throw Error('模型结构无效：周期无效');
    if (new Set(m.features.map(f => f.key)).size !== m.features.length) throw Error('模型因子重复');
    for (const f of m.features) if (!f || typeof f.key !== 'string' || !/^[a-zA-Z][a-zA-Z0-9]{0,49}$/.test(f.key) || !['w','lo','hi','mu','sd'].every(k => Number.isFinite(f[k])) || f.sd <= 0 || f.lo > f.hi || Math.abs(f.w) > 100) throw Error('模型结构无效：' + m.id);
    if (m.source === 'builtin') throw Error('导入候选不能冒充内置模型');
    if (m.calib) {
      if (!plain(m.calib)) throw Error('模型校准结构无效');
      for (const [key,groups] of Object.entries(m.calib)) {
        if (!['h7','h14','h30'].includes(key) || !Array.isArray(groups) || groups.length > 5) throw Error('模型校准结构无效');
        for (const group of groups) if (!plain(group) || Object.entries(group).some(([k,v]) => k === 'bucket' ? typeof v !== 'string' || !/^\d+–\d+$/.test(v) : v !== null && !Number.isFinite(v))) throw Error('模型校准数值无效');
      }
    }
    if (m.reference) {
      const r = m.reference, a = r.sorted || r.scores;
      if (!Array.isArray(a) || a.length > 10000 || a.some(v => !Number.isFinite(v)) || a.some((v,i) => i && v < a[i-1]) || !validDay(r.day)) throw Error('模型参考截面无效');
    }
  }
  function validateHolding(h) {
    if (!plain(h) || typeof h.hid !== 'string' || !h.hid || h.hid.length > 200 || !/^\d+$/.test(h.id) || typeof h.id !== 'string') throw Error('持仓结构无效');
    if (!Number.isFinite(h.buyPrice) || h.buyPrice <= 0 || h.buyPrice > 1e10 || !Number.isInteger(h.qty) || h.qty <= 0 || h.qty > 1e6) throw Error('持仓价格或数量无效');
    for (const k of ['buyDay','sellBy','sellDay']) if (h[k] != null && !validDay(h[k])) throw Error('持仓日期无效');
    if (!['open','sold'].includes(h.status) || (h.h !== undefined && ![7,14,30].includes(h.h))) throw Error('持仓状态无效');
    if (h.status === 'sold' && (!Number.isFinite(h.sellPrice) || h.sellPrice <= 0)) throw Error('卖出价格无效');
    if(h.recordToken!==undefined&&(typeof h.recordToken!=='string'||!/^m-[a-z0-9-]{1,76}$/.test(h.recordToken)))throw Error('记账请求标识无效');
    for(const k of ['buyFee','sellFee'])if(h[k]!=null&&(!Number.isFinite(h[k])||h[k]<0||h[k]>1e10||Math.abs(h[k]*100-Math.round(h[k]*100))>0.0001))throw Error('整笔费用无效');
    if(h.entrySource!==undefined&&!['manual','model-assisted'].includes(h.entrySource))throw Error('记账来源无效');
    for(const k of ['decisionNote','userNote'])if(h[k]!==undefined&&(typeof h[k]!=='string'||h[k].length>(k==='decisionNote'?1000:500)))throw Error('记账说明过长或无效');
    if(h.decisionCapturedAt!==undefined&&!Number.isFinite(Date.parse(h.decisionCapturedAt)))throw Error('决策记录时间无效');
    if(h.entrySource==='manual'&&(!validDay(h.buyDay)||h.buyDay>new Date(Date.now()+8*3600000).toISOString().slice(0,10)||!Number.isFinite(h.buyFee)))throw Error('自主记账需提供非未来买入日及整笔费用');
    if (h.name !== undefined && (typeof h.name !== 'string' || h.name.length > 300)) throw Error('持仓名称无效');
    if (h.url && !/^https:\/\/(www\.)?firepulse\.com\.cn\/cs2\/\d+(?:[?#].*)?$/.test(h.url)) throw Error('持仓链接无效');
  }
  function validatePack(p) {
    if (!plain(p) || !Number.isInteger(p.n) || p.n < 1 || p.n > 20000 || !Number.isInteger(p.day0) || p.day0 < 0 || p.day0 + p.n > 100000) throw Error('日K缓存范围无效');
    for (const k of ['o','h','l','c','v','real','stale']) if (typeof p[k] !== 'string' || p[k].length > 120000) throw Error('日K缓存编码无效');
    let s; try { s = unpackSeries(p); } catch (e) { throw Error('日K缓存编码损坏'); }
    if (!s.ok || ['o','h','l','c','v','real','stale'].some(k => s[k].length !== s.n)) throw Error('日K缓存长度无效');
    for (let i = 0; i < s.n; i++) {
      if (!['o','h','l','c','v'].every(k => Number.isFinite(s[k][i])) || Math.min(s.o[i],s.h[i],s.l[i],s.c[i]) <= 0 || s.v[i] < 0 || s.l[i] > Math.min(s.o[i],s.c[i]) || s.h[i] < Math.max(s.o[i],s.c[i]) || ![0,1].includes(s.real[i])) throw Error('日K缓存数值无效');
    }
    return s;
  }
  async function importAll(obj) {
    if (!obj || obj.app !== 'market-lens-lab') throw Error('不是 Market Lens Lab 导出的文件');
    if (JSON.stringify(obj).length > 48 * 1024 * 1024) throw Error('导入文件超过48MB限制');
    validateTree(obj);
    const writes = {};
    if (obj.settings) writes.settings = Object.assign({}, DEFAULT_SETTINGS, validateSettings(obj.settings));
    if (obj.registry) {
      const reg = obj.registry;
      if (!plain(reg) || !Array.isArray(reg.candidates || []) || (reg.candidates || []).length > 100 || !Array.isArray(reg.history || []) || (reg.history || []).length > 1000) throw Error('模型注册表无效');
      (reg.candidates || []).forEach(validateModel);
      if (new Set((reg.candidates || []).map(m => m.id)).size !== (reg.candidates || []).length) throw Error('模型ID重复');
      for (const e of reg.history || []) if (!plain(e) || typeof e.at !== 'string' || !Number.isFinite(Date.parse(e.at)) || ![7,14,30].includes(e.h)) throw Error('模型历史无效');
      const active = Object.assign({h7:null,h14:null,h30:null},reg.active || {});
      for (const [k,v] of Object.entries(active)) if (!['h7','h14','h30'].includes(k) || (v !== null && !(reg.candidates || []).some(m => m.id === v))) throw Error('启用模型不存在');
      writes.registry = { active, candidates: reg.candidates || [], history: reg.history || [] };
    }
    for (const [key,max] of [['snaps',MAX_SNAPS],['views',MAX_VIEWS]]) if (obj[key] !== undefined) {
      if (!Array.isArray(obj[key]) || obj[key].length > max) throw Error('跟踪记录数量无效');
      for (const row of obj[key]) {
        if (!plain(row) || !validDay(row.day) || ![7,14,30].includes(row.h)) throw Error('跟踪记录结构无效');
        if (key === 'snaps' && (!Array.isArray(row.items) || row.items.length > 10000 || row.items.some(a => !Array.isArray(a) || a.length !== 3 || !/^\d+$/.test(String(a[0])) || !Number.isFinite(a[1]) || !(a[2] > 0)))) throw Error('快照明细无效');
      }
      writes[key] = obj[key];
    }
    if (obj.holdings !== undefined) {
      if (!Array.isArray(obj.holdings) || obj.holdings.length > 10000) throw Error('持仓记录数量无效');
      obj.holdings.forEach(validateHolding);
      if (new Set(obj.holdings.map(h => h.hid)).size !== obj.holdings.length) throw Error('持仓ID重复');
      writes.holdings = obj.holdings;
    } else if (obj.lots !== undefined) {
      if (!Array.isArray(obj.lots) || obj.lots.length > 10000) throw Error('旧版持仓结构无效');
      writes.holdings = holdingsFromLots(obj.lots);
      if (writes.holdings.length !== obj.lots.length) throw Error('旧版持仓包含无效记录，未导入');
      writes.holdings.forEach(validateHolding);
    }
    if (writes.holdings) writes.holdingsFrom28 = true;
    if (obj.k !== undefined || obj.kidx !== undefined) {
      if (!plain(obj.k) || !plain(obj.kidx) || Object.keys(obj.k).length > 5000) throw Error('日K缓存结构无效');
      const index = {};
      for (const [key,rec] of Object.entries(obj.k)) {
        if (!/^k:\d+$/.test(key) || !plain(rec) || String(rec.id) !== key.slice(2)) throw Error('日K缓存键无效：' + key);
        const series = validatePack(rec.pack);
        if (rec.lastDay !== series.lastDay) throw Error('日K缓存日期不一致');
        writes[key] = rec;
        index[rec.id] = { name: String(rec.name || '').slice(0,300), family: String(rec.family || '').slice(0,200), lastDay: series.lastDay, fetchedAt: rec.fetchedAt, n: series.n, price: null };
      }
      // Merge with existing cache, deriving every imported index entry from validated bars.
      writes.kidx = Object.assign({}, await kIndex(), index);
    }
    if (obj.market) { const m = validatePack(obj.market.pack); if (obj.market.lastDay !== m.lastDay) throw Error('指数日期不一致'); writes.market = obj.market; }
    if (obj.wdir !== undefined) {
      if (!plain(obj.wdir) || Object.keys(obj.wdir).length > 5000 || Object.entries(obj.wdir).some(([k,v]) => k.length > 300 || !/^\d+$/.test(String(v)))) throw Error('商品目录无效');
      writes.wdir = obj.wdir;
    }
    // Validate everything before any write. Backup can be recovered by export (previousImport field).
    const backup = await exportAll({ includeK: true });
    await enqueue(() => rawSet({ previousImportBackup: backup }));
    if (idxTimer) { clearTimeout(idxTimer); idxTimer = null; }
    idxDirty = false;
    await enqueue(() => rawSet(Object.assign(writes, { 'xsec:h7': null, 'xsec:h14': null, 'xsec:h30': null, dataRevision: Date.now() + '-' + Math.random() })));
    idxCache = null;
    return Object.keys(writes).length;
  }
  const learningData=()=>get('learning:data',{batches:[],outcomes:[]});
  const clearLearning=()=>enqueue(()=>rawRemove(['learning:data']));
  function saveLearningBatch(b){
    validateTree(b);
    if(!b||b.version!=='entry-learning-1.0'||typeof b.key!=='string'||b.key.length>10000||!validDay(b.captureDay)||!validDay(b.signalDay)||!Number.isFinite(Date.parse(b.capturedAt))||!b.model?.id||!b.scoreRule?.version||!Number.isFinite(b.fee)||b.fee<0||b.fee>=1||!Array.isArray(b.rows)||!b.rows.length||b.rows.length>2000||JSON.stringify(b).length>12*1024*1024)throw Error('学习快照格式或大小无效');
    const ids=new Set();for(const r of b.rows){if(!/^\d+$/.test(r.id)||ids.has(r.id)||!r.entry||!(r.entry.score===null||(Number.isFinite(r.entry.score)&&r.entry.score>=0&&r.entry.score<=100)))throw Error('学习商品记录无效');ids.add(r.id);}
    return mutate('learning:data',{batches:[],outcomes:[]},d=>{if(d.batches.some(x=>x.key===b.key))return d;if(d.batches.length>=100||JSON.stringify(d).length+JSON.stringify(b).length>100*1024*1024)throw Error('学习档案达容量上限，请先导出再清理；不会覆盖旧记录');d.batches.push(b);return d;}).then(d=>d.batches.find(x=>x.key===b.key));
  }
  function saveLearningOutcomes(rows){
    validateTree(rows);if(!Array.isArray(rows)||rows.length>6000)throw Error('结果批次过大');
    return mutate('learning:data',{batches:[],outcomes:[]},d=>{const known=new Set(d.outcomes.map(o=>o.batchKey+'|'+o.id+'|'+o.h));for(const o of rows){const b=d.batches.find(b=>b.key===o.batchKey);if(!b||!b.rows.some(r=>r.id===o.id)||![7,14,30].includes(o.h)||o.status!=='matured'||!validDay(o.entryDay)||!validDay(o.exitDay)||!Number.isFinite(o.net)||!Number.isFinite(o.gross)||!(o.entryPrice>0)||!(o.exitPrice>0)||o.fee!==b.fee||!Number.isFinite(Date.parse(o.observedAt)))throw Error('结果记录无效');const entry=Date.parse(b.captureDay)+86400000,exit=entry+o.h*86400000;if(Date.parse(o.entryDay)!==entry||Date.parse(o.exitDay)!==exit||exit>=Math.floor(Date.parse(o.observedAt)/86400000)*86400000||Math.abs(o.net-(o.exitPrice*(1-b.fee)/o.entryPrice-1))>1e-10||Math.abs(o.gross-(o.exitPrice/o.entryPrice-1))>1e-10)throw Error('结果日期或收益计算无效');const k=o.batchKey+'|'+o.id+'|'+o.h;if(!known.has(k)){d.outcomes.push(o);known.add(k);}}return d;}).then(d=>d.outcomes.length);
  }
  const entryStudies=()=>get('entry:studies',[]);
  const clearEntryStudies=()=>enqueue(()=>rawRemove(['entry:studies']));
  function saveEntryStudy(study){
    validateTree(study);
    if(!study||study.version!=='entry-abc-0.1'||typeof study.key!=='string'||study.key.length>5000||!validDay(study.signalDay)||!Number.isFinite(Date.parse(study.capturedAt))||!Array.isArray(study.rows)||study.rows.length>300||JSON.stringify(study).length>2*1024*1024)throw Error('入场对照快照格式或大小无效');
    for(const r of study.rows)if(!/^\d+$/.test(r.id)||!r.comparison||['A','B','C'].some(k=>typeof r.comparison[k]?.pass!=='boolean'))throw Error('入场对照记录无效');
    return mutate('entry:studies',[],list=>{if(list.some(x=>x.key===study.key))return list;if(list.length>=100)throw Error('入场快照已达100批，请先导出；不会静默覆盖。');return list.concat(study);}).then(list=>list.find(x=>x.key===study.key));
  }
  async function researchState() {
    const experiments = await get('research:experiments', []), quotes = await get('research:quotes', []), shadows = await get('research:shadows', []);
    return { latest: experiments[0] || null, experiments: experiments.length, quotes: quotes.length, shadows: shadows.length };
  }
  function saveExperiment(result) {
    validateTree(result);
    if (!result || result.schema !== 1 || typeof result.id !== 'string' || ![7,14,30].includes(result.h) || !Array.isArray(result.models) || result.models.length !== 4 || !Array.isArray(result.reports) || JSON.stringify(result).length > 5*1024*1024) throw Error('实验结果结构或大小无效');
    return mutate('research:experiments', [], list => {
      if (list.some(x => x.id === result.id)) return list;
      if (list.length >= 10) throw Error('已保存10份冻结实验，请先单独导出研究档案，再手动清理。未覆盖旧实验。');
      return [result, ...list];
    }).then(list => list.find(x => x.id === result.id));
  }
  async function addResearchQuotes(rows) {
    if (!(await settings()).researchCapture) return 0;
    if (!Array.isArray(rows) || rows.length > 100) throw Error('报价采集批次过大');
    for (const q of rows) if (!q || !/^\d+$/.test(q.id) || !Number.isFinite(Date.parse(q.observedAt)) || !Number.isFinite(q.ask) || q.ask <= 0 || (q.count !== null && (!Number.isFinite(q.count) || q.count < 0)) || (q.close !== null && (!Number.isFinite(q.close) || q.close <= 0))) throw Error('研究报价无效');
    const clean = rows.map(q => ({id:q.id, observedAt:q.observedAt, ask:q.ask, count:q.count, close:q.close, signalDay:validDay(q.signalDay)?q.signalDay:null, source:'youpin', timeBasis:'本机读取时间，非交易所时间'}));
    return mutate('research:quotes', [], list => {
      const have = new Set(list.map(q => q.id+'|'+q.observedAt)), added = clean.filter(q => !have.has(q.id+'|'+q.observedAt));
      if (list.length + added.length > 20000) throw Error('报价研究档案已达20000条，请先导出再清理；未删除历史。');
      return list.concat(added);
    }).then(() => clean.length);
  }
  function addShadow(snapshot) {
    validateTree(snapshot);
    if (!snapshot || snapshot.schema !== 1 || typeof snapshot.experimentId !== 'string' || !validDay(snapshot.day) || !Number.isFinite(Date.parse(snapshot.capturedAt)) || ![7,14,30].includes(snapshot.h) || !Array.isArray(snapshot.arms) || snapshot.arms.length !== 4 || !Number.isInteger(snapshot.slots) || snapshot.slots < 1 || snapshot.slots > 50) throw Error('影子快照无效');
    for (const arm of snapshot.arms) if (typeof arm.name !== 'string' || !Array.isArray(arm.picks) || arm.picks.length > snapshot.slots || arm.picks.some(p => !/^\d+$/.test(p.id) || !Number.isFinite(p.score) || !(p.close>0) || (p.ask!==null && !(p.ask>0)))) throw Error('影子选品无效');
    const key = x => x.experimentId+'|'+x.day+'|'+x.h;
    return mutate('research:shadows', [], list => { if (list.some(x => key(x) === key(snapshot))) return list; if (list.length >= 200) throw Error('影子记录已达200批，请先导出清理；不会覆盖首份记录。'); return list.concat(snapshot); }).then(list=>list.find(x=>key(x)===key(snapshot)));
  }
  const shadowRecords = () => get('research:shadows', []);
  async function exportResearch() { return { app:'market-lens-research', schema:1, exportedAt:new Date().toISOString(), experiments:await get('research:experiments',[]), quotes:await get('research:quotes',[]), shadows:await shadowRecords() }; }
  const clearResearch = () => enqueue(()=>rawRemove(['research:experiments','research:quotes','research:shadows']));
  async function resetAll() {
    const keys = ['settings', 'registry', 'snaps', 'views', 'holdings', 'holdingsFrom28', 'lots', 'lotsFrom26', 'market', 'wdir', 'xsec:h7', 'xsec:h14', 'xsec:h30', 'previousImportBackup','learning:data','entry:studies','research:experiments','research:quotes','research:shadows'];
    await clearK();
    await enqueue(() => rawRemove(keys));
    await set('dataRevision', Date.now() + '-' + Math.random());
  }

  const api = {
    learningData, saveLearningBatch, saveLearningOutcomes, clearLearning,
    entryStudies, saveEntryStudy, clearEntryStudies, researchState, saveExperiment, addResearchQuotes, addShadow, shadowRecords, exportResearch, clearResearch,
    VERSION, persistent: !!area, DEFAULT_SETTINGS, get, set, bytesInUse,
    packSeries, unpackSeries, putK, getK, getKMany, flushIdx, allK, kIndex, isFresh, removeK, clearK, putMarket, getMarket, directory, putDirectory,
    settings, saveSettings, registry, addCandidate, activate, rollback, removeCandidate,
    addSnapshot, snapshots, addView, views, holdings, holdingsFromLots, addHolding, updateHolding, removeHolding, putXsec, getXsec, exportAll, exportBackup: () => get('previousImportBackup', null), importAll, resetAll,
    _mem: mem, _resetCache: () => { idxCache = null; },
  };
  if (typeof document !== 'undefined' && typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    const rpc = root.MarketLensStoreRPC;
    if (!rpc) throw Error('存储通信模块未加载');
    for (const method of rpc.methods) if (method !== 'isFresh') api[method] = async (...args) => {
      const progress = typeof args[1] === 'function' ? args[1] : args[0] && args[0].onProgress;
      const res = await chrome.runtime.sendMessage({ type: 'market-lens-store-v1', method, args: rpc.encode(args) });
      if (!res || !res.ok) throw Error(res && res.error || '扩展存储服务不可用，请刷新页面');
      const value = rpc.decode(res.value);
      if (progress) { const n = value instanceof Map ? value.size : Array.isArray(value) ? value.length : 0; progress(n,n); }
      return value;
    };
    // Chrome messages are bounded; never return the whole 816-item Float64 cache in one reply.
    const getManyRemote=api.getKMany;
    api.getKMany=async(ids,onProgress)=>{const list=[...new Set((ids||[]).map(String))],out=new Map();for(let i=0;i<list.length;i+=50){const batch=await getManyRemote(list.slice(i,i+50));for(const [id,rec] of batch)out.set(id,rec);if(onProgress)onProgress(Math.min(list.length,i+50),list.length);}return out;};
    api.allK=async(opts)=>{const ids=Object.keys(await api.kIndex()),map=await api.getKMany(ids,opts&&opts.onProgress);return Array.from(map.values()).filter(Boolean);};
    delete api.get; delete api.set; delete api._mem; delete api._resetCache;
  }
  root.MarketLensStore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
