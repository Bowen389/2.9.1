/* Offline reproduction only; no network. Use research archive + full ordinary K backup
   captured immediately after the experiment. Never uses or exports holdings. */
"use strict";
const fs = require("node:fs"),
  F = require("../factor-core"),
  EM = require("../experiment-core"),
  ST = require("../store"),
  B = require("../model-builtin");
async function main() {
  const [researchPath, cachePath, outputPath, id] = process.argv.slice(2);
  if (!researchPath || !cachePath || !outputPath)
    throw Error(
      "用法：node tools/replay-research.cjs research.json full-cache.json result.json [experimentId]",
    );
  const archive = JSON.parse(fs.readFileSync(researchPath, "utf8")),
    cache = JSON.parse(fs.readFileSync(cachePath, "utf8"));
  if (archive.app !== "market-lens-research" || cache.app !== "market-lens-lab")
    throw Error("输入不是研究档案和普通完整备份");
  const original = (archive.experiments || []).find((x) => !id || x.id === id);
  if (!original || !original.protocol || !original.sourceWindows)
    throw Error("缺少可复核实验或协议");
  if (original.version !== EM.VERSION)
    throw Error("实验协议版本不一致，请使用生成档案时的源码");
  function window(pack, w) {
    const s = ST.unpackSeries(pack),
      start = w.day0 - s.day0,
      end = start + w.n;
    if (!s.ok || start < 0 || end > s.n)
      throw Error("备份日K未覆盖实验冻结窗口");
    const out = {
      ...s,
      day0: w.day0,
      n: w.n,
      firstDay: F.dayStr(w.day0),
      lastDay: F.dayStr(w.day0 + w.n - 1),
    };
    for (const k of ["o", "h", "l", "c", "v", "real", "stale"])
      out[k] = s[k].slice(start, end);
    return out;
  }
  const items = original.universe.map((it, i) => {
    const record = cache.k && cache.k["k:" + it.id];
    if (!record) throw Error("缺商品日K：" + it.id);
    return { ...it, series: window(record.pack, original.sourceWindows[i]) };
  });
  const market =
    original.marketWindow && cache.market
      ? window(cache.market.pack, original.marketWindow)
      : null;
  if (!market) throw Error("缺大盘历史");
  const p = original.protocol;
  const P = F.buildPanel(items, market, {
    keys: B.keys,
    step: p.step,
    horizons: [original.h],
    lag: p.lag,
    skipLab: true,
    minItemsPerDay: p.minItemsPerDay,
    rules: original.rules,
    tradable: p.tradable,
  });
  const result = await EM.run(P, B.models["h" + original.h], B.keys, {
    h: original.h,
    topN: original.topN,
    tradable: p.tradable,
  });
  const report = {
    app: "market-lens-replay",
    originalId: original.id,
    dataHashMatches:
      result.provenance.dataHash === original.provenance.dataHash,
    modelHashMatches:
      result.provenance.modelHash === original.provenance.modelHash,
    result,
  };
  fs.writeFileSync(outputPath, JSON.stringify(report, null, 2));
  console.log(
    JSON.stringify({
      dataHashMatches: report.dataHashMatches,
      modelHashMatches: report.modelHashMatches,
      output: outputPath,
    }),
  );
  if (!report.dataHashMatches || !report.modelHashMatches) process.exitCode = 2;
}
main().catch((e) => {
  console.error(e.message);
  process.exitCode = 1;
});
