/* Single writer for ALL tabs. Serialized operations include reads/migration/import.
   Acknowledgement follows an index flush, so service-worker suspension loses no acknowledged K metadata. */
importScripts('store-rpc.js', 'store.js');
const RPC = globalThis.MarketLensStoreRPC, ST = globalThis.MarketLensStore;
let operations = Promise.resolve();
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== 'market-lens-store-v1') return false;
  if (sender.id !== chrome.runtime.id || !/^https:\/\/(www\.)?firepulse\.com\.cn\//.test(sender.url || '') || !RPC.methods.includes(msg.method)) {
    reply({ ok: false, error: '不允许的存储操作' }); return false;
  }
  const run = async () => {
    try {
      const args = RPC.decode(msg.args);
      if (!Array.isArray(args)) throw Error('参数格式无效');
      const value = await ST[msg.method](...args);
      await ST.flushIdx();
      reply({ ok: true, value: RPC.encode(value) });
    } catch (e) { reply({ ok: false, error: e.message || String(e) }); }
  };
  operations = operations.then(run, run);
  return true;
});
