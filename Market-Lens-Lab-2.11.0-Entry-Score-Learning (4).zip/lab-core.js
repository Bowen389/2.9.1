/* Independent experimental rules. No training, execution or future-row access. */
(function(root){
'use strict';
const L=typeof module!=='undefined'?require('./legacy-core.js'):root.MarketLensItem;
const DAY=86400000, VERSION='lab-2.1.0';
const clip=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const avg=a=>a.reduce((s,x)=>s+x,0)/a.length;
const median=a=>{let s=a.slice().sort((a,b)=>a-b),i=Math.floor(s.length/2);return s.length%2?s[i]:(s[i-1]+s[i])/2;};
const sigmoid=x=>(1+Math.tanh(x))/2;
function prefix(payload,end){
 if(!payload||!Array.isArray(payload.data))throw Error('K线响应结构无效');
 // Filter raw timestamps BEFORE cleaning to isolate future corrupt rows too.
 return L.kchart({code:payload.code,data:payload.data.filter(r=>Array.isArray(r)&&Number.isFinite(Number(r[0]))&&(Number(r[0])<1e12?Number(r[0])*1000:Number(r[0]))<end)},end);
}
function evaluate(payload,price,now=Date.now()){
 const fail=reason=>({ok:false,version:VERSION,reason});
 let k;try{k=prefix(payload,Math.floor(now/DAY)*DAY);}catch(e){return fail(e.message);}
 if(!k.ok2)return fail('需至少60根有效日K，末端无异常且未过期');
 const rows=k.rows.slice(-180), last=rows.at(-1);
 if(!Number.isFinite(price)||price<=0)return fail('当前悠悠报价无效');
 if(rows.some((r,i)=>i&&r.t-rows[i-1].t!==DAY))return fail('最近最多180根日K存在缺日，新模型暂不评分');
 if(Math.floor(now/DAY)-Math.floor(last.t/DAY)>2)return fail('完整日K滞后超过2天，新模型暂不评分');
 const c=rows.map(r=>r.c),v=rows.map(r=>r.v);
 if(v.some(x=>!Number.isFinite(x)||x<0))return fail('成交量字段缺失或异常');
 const ret=c.slice(-31).slice(1).map((x,i)=>Math.log(x/c.slice(-31)[i]));
 const med=median(ret),sigma=Math.max(.005,1.4826*median(ret.map(x=>Math.abs(x-med))));
 const z7=clip(Math.log(last.c/c.at(-8))/(sigma*Math.sqrt(7)),-4,4);
 const z30=clip(Math.log(last.c/c.at(-31))/(sigma*Math.sqrt(30)),-4,4);
 const trend=100*sigmoid((.4*z7+.6*z30)/2);
 const baseVol=median(v.slice(-33,-3)),recentVol=avg(v.slice(-3));
 const volumeValid=baseVol>=1;
 const relative=volumeValid?recentVol/baseVol:null;
 const activity=volumeValid?sigmoid(Math.log(Math.max(.01,relative))):.5;
 const nz=v.slice(-30).filter(x=>x>0).length/30;
 const liquidity=100*Math.sqrt(clip(Math.log1p(median(v.slice(-30)))/Math.log(501))*nz);
 const ma20=avg(c.slice(-20)),high20=Math.max(...c.slice(-21,-1));
 const peak20=Math.max(...c.slice(-20)),dd=(peak20-price)/peak20;
 const extension=Math.log(price/ma20)/sigma;
 const recovery=sigmoid(Math.log(last.c/c.at(-4))/(sigma*Math.sqrt(3)));
 const distance=Math.log(price/high20)/sigma;
 const trendGate=clip((trend-35)/35);
 const liqGate=.35+.65*clip(liquidity/50);
 const quoteGap=Math.abs(Math.log(price/last.c))/sigma;
 const gapPenalty=Math.exp(-Math.max(0,quoteGap-2)/3);
 // Pullback proximity targets one sigma below recent peak; falls smoothly on both sides.
 const pullLocation=Math.exp(-.5*Math.pow((dd/sigma-1.5)/2,2));
 const pullback=100*trendGate*liqGate*gapPenalty*(.65*pullLocation+.35*recovery)*Math.exp(-Math.max(0,-extension-3)/3);
 const breakoutLocation=sigmoid(distance*2)*Math.exp(-Math.max(0,distance-2)/3);
 const breakout=100*trendGate*liqGate*gapPenalty*(.65*breakoutLocation+.35*activity);
 // Reversal is independent of the medium-term trend gate. No future pivots.
 const low20=Math.min(...c.slice(-20));
 const position=(price-low20)/Math.max(peak20-low20,price*.001);
 const lowPosition=1-clip(position);
 const r3=Math.log(last.c/c.at(-4))/(sigma*Math.sqrt(3));
 const prior3=Math.log(c.at(-4)/c.at(-7))/(sigma*Math.sqrt(3));
 const acceleration=sigmoid((r3-prior3)/2);
 const olderLow=Math.min(...c.slice(-20,-3));
 const recentLow=Math.min(...c.slice(-3));
 const stabilization=sigmoid(Math.log(recentLow/olderLow)/sigma);
 const depth=Math.log(peak20/low20)/sigma;
 const rebound=Math.log(last.c/low20)/sigma;
 const ma5=avg(c.slice(-5));
 const confirmed=r3>0&&last.c>=ma5&&rebound>=.5;
 const context=clip((depth-1)/3);
 const reversalRaw=100*(.20*lowPosition+.25*recovery+.20*stabilization+.20*acceleration+.15*activity)*(.35+.65*context)*(.5+.5*stabilization)*liqGate*gapPenalty;
 const reversal=confirmed?reversalRaw:Math.min(59,reversalRaw);
 const branches={reversal,pullback,breakout};
 const branch=Object.keys(branches).sort((a,b)=>branches[b]-branches[a])[0];
 const branchNames={reversal:'止跌转折型',pullback:'趋势回撤型',breakout:'突破适配型'};
 const eligible=volumeValid&&liquidity>=20&&last.v>0&&quoteGap<=5;
 const entry=eligible?branches[branch]:Math.min(39,branches[branch]);
 const reasons=[],risks=[],conditions=[];
 if(branch==='reversal'){
  reasons.push('近20根收盘区间位置 '+(100*clip(position)).toFixed(0)+'%，历史回落幅度 '+(100*(peak20/low20-1)).toFixed(1)+'%');
  if(r3>0)reasons.push('最近3日收盘动量已转正，短期恢复 '+r3.toFixed(2)+' 个标准化单位');else risks.push('最近3日收盘动量仍未转正');
  if(recentLow>=olderLow)reasons.push('最近3根收盘未低于此前17根最低收盘');else risks.push('最近3根仍包含新的20根收盘低点，止跌证据不完整');
  if(r3>prior3)reasons.push('最近3日动量较此前3日改善');
  if(confirmed)reasons.push('末日收盘达到MA5，且已脱离20根最低收盘至少0.5个波动尺度');else conditions.push('等待3日动量转正、收盘达到MA5并离开低点至少0.5个波动尺度；未确认分支最高59分');
  if(trend<40)risks.push('中期趋势仍弱；这是反转试探，不是趋势已经反转的保证');
 }else if(branch==='pullback'){
  reasons.push('中期趋势分 '+trend.toFixed(0)+'；距离20根最高收盘回撤 '+(dd*100).toFixed(1)+'%');
  reasons.push('回撤位置适配 '+(pullLocation*100).toFixed(0)+' /100，短期恢复项 '+(recovery*100).toFixed(0)+' /100');
  conditions.push('观察回撤是否停止、随后收盘能否保持恢复；不把单日低价视为支撑已确认');
 }else{
  reasons.push('相对前20根最高收盘距离 '+distance.toFixed(2)+' 个波动尺度');
  if(price<=high20)risks.push('当前报价尚未高于前20根最高收盘，不能称为已突破');
  conditions.push('等待完整日收盘站上前高并观察是否跌回区间；当前评分不验证连续站稳');
 }
 if(volumeValid)reasons.push('近3日均量为此前30日成交中位数的 '+relative.toFixed(2)+' 倍');
 if(relative!==null&&relative<1)risks.push('相对成交量不足1倍，缺少放量支持');
 if(liquidity<40)risks.push('绝对流动性代理偏弱，实际成交及价差风险可能较大');
 if(dd<0)risks.push('报价超过近期收盘高点，留意追高和报价失真');
 if(!volumeValid)risks.push('历史成交中位数不足1件，相对量不可用，入场总分最高39');
 if(liquidity<20)risks.push('流动性代理低于20，入场总分最高39');
 if(last.v===0)risks.push('最近完整日成交为零，入场总分最高39');
 if(quoteGap>5)risks.push('报价偏离末日收盘超过5个波动尺度，入场总分最高39');
 const invalidation=branch==='breakout'?high20:low20;
 const warnings=['日K为悠悠在售报价，量为全平台代理；流动性不是订单簿深度。','参数未经收益寻优或样本外盈利验证；入场总分为分支最大适配分经风险限制，不是上涨概率。'];
 return {ok:true,version:VERSION,asOf:last.day,price,trend,pullback,breakout,reversal,entry,branch,branchName:branchNames[branch],liquidity,relativeVolume:relative,eligible,
 status:!eligible?'证据不足 / 暂缓':entry>=65?'可关注 / '+branchNames[branch]:entry>=40?'等待确认 / '+branchNames[branch]:'暂缓 / '+branchNames[branch],
 reasons,risks,conditions,invalidation:{price:invalidation,note:branch==='breakout'?'若突破后完整日收盘重新跌回前高以下，突破依据减弱；非自动止损价':'若后续完整日收盘跌破20根最低收盘，企稳依据减弱；非保证有效的支撑或止损价'},
 features:{sigma,z7,z30,ma20,ma5,high20,low20,drawdown:dd,quoteGap,nonzeroDays30:nz*30,r3,prior3,acceleration,stabilization,position,depth,rebound,confirmed},
 quality:{rows:rows.length,priceCoverage:100,relativeVolumeAvailable:volumeValid},warnings};
}
function parseDate(date){if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return null;let t=Date.parse(date+'T00:00:00Z');return Number.isFinite(t)&&new Date(t).toISOString().slice(0,10)===date?t:null;}
function historical(payload,date,now=Date.now()){
 const t=parseDate(date);if(t===null||t+DAY>now)return {ok:false,reason:'请选择已收盘的有效UTC日期'};
 let k;try{k=prefix(payload,t+DAY);}catch(e){return {ok:false,reason:e.message};}
 if(k.asOf!==date)return {ok:false,reason:'所选日无有效日K，不使用邻日替代'};
 const current=evaluate(payload,k.rows.at(-1).c,t+DAY);
 return {ok:current.ok,reason:current.reason,date,timing:'D日收盘后可计算；不是D日盘中信号',current,legacy:L.historicalScore(payload,date,now)};
}
function ranks(a){let s=a.map((v,i)=>({v,i})).sort((a,b)=>a.v-b.v),r=[];for(let i=0;i<s.length;){let j=i+1;while(j<s.length&&s[j].v===s[i].v)j++;for(let k=i;k<j;k++)r[s[k].i]=(i+j-1)/2;i=j;}return r;}
function corr(x,y){if(x.length<3)return null;const a=ranks(x),b=ranks(y),ma=avg(a),mb=avg(b);let num=0,da=0,db=0;for(let i=0;i<a.length;i++){num+=(a[i]-ma)*(b[i]-mb);da+=(a[i]-ma)**2;db+=(b[i]-mb)**2;}return da&&db?num/Math.sqrt(da*db):null;}
async function backtest(payload,opts={},progress=()=>{},now=Date.now()){
 const k=prefix(payload,Math.floor(now/DAY)*DAY),step=Math.max(1,Number(opts.step)||7),samples=[];let rejected=0;
 for(let i=59;i<k.rows.length;i+=step){
 const r=k.rows[i],h=historical(payload,r.day,now);
 if(h.ok){const o=L.historicalOutcomes(payload,r.day,now);if(o.periods.length===3&&o.periods.every(p=>Number.isFinite(p.changePct))&&h.legacy.ok){
 samples.push({date:r.day,trend:h.current.trend,pullback:h.current.pullback,breakout:h.current.breakout,reversal:h.current.reversal,entry:h.current.entry,eligible:h.current.eligible,oldStrength:h.legacy.score.total,oldEntry:h.legacy.entry.total,momentum30:h.current.features.z30,...Object.fromEntries(o.periods.map(p=>['d'+p.days,p.changePct]))});
 }else rejected++;}else rejected++;
 if(i%10<step){progress(i/k.rows.length);await new Promise(r=>setTimeout(r,0));}
 }
 const keys=['entry','reversal','trend','pullback','breakout','oldStrength','oldEntry','momentum30'];
 const stats=keys.map(key=>({key,n:samples.length,ic7:corr(samples.map(s=>s[key]),samples.map(s=>s.d7)),ic14:corr(samples.map(s=>s[key]),samples.map(s=>s.d14)),ic30:corr(samples.map(s=>s[key]),samples.map(s=>s.d30)),buckets:[[0,40],[40,65],[65,101]].filter(()=>key!=='momentum30').map(([lo,hi])=>{const a=samples.filter(s=>s[key]>=lo&&s[key]<hi);return {range:lo+'–'+(hi-1),n:a.length,avg30:a.length?avg(a.map(s=>s.d30)):null,median30:a.length?median(a.map(s=>s.d30)):null,positiveRate:a.length?a.filter(s=>s.d30>0).length/a.length:null};})}));
 return {version:VERSION,step,n:samples.length,rejected,stats,samples,note:'同一组新旧均可评分且7/14/30天端点到期的日期。描述性报价检验；非交易收益、非样本外验证。默认7日间隔仍存在持有期重叠。'};
}
function lastClose(payload,now=Date.now()){
 const k=prefix(payload,Math.floor(now/DAY)*DAY);
 if(!k.rows.length)throw Error('缺少完整UTC日收盘');
 return k.rows[k.rows.length-1].c;
}
const api={VERSION,evaluate,historical,backtest,lastClose,parseDate};root.MarketLensLab=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
