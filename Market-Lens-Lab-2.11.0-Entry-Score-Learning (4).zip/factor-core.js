/* Market Lens Lab · factor-core (lab-2.4)
 *
 * Three layers, pure functions, no DOM / network:
 *   L1 大盘状态  marketRegime()      — index-only, same value for every item
 *   L2 选品分    featuresAt()+score() — cross-sectional linear factor score (learnable)
 *   L3 买点形态  labBranches()        — lab-2.1 branch maths ported to the series (explanatory)
 * Research / learning:
 *   buildPanel()    walk every (item, day) with features from data <= day only, forward returns
 *   crossIC() quantiles() portfolioSim() timingIC() itemTimingIC() bootstrapMeanCI()
 *   train()         purged walk-forward ridge / IC-weighted, holdout test, gates
 *   calibrate()     score percentile bucket -> historical forward excess stats
 *
 * No-look-ahead contract: featuresAt(s, i, m) reads s[0..i] and m[..day(i)] only.
 * Forward returns are computed in buildPanel() and never enter featuresAt().
 */
(function (root) {
  'use strict';
  const VERSION = 'factor-2.10.0';
  const EX = root.MarketLensExecution || (typeof require === 'function' ? require('./execution-core.js') : null);
  const DAY = 86400000;
  const LN = Math.log;
  const clip = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const S = x => (1 + Math.tanh(x)) / 2;
  const isNum = x => typeof x === 'number' && Number.isFinite(x);

  // ---------------------------------------------------------------------------
  // numeric helpers
  // ---------------------------------------------------------------------------
  function num(x) {
    if (x === null || x === undefined || typeof x === 'boolean' || typeof x === 'object') return null;
    const s = String(x).trim().replace(/,/g, '');
    if (!s || !/^[-+]?\d+(?:\.\d+)?(?:e[-+]?\d+)?$/i.test(s)) return null;
    const v = Number(s);
    return Number.isFinite(v) ? v : null;
  }
  function mean(a) { let s = 0; for (let i = 0; i < a.length; i++) s += a[i]; return a.length ? s / a.length : NaN; }
  function median(a) {
    if (!a.length) return NaN;
    const s = Array.from(a).sort((x, y) => x - y), m = s.length >> 1;
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  }
  function quantile(sorted, q) {
    if (!sorted.length) return NaN;
    const ix = (sorted.length - 1) * q, lo = Math.floor(ix), hi = Math.ceil(ix);
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (ix - lo);
  }
  function std(a) {
    if (a.length < 2) return NaN;
    const m = mean(a); let s = 0;
    for (let i = 0; i < a.length; i++) s += (a[i] - m) * (a[i] - m);
    return Math.sqrt(s / (a.length - 1));
  }
  // Average ranks (ties share the mean rank), 0-based.
  function ranks(a) {
    const idx = Array.from(a, (v, i) => i).sort((x, y) => a[x] - a[y]);
    const r = new Float64Array(a.length);
    for (let i = 0; i < idx.length;) {
      let j = i + 1;
      while (j < idx.length && a[idx[j]] === a[idx[i]]) j++;
      const avg = (i + j - 1) / 2;
      for (let k = i; k < j; k++) r[idx[k]] = avg;
      i = j;
    }
    return r;
  }
  function pearson(x, y) {
    const n = x.length; if (n < 3) return null;
    const mx = mean(x), my = mean(y); let sxy = 0, sxx = 0, syy = 0;
    for (let i = 0; i < n; i++) { const a = x[i] - mx, b = y[i] - my; sxy += a * b; sxx += a * a; syy += b * b; }
    return sxx > 0 && syy > 0 ? sxy / Math.sqrt(sxx * syy) : null;
  }
  function spearman(x, y) { return x.length < 3 ? null : pearson(ranks(x), ranks(y)); }
  // Inverse normal CDF (Acklam) for rank-gaussianisation.
  function probit(p) {
    const a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239];
    const b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572];
    const c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
    const d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416];
    const pl = 0.02425;
    p = clip(p, 1e-9, 1 - 1e-9);
    let q, r;
    if (p < pl) { q = Math.sqrt(-2 * LN(p)); return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    if (p > 1 - pl) { q = Math.sqrt(-2 * LN(1 - p)); return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    q = p - 0.5; r = q * q;
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  }
  function gaussRank(a) { const r = ranks(a), n = a.length; return Array.from(r, x => probit((x + 0.5) / n)); }
  // Seeded PRNG (bootstrap reproducibility).
  function rng(seed) { let s = seed >>> 0 || 1; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
  const dayStr = d => new Date(d * DAY).toISOString().slice(0, 10);
  const dayOf = t => Math.floor(t / DAY);
  // FirePulse stamps daily bars in Beijing time: item K at 00:00 UTC (08:00 CST)
  // and the category index at 16:00 UTC (= 00:00 CST of the bar's own date).
  // Labelling bars by their Beijing (UTC+8) calendar date aligns both series;
  // plain UTC labelling put the index one day early (verified: same-day return
  // correlation item vs index peaks only after this shift, median ≈ 0.27).
  const TZ_MS = 8 * 3600000;
  const barDay = t => Math.floor((t + TZ_MS) / DAY);

  // ---------------------------------------------------------------------------
  // Series: calendar-aligned daily bars. Missing days are forward-filled with the
  // previous close (v = 0, real = 0); `stale[i]` counts consecutive filled days.
  // Row validation mirrors legacy kchart(): 7 columns, OHLC > 0, l <= min(o,c),
  // h >= max(o,c), v >= 0. Same-day duplicates keep the last row.
  // opts.end (ms): rows with t >= end are excluded (default today 00:00 UTC →
  // only completed UTC days, never the live bar).
  // opts.cols: 'item' [t,o,c,l,h,v,turnover] | 'market' [t,o,c,l,h,turnover,volume]
  // ---------------------------------------------------------------------------
  function toSeries(payload, opts) {
    const o = opts || {};
    const end = isNum(o.end) ? o.end : dayOf(Date.now()) * DAY;
    const market = o.cols === 'market';
    const raw = Array.isArray(payload) ? payload : payload && Array.isArray(payload.data) ? payload.data : null;
    if (!raw) return { ok: false, reason: '日K响应结构无效' };
    if (raw.length > 20000) return { ok: false, reason: '日K记录过多' };
    const byDay = new Map(); let dropped = 0;
    for (const r of raw) {
      if (!Array.isArray(r) || r.length < (market ? 3 : 7)) { dropped++; continue; }
      let t = num(r[0]);
      if (t === null) { dropped++; continue; }
      if (t < 1e12) t *= 1000;
      if (t >= end || t < 0) continue;
      const op = num(r[1]), c = num(r[2]), l = num(r[3]), h = num(r[4]);
      const v = market ? 0 : num(r[5]);
      if (market) {
        if (c === null || c <= 0) { dropped++; continue; }
        byDay.set(barDay(t), [c, c, c, c, 0]);
        continue;
      }
      if (op === null || c === null || l === null || h === null || v === null || v < 0 ||
        Math.min(op, c, l, h) <= 0 || l > Math.min(op, c) || h < Math.max(op, c)) { dropped++; continue; }
      byDay.set(barDay(t), [op, h, l, c, v]);
    }
    const days = Array.from(byDay.keys()).sort((a, b) => a - b);
    if (!days.length) return { ok: false, reason: '没有有效日K', dropped };
    const day0 = days[0], n = days[days.length - 1] - day0 + 1;
    const O = new Float64Array(n), H = new Float64Array(n), Lw = new Float64Array(n), C = new Float64Array(n), V = new Float64Array(n);
    const real = new Uint8Array(n), stale = new Uint16Array(n);
    let prev = null;
    for (let i = 0; i < n; i++) {
      const b = byDay.get(day0 + i);
      if (b) { O[i] = b[0]; H[i] = b[1]; Lw[i] = b[2]; C[i] = b[3]; V[i] = b[4]; real[i] = 1; stale[i] = 0; prev = b[3]; }
      else { O[i] = H[i] = Lw[i] = C[i] = prev; V[i] = 0; real[i] = 0; stale[i] = Math.min(65535, (i ? stale[i - 1] : 0) + 1); }
    }
    return { ok: true, day0, n, o: O, h: H, l: Lw, c: C, v: V, real, stale, dropped, firstDay: dayStr(day0), lastDay: dayStr(day0 + n - 1) };
  }
  // Merge a short, freshly fetched window (`recent`) into a cached series
  // (`old`). Real bars in `recent` are authoritative for the days they cover
  // (the feed may revise the last few bars); everything before recent.day0 is
  // taken from the cache. Forward-fill flags are recomputed from scratch, so
  // the result is indistinguishable from a full fetch. Returns `recent` alone
  // when the two windows do not touch (a gap would corrupt the calendar), and
  // `old` when `recent` is unusable.
  function mergeSeries(old, recent) {
    if (!recent || !recent.ok) return old && old.ok ? old : recent;
    if (!old || !old.ok) return recent;
    const oldLast = old.day0 + old.n - 1;
    if (recent.day0 > oldLast + 1) return Object.assign({}, recent, { gap: true });
    const byDay = new Map();
    for (let i = 0; i < old.n; i++) if (old.real[i] && old.day0 + i < recent.day0) byDay.set(old.day0 + i, [old.o[i], old.h[i], old.l[i], old.c[i], old.v[i]]);
    for (let i = 0; i < recent.n; i++) if (recent.real[i]) byDay.set(recent.day0 + i, [recent.o[i], recent.h[i], recent.l[i], recent.c[i], recent.v[i]]);
    const days = Array.from(byDay.keys()).sort((a, b) => a - b);
    if (!days.length) return recent;
    const day0 = days[0], n = days[days.length - 1] - day0 + 1;
    const O = new Float64Array(n), H = new Float64Array(n), Lw = new Float64Array(n), C = new Float64Array(n), V = new Float64Array(n);
    const real = new Uint8Array(n), stale = new Uint16Array(n);
    let prev = null;
    for (let i = 0; i < n; i++) {
      const b = byDay.get(day0 + i);
      if (b) { O[i] = b[0]; H[i] = b[1]; Lw[i] = b[2]; C[i] = b[3]; V[i] = b[4]; real[i] = 1; stale[i] = 0; prev = b[3]; }
      else { O[i] = H[i] = Lw[i] = C[i] = prev; V[i] = 0; real[i] = 0; stale[i] = Math.min(65535, (i ? stale[i - 1] : 0) + 1); }
    }
    return { ok: true, day0, n, o: O, h: H, l: Lw, c: C, v: V, real, stale, dropped: (old.dropped || 0) + (recent.dropped || 0), firstDay: dayStr(day0), lastDay: dayStr(day0 + n - 1), merged: true };
  }
  // Slice a series so that its last index is `day` (history-only view).
  function truncate(s, day) {
    if (!s || !s.ok) return s;
    const n = Math.min(s.n, day - s.day0 + 1);
    if (n <= 0) return { ok: false, reason: '所选日之前没有数据' };
    const sub = a => a.subarray(0, n);
    return Object.assign({}, s, { n, o: sub(s.o), h: sub(s.h), l: sub(s.l), c: sub(s.c), v: sub(s.v), real: sub(s.real), stale: sub(s.stale), lastDay: dayStr(s.day0 + n - 1) });
  }
  const mIdx = (m, day) => (m && m.ok ? day - m.day0 : -1);
  const mClose = (m, day) => { const j = mIdx(m, day); return j >= 0 && j < m.n ? m.c[j] : null; };

  // ---------------------------------------------------------------------------
  // L1 · market regime (index close only). Volatility-scaled momentum over
  // 7/30/90 days, drawdown from the 180-day high. score 0–100, 50 = neutral.
  // ---------------------------------------------------------------------------
  const REGIME = { weights: [[7, 0.25], [30, 0.45], [90, 0.30]], sigmaWindow: 60, sigmaFloor: 0.002, width: 1.2 };
  function marketRegime(m, day) {
    const j = mIdx(m, day);
    if (j < 95 || j >= m.n) return null;
    const c = m.c, r = [];
    for (let i = j - REGIME.sigmaWindow + 1; i <= j; i++) r.push(LN(c[i] / c[i - 1]));
    const sig = Math.max(REGIME.sigmaFloor, std(r));
    let zs = {}, wz = 0;
    for (const [h, w] of REGIME.weights) { const z = LN(c[j] / c[j - h]) / (sig * Math.sqrt(h)); zs['z' + h] = z; wz += w * z; }
    let hi = 0; for (let i = Math.max(0, j - 179); i <= j; i++) hi = Math.max(hi, c[i]);
    const dd = c[j] / hi - 1;
    let ma20 = 0, ma20p = 0;
    for (let i = j - 19; i <= j; i++) ma20 += c[i] / 20;
    for (let i = j - 24; i <= j - 5; i++) ma20p += c[i] / 20;
    const score = 100 * S(wz / REGIME.width);
    const label = score >= 65 ? '偏强' : score >= 45 ? '中性' : score >= 30 ? '偏弱' : '显著弱势';
    return { day: dayStr(day), close: c[j], z7: zs.z7, z30: zs.z30, z90: zs.z90, mz: wz, sigmaDaily: sig, drawdown180: dd, ma20Slope: LN(ma20 / ma20p), score, label };
  }

  // ---------------------------------------------------------------------------
  // L2 · feature library. Every feature is scale-free (own-vol z, log ratios,
  // range positions) so different items are comparable. Returns null + reason
  // when history is too short or too many days were forward-filled.
  // ---------------------------------------------------------------------------
  const FEATURE_MIN_ROWS = 100;
  const FEATURE_DEFS = {
    mom3: '3日动量（σ标准化）', mom7: '7日动量（σ标准化）', mom30: '30日动量（σ标准化）', mom90: '90日动量（σ标准化）',
    mom30s7: '30日动量·跳过最近7日', ret7: '7日原始对数收益', ret30: '30日原始对数收益',
    volLvl: '波动率水平 ln σ', volRatio: '波动扩张 σ20/σ60',
    relVol3: '近3日量/前30日中位量', volTrend: '近7日量/前30日均量', liq: '流动性 ln(1+30日中位量)', zeroVol: '30日零成交占比',
    logPrice: '价格水平 ln 价格', pos90: '90日区间位置', pos180: '180日区间位置', ddHigh: '距180日最高（对数）', upLow: '距180日最低（对数）',
    ma20dist: '偏离MA20（σ）', ma5_20: 'MA5/MA20（σ）', ma20slope: 'MA20斜率（σ）', ma60dist: '偏离MA60（σ）', rsi14: 'RSI14',
    trendR2: '30日趋势平滑度 R²×方向', maxRet: '30日最大单日涨幅（σ）', minRet: '30日最大单日跌幅（σ）', skew60: '60日收益偏度',
    obvAgree: 'OBV20一致度', beta: 'β（90日，对大盘）', betaAsym: 'β跌−β涨', idioVol: '特质波动 ln σε', corrMkt: '与大盘相关系数',
    alpha7: '7日余量α（σε标准化）', alpha30: '30日余量α（σε标准化）', alpha90: '90日余量α（σε标准化）',
    labEntry: 'lab-2.1 入场总分', labReversal: 'lab-2.1 止跌转折', labPullback: 'lab-2.1 趋势回撤', labBreakout: 'lab-2.1 突破适配', labTrend: 'lab-2.1 趋势分',
  };
  const FEATURE_KEYS = Object.keys(FEATURE_DEFS);

  function windowReturns(c, from, to) { // log returns for bars from..to (each vs previous bar)
    const out = new Float64Array(Math.max(0, to - from + 1));
    for (let i = from; i <= to; i++) out[i - from] = LN(c[i] / c[i - 1]);
    return out;
  }
  function rsiAt(c, i, p = 14, look = 60) {
    const s = Math.max(1, i - look + 1);
    if (i - s < p) return null;
    let g = 0, l = 0;
    for (let k = s; k < s + p; k++) { const d = c[k] - c[k - 1]; g += Math.max(d, 0); l += Math.max(-d, 0); }
    g /= p; l /= p;
    for (let k = s + p; k <= i; k++) { const d = c[k] - c[k - 1]; g = (g * (p - 1) + Math.max(d, 0)) / p; l = (l * (p - 1) + Math.max(-d, 0)) / p; }
    if (g === 0 && l === 0) return 50;
    if (l === 0) return 100;
    return 100 - 100 / (1 + g / l);
  }

  function featuresAt(s, i, m, opts) {
    const o = opts || {};
    if (!s || !s.ok) return { ok: false, reason: '序列无效' };
    if (i < FEATURE_MIN_ROWS - 1 || i >= s.n) return { ok: false, reason: '历史不足' + FEATURE_MIN_ROWS + '天' };
    const c = s.c, v = s.v;
    let filled = 0; for (let k = i - 59; k <= i; k++) if (!s.real[k]) filled++;
    if (filled > 6) return { ok: false, reason: '近60天缺日超过6天' };
    if (s.stale[i] > 3) return { ok: false, reason: '末日报价已连续' + s.stale[i] + '天无更新' };
    const r60 = windowReturns(c, i - 59, i), r20 = r60.subarray(40);
    const sig = Math.max(0.004, std(r60));
    const f = {};
    const lr = (a, b) => LN(c[b] / c[a]);
    f.mom3 = lr(i - 3, i) / (sig * Math.sqrt(3));
    f.mom7 = lr(i - 7, i) / (sig * Math.sqrt(7));
    f.mom30 = lr(i - 30, i) / (sig * Math.sqrt(30));
    f.mom90 = lr(i - 90, i) / (sig * Math.sqrt(90));
    f.mom30s7 = lr(i - 37, i - 7) / (sig * Math.sqrt(30));
    f.ret7 = lr(i - 7, i);
    f.ret30 = lr(i - 30, i);
    f.volLvl = LN(sig);
    f.volRatio = LN(Math.max(0.002, std(r20)) / sig);
    const v3 = (v[i] + v[i - 1] + v[i - 2]) / 3;
    const base30 = median(v.subarray(i - 32, i - 2));
    f.relVol3 = LN((v3 + 1) / (base30 + 1));
    let a7 = 0, a30 = 0;
    for (let k = i - 6; k <= i; k++) a7 += v[k] / 7;
    for (let k = i - 36; k <= i - 7; k++) a30 += v[k] / 30;
    f.volTrend = LN((a7 + 1) / (a30 + 1));
    const last30v = v.subarray(i - 29, i + 1);
    f.liq = Math.log1p(median(last30v));
    let z = 0; for (let k = 0; k < 30; k++) if (last30v[k] === 0) z++;
    f.zeroVol = z / 30;
    f.logPrice = LN(c[i]);
    const rangePos = w => {
      let lo = Infinity, hi = -Infinity;
      for (let k = Math.max(0, i - w + 1); k <= i; k++) { lo = Math.min(lo, c[k]); hi = Math.max(hi, c[k]); }
      return { lo, hi, pos: hi > lo ? (c[i] - lo) / (hi - lo) : 0.5 };
    };
    const p90 = rangePos(90), p180 = rangePos(180);
    f.pos90 = p90.pos; f.pos180 = p180.pos;
    f.ddHigh = LN(c[i] / p180.hi); f.upLow = LN(c[i] / p180.lo);
    let ma5 = 0, ma20 = 0, ma20p = 0, ma60 = 0;
    for (let k = i - 4; k <= i; k++) ma5 += c[k] / 5;
    for (let k = i - 19; k <= i; k++) ma20 += c[k] / 20;
    for (let k = i - 24; k <= i - 5; k++) ma20p += c[k] / 20;
    for (let k = i - 59; k <= i; k++) ma60 += c[k] / 60;
    f.ma20dist = LN(c[i] / ma20) / sig;
    f.ma5_20 = LN(ma5 / ma20) / sig;
    f.ma20slope = LN(ma20 / ma20p) / sig;
    f.ma60dist = LN(c[i] / ma60) / sig;
    f.rsi14 = rsiAt(c, i);
    // trend smoothness: R² of ln price on time over 30 bars, signed by slope
    { let sx = 0, sy = 0, sxx = 0, sxy = 0, syy = 0; const n = 30;
      for (let k = 0; k < n; k++) { const y = LN(c[i - n + 1 + k]); sx += k; sy += y; sxx += k * k; sxy += k * y; syy += y * y; }
      const cov = sxy - sx * sy / n, vx = sxx - sx * sx / n, vy = syy - sy * sy / n;
      f.trendR2 = vy > 1e-12 ? Math.sign(cov) * (cov * cov) / (vx * vy) : 0; }
    { let mx = -Infinity, mn = Infinity; for (let k = 30; k < 60; k++) { mx = Math.max(mx, r60[k]); mn = Math.min(mn, r60[k]); }
      f.maxRet = mx / sig; f.minRet = mn / sig; }
    { const mu = mean(r60); let m2 = 0, m3 = 0; for (let k = 0; k < 60; k++) { const d = r60[k] - mu; m2 += d * d; m3 += d * d * d; }
      m2 /= 60; m3 /= 60; f.skew60 = m2 > 1e-12 ? m3 / Math.pow(m2, 1.5) : 0; }
    { let obv = 0, vol = 0;
      for (let k = i - 19; k <= i; k++) { obv += (c[k] > c[k - 1] ? 1 : c[k] < c[k - 1] ? -1 : 0) * v[k]; vol += v[k]; }
      const pr = c[i] / c[i - 20] - 1;
      f.obvAgree = vol > 0 && pr !== 0 ? (obv / vol) * Math.sign(pr) : 0; }
    // market-relative block
    f.beta = f.betaAsym = f.idioVol = f.corrMkt = f.alpha7 = f.alpha30 = f.alpha90 = null;
    if (m && m.ok) {
      const day = s.day0 + i, xs = [], ys = [];
      for (let k = i - 89; k <= i; k++) {
        const d = s.day0 + k, j = mIdx(m, d);
        if (j < 1 || j >= m.n || !s.real[k] || !s.real[k - 1]) continue;
        xs.push(LN(m.c[j] / m.c[j - 1])); ys.push(LN(c[k] / c[k - 1]));
      }
      const jEnd = mIdx(m, day);
      if (xs.length >= 60 && jEnd >= 90 && jEnd < m.n) {
        const mx = mean(xs), my = mean(ys); let sxx = 0, sxy = 0, syy = 0;
        for (let k = 0; k < xs.length; k++) { const a = xs[k] - mx, b = ys[k] - my; sxx += a * a; sxy += a * b; syy += b * b; }
        if (sxx > 1e-12 && syy > 1e-12) {
          const beta = clip(sxy / sxx, -2, 4);
          f.beta = beta; f.corrMkt = sxy / Math.sqrt(sxx * syy);
          const res = ys.map((y, k) => y - beta * xs[k]);
          const iv = Math.max(0.003, std(res));
          f.idioVol = LN(iv);
          // alpha over calendar windows using closes (robust to the aligned-day filter)
          const alphaZ = h => { const jm = jEnd - h; if (jm < 0) return null; const ri = lr(i - h, i), rm = LN(m.c[jEnd] / m.c[jm]); return (ri - beta * rm) / (iv * Math.sqrt(h)); };
          f.alpha7 = alphaZ(7); f.alpha30 = alphaZ(30); f.alpha90 = alphaZ(90);
          const up = [], dn = [];
          for (let k = 0; k < xs.length; k++) (xs[k] >= 0 ? up : dn).push(k);
          const slope = idx => { if (idx.length < 12) return null; const X = idx.map(k => xs[k]), Y = idx.map(k => ys[k]); const a = mean(X), b = mean(Y); let q = 0, w = 0; for (let k = 0; k < X.length; k++) { q += (X[k] - a) * (X[k] - a); w += (X[k] - a) * (Y[k] - b); } return q > 1e-12 ? clip(w / q, -2, 4) : null; };
          const bu = slope(up), bd = slope(dn);
          f.betaAsym = bu !== null && bd !== null ? bd - bu : null;
        }
      }
    }
    if (!o.skipLab) {
      const lb = labBranches(s, i, c[i]);
      if (lb.ok) { f.labEntry = lb.entry; f.labReversal = lb.reversal; f.labPullback = lb.pullback; f.labBreakout = lb.breakout; f.labTrend = lb.trend; }
      else f.labEntry = f.labReversal = f.labPullback = f.labBreakout = f.labTrend = null;
    }
    return { ok: true, day: dayStr(s.day0 + i), close: c[i], sigma: sig, f };
  }

  // ---------------------------------------------------------------------------
  // L3 · lab-2.1 branch maths on the aligned series (identical to lab-core
  // evaluate() when the window has no gaps; filled days are flat bars here).
  // price = live quote in item mode, the day's close in history / scan mode.
  // ---------------------------------------------------------------------------
  function labBranches(s, i, price) {
    const fail = reason => ({ ok: false, reason });
    if (i < 59) return fail('需至少60根日K');
    const from = Math.max(0, i - 179), c = Array.from(s.c.subarray(from, i + 1)), v = Array.from(s.v.subarray(from, i + 1));
    const last = c[c.length - 1], lastV = v[v.length - 1];
    if (!isNum(price) || price <= 0) return fail('报价无效');
    const at = k => c[c.length + k];
    const w31 = c.slice(-31), ret = w31.slice(1).map((x, k) => LN(x / w31[k]));
    const med = median(ret), sigma = Math.max(0.005, 1.4826 * median(ret.map(x => Math.abs(x - med))));
    const z7 = clip(LN(last / at(-8)) / (sigma * Math.sqrt(7)), -4, 4);
    const z30 = clip(LN(last / at(-31)) / (sigma * Math.sqrt(30)), -4, 4);
    const trend = 100 * S((0.4 * z7 + 0.6 * z30) / 2);
    const baseVol = median(v.slice(-33, -3)), recentVol = mean(v.slice(-3));
    const volumeValid = baseVol >= 1, relative = volumeValid ? recentVol / baseVol : null;
    const activity = volumeValid ? S(LN(Math.max(0.01, relative))) : 0.5;
    const nz = v.slice(-30).filter(x => x > 0).length / 30;
    const liquidity = 100 * Math.sqrt(clip(Math.log1p(median(v.slice(-30))) / LN(501)) * nz);
    const ma20 = mean(c.slice(-20)), high20 = Math.max(...c.slice(-21, -1));
    const peak20 = Math.max(...c.slice(-20)), dd = (peak20 - price) / peak20;
    const extension = LN(price / ma20) / sigma;
    const recovery = S(LN(last / at(-4)) / (sigma * Math.sqrt(3)));
    const distance = LN(price / high20) / sigma;
    const trendGate = clip((trend - 35) / 35), liqGate = 0.35 + 0.65 * clip(liquidity / 50);
    const quoteGap = Math.abs(LN(price / last)) / sigma, gapPenalty = Math.exp(-Math.max(0, quoteGap - 2) / 3);
    const pullLocation = Math.exp(-0.5 * Math.pow((dd / sigma - 1.5) / 2, 2));
    const pullback = 100 * trendGate * liqGate * gapPenalty * (0.65 * pullLocation + 0.35 * recovery) * Math.exp(-Math.max(0, -extension - 3) / 3);
    const breakoutLocation = S(distance * 2) * Math.exp(-Math.max(0, distance - 2) / 3);
    const breakout = 100 * trendGate * liqGate * gapPenalty * (0.65 * breakoutLocation + 0.35 * activity);
    const low20 = Math.min(...c.slice(-20));
    const position = (price - low20) / Math.max(peak20 - low20, price * 0.001);
    const r3 = LN(last / at(-4)) / (sigma * Math.sqrt(3)), prior3 = LN(at(-4) / at(-7)) / (sigma * Math.sqrt(3));
    const acceleration = S((r3 - prior3) / 2);
    const olderLow = Math.min(...c.slice(-20, -3)), recentLow = Math.min(...c.slice(-3));
    const stabilization = S(LN(recentLow / olderLow) / sigma);
    const depth = LN(peak20 / low20) / sigma, rebound = LN(last / low20) / sigma;
    const ma5 = mean(c.slice(-5));
    const confirmed = r3 > 0 && last >= ma5 && rebound >= 0.5;
    const context = clip((depth - 1) / 3);
    const reversalRaw = 100 * (0.2 * (1 - clip(position)) + 0.25 * recovery + 0.2 * stabilization + 0.2 * acceleration + 0.15 * activity) * (0.35 + 0.65 * context) * (0.5 + 0.5 * stabilization) * liqGate * gapPenalty;
    const reversal = confirmed ? reversalRaw : Math.min(59, reversalRaw);
    const br = { reversal, pullback, breakout };
    const branch = Object.keys(br).sort((a, b) => br[b] - br[a])[0];
    const eligible = volumeValid && liquidity >= 20 && lastV > 0 && quoteGap <= 5;
    const entry = eligible ? br[branch] : Math.min(39, br[branch]);
    return { ok: true, entry, branch, reversal, pullback, breakout, trend, liquidity, relative, eligible, confirmed, sigma };
  }

  // ---------------------------------------------------------------------------
  // Model params & scoring. A model is a sparse linear score on fixed
  // winsorised + standardised features:
  //   z_k = clip((clip(x_k, lo, hi) − mu) / sd, −4, 4);  score = Σ w_k z_k
  // Missing features contribute 0 (neutral) and lower coverage.
  // ---------------------------------------------------------------------------
  function scoreFeatures(f, model) {
    if (!f || !model || !Array.isArray(model.features)) return null;
    let s = 0, used = 0, tot = 0;
    const parts = [];
    for (const p of model.features) {
      const aw = Math.abs(p.w); tot += aw;
      const x = f[p.key];
      if (!isNum(x)) { parts.push({ key: p.key, x: null, z: 0, contrib: 0, w: p.w }); continue; }
      const z = clip((clip(x, p.lo, p.hi) - p.mu) / (p.sd || 1), -4, 4);
      s += p.w * z; used += aw;
      parts.push({ key: p.key, x, z, contrib: p.w * z, w: p.w });
    }
    return { score: s, coverage: tot ? used / tot : 0, parts };
  }
  function percentileOf(score, sortedRef) {
    if (!isNum(score) || !sortedRef || !sortedRef.length) return null;
    let lo = 0, hi = sortedRef.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (sortedRef[mid] < score) lo = mid + 1; else hi = mid; }
    let eq = lo; while (eq < sortedRef.length && sortedRef[eq] === score) eq++;
    return 100 * ((lo + eq) / 2) / sortedRef.length;
  }

  // ---------------------------------------------------------------------------
  // Item filter rules (the user's universe). Shared by scan, backtest, learning,
  // the single-item view and the research scripts.
  //   · name rules (static, identity only): knife / StatTrak / souvenir gun skin /
  //     gun-skin wear / optional words;
  //   · price rule: in panels it is applied POINT-IN-TIME to the close of the
  //     decision day (no look-ahead: today's price never selects history);
  //     in scans to the latest known price.
  // Names follow FirePulse / 悠悠 market names, e.g.
  //   'AK-47 | 红线 (久经沙场)'   'AK-47（StatTrak™） | 红线 (久经沙场)'
  //   '双持贝瑞塔（纪念品） | 蔷薇 (崭新出厂)'   'M9 刺刀（★ StatTrak™） | 虎牙 (崭新出厂)'
  //   '运动手套（★） | 迈阿密风云 (久经沙场)'   '封装的涂鸦 | AK-47压枪 (靛蓝)'
  // ★ marks knives and gloves; gloves are recognised by 手套/裹手. Anything that is
  // not a knife/glove and carries a wear suffix is a gun skin; everything else
  // (graffiti, stickers, cases, agents…) is 'other' and only the price rule and
  // the optional words apply to it.
  // ---------------------------------------------------------------------------
  const WEARS = ['崭新出厂', '略有磨损', '久经沙场', '破损不堪', '战痕累累'];
  const DEFAULT_RULES = Object.freeze({ enabled: true, gunWears: Object.freeze(['崭新出厂', '略有磨损']), excludeKnife: true, excludeStatTrak: true, excludeSouvenir: true, priceMin: 30, priceMax: 20000, excludeWords: Object.freeze([]) });
  const WEAR_RE = /[(（]\s*(崭新出厂|略有磨损|久经沙场|破损不堪|战痕累累)\s*[)）]\s*$/;
  const GLOVE_RE = /手套|裹手/;
  function classifyName(name) {
    const n = String(name === null || name === undefined ? '' : name).trim();
    const m = n.match(WEAR_RE), wear = m ? m[1] : null;
    const star = n.indexOf('★') >= 0;
    const kind = star ? (GLOVE_RE.test(n) ? 'glove' : 'knife') : (wear ? 'gun' : 'other');
    return { kind, wear, statTrak: /stattrak/i.test(n), souvenir: n.indexOf('纪念品') >= 0 };
  }
  // Fill defaults and sanitise (settings may come from storage or an import).
  // priceMax null = no upper bound (JSON cannot store Infinity).
  function normRules(r) {
    const src = r && typeof r === 'object' ? r : {};
    const o = {};
    o.enabled = src.enabled === undefined ? DEFAULT_RULES.enabled : !!src.enabled;
    const wears = Array.isArray(src.gunWears) ? src.gunWears : DEFAULT_RULES.gunWears;
    o.gunWears = WEARS.filter(w => wears.indexOf(w) >= 0);
    for (const k of ['excludeKnife', 'excludeStatTrak', 'excludeSouvenir']) o[k] = src[k] === undefined ? DEFAULT_RULES[k] : !!src[k];
    const lo = src.priceMin === undefined ? DEFAULT_RULES.priceMin : Number(src.priceMin);
    o.priceMin = isNum(lo) && lo > 0 ? lo : 0;
    const hi = src.priceMax === undefined ? DEFAULT_RULES.priceMax : src.priceMax === null || src.priceMax === '' ? null : Number(src.priceMax);
    o.priceMax = isNum(hi) && hi > 0 ? hi : null;
    if (o.priceMax !== null && o.priceMax < o.priceMin) { const t = o.priceMax; o.priceMax = o.priceMin; o.priceMin = t; }
    const words = Array.isArray(src.excludeWords) ? src.excludeWords : String(src.excludeWords || '').split(/[,，、;；\s]+/);
    o.excludeWords = Array.from(new Set(words.map(w => String(w).trim()).filter(Boolean))).slice(0, 50);
    return o;
  }
  const RULE_REASONS = { knife: '刀具', stattrak: 'StatTrak™', souvenir: '纪念品枪皮', wear: '枪皮磨损不在范围', word: '名称含排除词', cheap: '价格低于下限', expensive: '价格高于上限' };
  // Name-only check. Returns null when accepted, else a reason code.
  function ruleReasonName(name, rules) {
    const r = rules;
    if (!r || !r.enabled) return null;
    const c = classifyName(name);
    if (r.excludeKnife && c.kind === 'knife') return 'knife';
    if (r.excludeStatTrak && c.statTrak) return 'stattrak';
    if (r.excludeSouvenir && c.souvenir && c.kind === 'gun') return 'souvenir';
    if (c.kind === 'gun' && r.gunWears.indexOf(c.wear) < 0) return 'wear';
    if (r.excludeWords && r.excludeWords.length) { const n = String(name || ''); if (r.excludeWords.some(w => n.indexOf(w) >= 0)) return 'word'; }
    return null;
  }
  // Price check. Unknown/invalid price returns null (caller decides; scans
  // re-check once the daily K is known).
  function ruleReasonPrice(price, rules) {
    const r = rules;
    if (!r || !r.enabled) return null;
    const p = Number(price);
    if (!isNum(p) || p <= 0) return null;
    if (p < r.priceMin) return 'cheap';
    if (r.priceMax !== null && p > r.priceMax) return 'expensive';
    return null;
  }
  function ruleCheck(name, price, rules) {
    const code = ruleReasonName(name, rules) || ruleReasonPrice(price, rules);
    return code ? { ok: false, code, text: RULE_REASONS[code] } : { ok: true, code: null, text: '' };
  }
  const fmtPrice = v => String(Math.round(v * 100) / 100);
  function rulesText(rules) {
    const r = normRules(rules);
    if (!r.enabled) return '未启用（不过滤商品）';
    const parts = [];
    parts.push(r.gunWears.length === WEARS.length ? '枪皮不限磨损' : r.gunWears.length ? '枪皮仅' + r.gunWears.join('/') : '不含枪皮');
    if (r.excludeKnife) parts.push('去刀具');
    if (r.excludeStatTrak) parts.push('去StatTrak™');
    if (r.excludeSouvenir) parts.push('去纪念品');
    parts.push(r.priceMax !== null ? '价格¥' + fmtPrice(r.priceMin) + '–' + fmtPrice(r.priceMax) : r.priceMin > 0 ? '价格≥¥' + fmtPrice(r.priceMin) : '不限价格');
    if (r.excludeWords.length) parts.push('排除词 ' + r.excludeWords.join('、'));
    return parts.join(' · ');
  }
  function rulesKey(rules) {
    const r = normRules(rules);
    return r.enabled ? JSON.stringify([r.gunWears, r.excludeKnife, r.excludeStatTrak, r.excludeSouvenir, r.priceMin, r.priceMax, r.excludeWords]) : 'off';
  }

  // ---------------------------------------------------------------------------
  // Panel: every (item, day) sample with features (history only) and forward
  // log returns y[h] = ln(C[t+lag+h] / C[t+lag]) (enter the day AFTER the
  // signal; lag = 1 by default). Samples where the entry/exit close is stale
  // for > 3 days are dropped for that horizon.
  // ---------------------------------------------------------------------------
  const PANEL_DEFAULTS = { step: 1, horizons: [7, 14, 30], lag: 1, keys: FEATURE_KEYS, startDay: -Infinity, endDay: Infinity, skipLab: false, minItemsPerDay: 1, tradable: null, rules: null };
  // Rows for one item. `tradable` = {minLiq, maxZeroVol} filters at build time
  // using only data up to the sample date (median 30d volume, zero-volume share).
  // `o._price` = {min, max} (from rules) keeps a row only if the close of the
  // sample day itself is inside the range — point-in-time, never today's price.
  function panelRowsFor(s, it, market, o, out) {
    if (!s || !s.ok) return 0;
    const keys = o.keys, K = keys.length, H = o.horizons;
    const pr = o._price || null;
    const skipLab = o.skipLab || !keys.some(k => k.startsWith('lab'));
    const minLiq = o.tradable && isNum(o.tradable.minLiq) ? LN(1 + o.tradable.minLiq) : null;
    const maxZ = o.tradable && isNum(o.tradable.maxZeroVol) ? o.tradable.maxZeroVol : null;
    const first = Math.max(FEATURE_MIN_ROWS - 1, o.startDay - s.day0);
    const last = Math.min(s.n - 1, o.endDay - s.day0);
    let rejected = 0;
    // align sampling to the calendar so different items share dates
    let i0 = first; const rem = ((s.day0 + i0) % o.step + o.step) % o.step; if (rem) i0 += o.step - rem;
    for (let i = i0; i <= last; i += o.step) {
      if (!s.real[i]) continue;
      if (pr && !(s.c[i] >= pr.min && (pr.max === null || s.c[i] <= pr.max))) { if (o._stats) o._stats.priceRows++; continue; }
      const fr = featuresAt(s, i, market, { skipLab });
      if (!fr.ok) { rejected++; continue; }
      if (minLiq !== null && !(fr.f.liq >= minLiq)) continue;
      if (maxZ !== null && !(fr.f.zeroVol <= maxZ)) continue;
      const x = new Float32Array(K);
      for (let k = 0; k < K; k++) { const val = fr.f[keys[k]]; x[k] = isNum(val) ? val : NaN; }
      const day = s.day0 + i, y = {}, ym = {};
      for (const h of H) {
        const a = i + o.lag, b = i + o.lag + h;
        if (a >= 0 && b < s.n && s.real[a] && s.real[b]) y[h] = LN(s.c[b] / s.c[a]); else y[h] = NaN;
        const ma = mClose(market, day + o.lag), mb = mClose(market, day + o.lag + h);
        ym[h] = ma && mb ? LN(mb / ma) : NaN;
      }
      out.push({ d: day, it, x, y, ym, close: s.c[i] });
    }
    return rejected;
  }
  function finishPanel(items, rows, o, rejected, market) {
    rows.sort((a, b) => a.d - b.d || a.it - b.it);
    const byDay = new Map();
    for (let r = 0; r < rows.length; r++) { const d = rows[r].d; if (!byDay.has(d)) byDay.set(d, []); byDay.get(d).push(r); }
    for (const [d, ids] of byDay) if (ids.length < o.minItemsPerDay) byDay.delete(d);
    const days = Array.from(byDay.keys()).sort((a, b) => a - b);
    const used = new Set(); for (const ids of byDay.values()) for (const r of ids) used.add(rows[r].it);
    return {
      sources: items.map(x => x.series), marketSeries: market, asOf: Math.max(...items.filter(x => x.series && x.series.ok).map(x => x.series.day0 + x.series.n - 1)),
      keys: o.keys, horizons: o.horizons, lag: o.lag, step: o.step, rows, byDay, days, items: items.map(x => ({ id: x.id, name: x.name, family: x.family })), nItems: used.size, rejected, market: !!(market && market.ok),
      rules: o._rules || null, ruleStats: o._stats ? { excludedItems: o._stats.excluded, excludedTotal: Object.values(o._stats.excluded).reduce((a, b) => a + b, 0), priceRows: o._stats.priceRows } : null,
    };
  }
  // Rules (optional): name rules drop whole items, the price rule drops rows
  // point-in-time (see panelRowsFor). Returns a per-item skip mask.
  function prepareRules(items, o) {
    const R = o.rules ? normRules(o.rules) : null;
    if (!R || !R.enabled) return null;
    o._rules = R; o._price = { min: R.priceMin, max: R.priceMax }; o._stats = { excluded: {}, priceRows: 0 };
    return items.map(x => { const c = ruleReasonName(x.name, R); if (c) o._stats.excluded[c] = (o._stats.excluded[c] || 0) + 1; return !!c; });
  }
  function buildPanel(items, market, opts) {
    const o = Object.assign({}, PANEL_DEFAULTS, opts || {});
    const skip = prepareRules(items, o);
    const rows = []; let rejected = 0;
    for (let it = 0; it < items.length; it++) if (!skip || !skip[it]) rejected += panelRowsFor(items[it].series, it, market, o, rows);
    return finishPanel(items, rows, o, rejected, market);
  }
  // Same result as buildPanel, but yields to the event loop between items so a
  // browser tab stays responsive. onProgress(done, total).
  async function buildPanelAsync(items, market, opts, onProgress, signal) {
    const o = Object.assign({}, PANEL_DEFAULTS, opts || {});
    const skip = prepareRules(items, o);
    const rows = []; let rejected = 0;
    for (let it = 0; it < items.length; it++) {
      if (signal && signal.aborted) throw Object.assign(new Error('已取消'), { name: 'AbortError' });
      if (!skip || !skip[it]) rejected += panelRowsFor(items[it].series, it, market, o, rows);
      if (onProgress) onProgress(it + 1, items.length);
      await new Promise(r => setTimeout(r, 0));
    }
    return finishPanel(items, rows, o, rejected, market);
  }

  // ---- single-item helpers (UI) -------------------------------------------
  // Latest usable index of a series at or before `day` (real bar, not stale).
  function lastUsableIndex(s, day) {
    if (!s || !s.ok) return -1;
    let i = Math.min(s.n - 1, isNum(day) ? day - s.day0 : s.n - 1);
    while (i >= 0 && !s.real[i]) i--;
    return i;
  }
  function scoreAt(s, m, model, day) {
    const i = lastUsableIndex(s, day);
    if (i < 0) return { ok: false, reason: '没有可用日K' };
    const fr = featuresAt(s, i, m, { skipLab: true });
    if (!fr.ok) return { ok: false, reason: fr.reason, day: dayStr(s.day0 + i) };
    const sc = scoreFeatures(fr.f, model);
    return { ok: true, i, day: dayStr(s.day0 + i), dayNum: s.day0 + i, close: s.c[i], sigma: fr.sigma, f: fr.f, score: sc.score, coverage: sc.coverage, parts: sc.parts };
  }
  // Percentile of today's score within the item's own recent history of scores
  // (single-item timing view). Uses only data up to each historical day.
  function ownHistory(s, m, model, opts) {
    const o = Object.assign({ lookback: 365, step: 3, day: null }, opts || {});
    const i = lastUsableIndex(s, o.day);
    if (i < 0) return { ok: false, reason: '没有可用日K' };
    const cur = featuresAt(s, i, m, { skipLab: true });
    if (!cur.ok) return { ok: false, reason: cur.reason };
    const now = scoreFeatures(cur.f, model).score, hist = [];
    for (let j = i - o.step; j >= Math.max(FEATURE_MIN_ROWS - 1, i - o.lookback); j -= o.step) {
      if (!s.real[j]) continue;
      const fr = featuresAt(s, j, m, { skipLab: true });
      if (fr.ok) hist.push({ d: dayStr(s.day0 + j), score: scoreFeatures(fr.f, model).score });
    }
    if (hist.length < 20) return { ok: false, reason: '自身历史样本不足（' + hist.length + '）', score: now };
    const sorted = hist.map(x => x.score).sort((a, b) => a - b);
    return { ok: true, score: now, pct: percentileOf(now, sorted), n: hist.length, from: hist[hist.length - 1].d, series: hist.reverse() };
  }
  const QUINTILE_NAMES = ['最低 20%', '偏低', '中间', '偏高', '最高 20%'];
  const bucketOf = pct => (isNum(pct) ? Math.min(5, Math.max(1, Math.floor(pct / 20) + 1)) : null);
  // Direction-aware descriptions: [text when the feature is LOW, text when HIGH].
  const FEATURE_HINTS = {
    mom3: ['近3日下跌', '近3日上涨'], mom7: ['近7日下跌', '近7日上涨'], mom30: ['近30日走弱', '近30日走强'], mom90: ['近90日走弱', '近90日走强'],
    mom30s7: ['中期（30日·跳过近7日）走弱', '中期（30日·跳过近7日）走强'], ret7: ['近7日下跌', '近7日上涨'], ret30: ['近30日下跌', '近30日上涨'],
    volLvl: ['波动低', '波动高'], volRatio: ['波动收敛', '波动放大'], relVol3: ['近3日缩量', '近3日放量'], volTrend: ['近7日缩量', '近7日放量'],
    liq: ['成交偏少', '成交活跃'], zeroVol: ['几乎每天有成交', '零成交日多'], logPrice: ['价格较低', '价格较高'],
    pos90: ['90日区间低位', '90日区间高位'], pos180: ['180日区间低位', '180日区间高位'], ddHigh: ['距180日高点回撤深', '接近180日高点'], upLow: ['接近180日低点', '远离180日低点'],
    ma20dist: ['低于MA20（短期回调）', '高于MA20（短期偏热）'], ma5_20: ['MA5在MA20下方', 'MA5在MA20上方'], ma20slope: ['MA20向下', 'MA20向上'], ma60dist: ['低于MA60', '高于MA60'],
    rsi14: ['RSI偏低', 'RSI偏高'], trendR2: ['走势下行或杂乱', '上行且平滑'], maxRet: ['近期无大阳', '近期有大阳'], minRet: ['近期有大跌日', '近期无大跌日'], skew60: ['收益左偏', '收益右偏'],
    obvAgree: ['量价背离', '量价一致'], beta: ['低β（受大盘影响小）', '高β（跟大盘波动大）'], betaAsym: ['下跌时β较小', '下跌时β较大'], idioVol: ['特质波动低', '特质波动高'], corrMkt: ['与大盘相关低', '与大盘相关高'],
    alpha7: ['7日跑输大盘', '7日跑赢大盘'], alpha30: ['30日跑输大盘', '30日跑赢大盘'], alpha90: ['90日跑输大盘', '90日跑赢大盘'],
  };
  // Top contributions (both signs) with plain-language text.
  function explain(parts, n) {
    const arr = (parts || []).filter(p => isNum(p.contrib) && p.contrib !== 0).sort((a, b) => Math.abs(b.contrib) - Math.abs(a.contrib)).slice(0, n || 5);
    return arr.map(p => {
      const hint = FEATURE_HINTS[p.key] || [p.key + '偏低', p.key + '偏高'];
      return { key: p.key, label: FEATURE_DEFS[p.key] || p.key, text: hint[p.z < 0 ? 0 : 1], contrib: p.contrib, z: p.z, x: p.x, sign: p.contrib > 0 ? '+' : '−' };
    });
  }

  // Extract a column (feature index or function of row) for a set of row ids.
  function col(panel, ids, fn) { return ids.map(r => fn(panel.rows[r])); }
  const featFn = (panel, key) => { const k = panel.keys.indexOf(key); if (k < 0) throw Error('未知特征 ' + key); return r => r.x[k]; };

  // ---------------------------------------------------------------------------
  // Metrics
  // ---------------------------------------------------------------------------
  // Per-day cross-sectional Spearman IC between score(row) and y[h].
  // t-stat uses non-overlapping days (every h/step-th day) to respect overlap.
  function crossIC(panel, scoreFn, h, opts) {
    const o = Object.assign({ minN: 20, days: panel.days, target: 'raw' }, opts || {});
    const series = [];
    for (const d of o.days) {
      const ids = (panel.byDay.get(d) || []);
      const xs = [], ys = [];
      for (const r of ids) {
        const row = panel.rows[r], x = scoreFn(row), y = row.y[h];
        if (isNum(x) && isNum(y)) { xs.push(x); ys.push(y); }
      }
      if (xs.length < o.minN) continue;
      const ic = spearman(xs, ys);
      if (ic !== null) series.push({ d, ic, n: xs.length });
    }
    return summarizeIC(series, h);
  }
  function summarizeIC(series, stride) {
    if (!series.length) return { n: 0, mean: null, sd: null, ir: null, t: null, posRate: null, series };
    const ics = series.map(s => s.ic), m = mean(ics), sd = std(ics);
    // non-overlapping subsample for the t statistic
    const no = []; let previous = -Infinity; for (const point of series) if (point.d - previous >= stride) { no.push(point.ic); previous = point.d; }
    const sdNo = std(no);
    const t = no.length >= 3 && sdNo > 0 ? mean(no) / (sdNo / Math.sqrt(no.length)) : null;
    const byYear = {};
    for (const s of series) { const y = dayStr(s.d).slice(0, 4); (byYear[y] = byYear[y] || []).push(s.ic); }
    for (const y of Object.keys(byYear)) byYear[y] = { n: byYear[y].length, mean: mean(byYear[y]) };
    return { n: series.length, nonOverlap: no.length, mean: m, sd, ir: sd > 0 ? m / sd : null, t, posRate: ics.filter(x => x > 0).length / ics.length, avgItems: mean(series.map(s => s.n)), byYear, series };
  }
  // Moving-block bootstrap CI of the mean IC.
  function bootstrapMeanCI(values, block = 10, B = 1000, alpha = 0.05, seed = 7) {
    const n = values.length; if (n < 10) return null;
    block = Math.max(1, Math.min(n, Math.ceil(block)));
    const rand = rng(seed), means = [];
    for (let b = 0; b < B; b++) {
      let s = 0, c = 0;
      while (c < n) { const st = Math.floor(rand() * (n - block + 1)); for (let k = 0; k < block && c < n; k++, c++) s += values[st + k]; }
      means.push(s / n);
    }
    means.sort((a, b) => a - b);
    return [quantile(means, alpha / 2), quantile(means, 1 - alpha / 2)];
  }
  // Quantile portfolios per day; returns net-of-cost simple returns (cost = round trip).
  function quantiles(panel, scoreFn, h, opts) {
    const o = Object.assign({ q: 5, cost: 0.01, minN: 25, days: panel.days, nonOverlap: true }, opts || {});
    const dates = o.nonOverlap ? EX.nonOverlap(o.days, h) : o.days;
    // medEx: median of the group minus median of the pool (robust to a few spikes)
    const acc = Array.from({ length: o.q }, () => ({ ret: [], ex: [], win: [], medEx: [] }));
    let used = 0, incomplete = 0;
    for (let k = 0; k < dates.length; k++) {
      const d = dates[k]; if (Number.isFinite(panel.asOf) && d + panel.lag + h > panel.asOf) continue;
      const ids = panel.byDay.get(d) || [];
      const arr = [];
      for (const r of ids) { const row = panel.rows[r], x = scoreFn(row), y = row.y[h]; if (isNum(x)) arr.push([x, y]); }
      if (arr.length < o.minN) continue;
      // Membership is fixed by signal scores. An incomplete period is reported, never backfilled.
      if (arr.some(a => !isNum(a[1]))) { incomplete++; continue; }
      used++;
      arr.sort((a, b) => a[0] - b[0]);
      const simple = arr.map(a => Math.exp(a[1]) - 1);
      const uni = mean(simple), uniMed = median(simple);
      for (let g = 0; g < o.q; g++) {
        const part = simple.slice(Math.floor(g * arr.length / o.q), Math.floor((g + 1) * arr.length / o.q));
        const r = mean(part);
        acc[g].ret.push(EX.netReturn(r, o.cost)); acc[g].ex.push(r - uni); acc[g].win.push(r > uni ? 1 : 0); acc[g].medEx.push(median(part) - uniMed);
      }
    }
    const groups = acc.map((g, i) => ({ q: i + 1, n: g.ret.length, avgNet: g.ret.length ? mean(g.ret) : null, avgExcess: g.ex.length ? mean(g.ex) : null, medExcess: g.medEx.length ? mean(g.medEx) : null, beatRate: g.win.length ? mean(g.win) : null }));
    const top = acc[o.q - 1].ex, bot = acc[0].ex;
    return { h, q: o.q, cost: o.cost, periods: used, incomplete, conditional: incomplete > 0, groups, topMinusBottom: top.length ? mean(top) - mean(bot) : null };
  }
  // Top-N portfolio, rebalanced every `h` days (non-overlapping, holding >= 7d
  // lock), equal weight, round-trip cost on every position. Benchmarks: equal-
  // weight universe (same cost) and the market index (no cost).
  // Top-N equal-weight portfolio, rebalanced every h days (non-overlapping),
  // net of round-trip cost. Benchmarks: equal-weight eligible universe (same
  // cost) and the market index. Options:
  //   filter(row) -> bool   extra tradability filter (applied to both)
  //   gate(day)   -> bool   false = stay in cash that period (top only)
  // Robustness stats: median-of-picks return and per-pick win rate, because
  // equal-weight means of noisy, right-skewed ask-price returns flatter.
  function portfolioSim(panel, scoreFn, opts) { return EX.simulate(panel, scoreFn, opts); }
  // Single-item timing: per-item time-series Spearman between score and the
  // item's forward EXCESS return (vs index when available), non-overlapping.
  function itemTimingIC(panel, scoreFn, h, opts) {
    const o = Object.assign({ minN: 12, excess: true }, opts || {});
    const byItem = new Map();
    for (const row of panel.rows) { if (!byItem.has(row.it)) byItem.set(row.it, []); byItem.get(row.it).push(row); }
    const ics = [];
    for (const [it, arr] of byItem) {
      arr.sort((a, b) => a.d - b.d);
      const xs = [], ys = [];
      let lastD = -Infinity;
      for (const row of arr) {
        if (row.d - lastD < h) continue;
        const x = scoreFn(row), y = o.excess ? row.y[h] - row.ym[h] : row.y[h];
        if (isNum(x) && isNum(y)) { xs.push(x); ys.push(y); lastD = row.d; }
      }
      if (xs.length < o.minN) continue;
      const ic = spearman(xs, ys); if (ic !== null) ics.push({ it, ic, n: xs.length });
    }
    if (!ics.length) return { items: 0, mean: null };
    const v = ics.map(x => x.ic), m = mean(v), sd = std(v);
    return { items: ics.length, mean: m, sd, t: sd > 0 ? m / (sd / Math.sqrt(v.length)) : null, posRate: v.filter(x => x > 0).length / v.length, avgN: mean(ics.map(x => x.n)) };
  }
  // Market timing: time-series Spearman of a regime value vs the index /
  // equal-weight universe forward return, non-overlapping days.
  function timingIC(panel, market, h, regimeFn) {
    const xs = [], ym = [], yu = [];
    let lastD = -Infinity;
    for (const d of panel.days) {
      if (d - lastD < h) continue;
      const g = regimeFn(d); if (!isNum(g)) continue;
      const ids = panel.byDay.get(d) || [];
      const ys = ids.map(r => panel.rows[r].y[h]).filter(isNum);
      const m = ids.length ? panel.rows[ids[0]].ym[h] : NaN;
      if (ys.length < 20 || !isNum(m)) continue;
      xs.push(g); ym.push(m); yu.push(mean(ys.map(y => Math.exp(y) - 1)));
      lastD = d;
    }
    return { n: xs.length, icIndex: spearman(xs, ym), icUniverse: spearman(xs, yu) };
  }

  // ---------------------------------------------------------------------------
  // Training: purged walk-forward with an untouched holdout.
  //   dates:  [ .... walk-forward (λ / method selection) .... | purge | holdout test ]
  // Features are winsorised (1%/99%) and z-scored with statistics from the
  // fitting window only, demeaned per day (the model learns SELECTION, not the
  // market level), target = per-day rank-gaussian of y[h].
  // ---------------------------------------------------------------------------
  function fitStats(panel, ids, keys) {
    const K = keys.length, idx = keys.map(k => panel.keys.indexOf(k));
    const out = [];
    for (let k = 0; k < K; k++) {
      const vals = [];
      for (const r of ids) { const x = panel.rows[r].x[idx[k]]; if (isNum(x)) vals.push(x); }
      vals.sort((a, b) => a - b);
      if (vals.length < 50) { out.push({ key: keys[k], lo: -Infinity, hi: Infinity, mu: 0, sd: 1, n: vals.length }); continue; }
      const lo = quantile(vals, 0.01), hi = quantile(vals, 0.99);
      const w = vals.map(x => clip(x, lo, hi)), mu = mean(w), sd = std(w) || 1;
      out.push({ key: keys[k], lo, hi, mu, sd, n: vals.length });
    }
    return out;
  }
  function zRow(row, idx, stats) {
    const z = new Float64Array(idx.length);
    for (let k = 0; k < idx.length; k++) {
      const x = row.x[idx[k]], st = stats[k];
      z[k] = isNum(x) ? clip((clip(x, st.lo, st.hi) - st.mu) / st.sd, -4, 4) : 0;
    }
    return z;
  }
  // Accumulate per-day demeaned normal equations.
  function normalEq(panel, days, keys, stats, h) {
    const K = keys.length, idx = keys.map(k => panel.keys.indexOf(k));
    const XtX = Array.from({ length: K }, () => new Float64Array(K)), Xty = new Float64Array(K);
    let n = 0;
    for (const d of days) {
      const ids = (panel.byDay.get(d) || []).filter(r => isNum(panel.rows[r].y[h]));
      if (ids.length < 20) continue;
      const Z = ids.map(r => zRow(panel.rows[r], idx, stats));
      const y = gaussRank(ids.map(r => panel.rows[r].y[h]));
      const mz = new Float64Array(K);
      for (const z of Z) for (let k = 0; k < K; k++) mz[k] += z[k] / Z.length;
      for (let a = 0; a < Z.length; a++) {
        const z = Z[a];
        for (let p = 0; p < K; p++) {
          const zp = z[p] - mz[p];
          Xty[p] += zp * y[a];
          for (let q = p; q < K; q++) XtX[p][q] += zp * (z[q] - mz[q]);
        }
        n++;
      }
    }
    for (let p = 0; p < K; p++) for (let q = 0; q < p; q++) XtX[p][q] = XtX[q][p];
    return { XtX, Xty, n };
  }
  function solve(A, b) { // Gaussian elimination with partial pivoting
    const n = b.length, M = A.map((r, i) => Array.from(r).concat([b[i]]));
    for (let c = 0; c < n; c++) {
      let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
      if (Math.abs(M[p][c]) < 1e-12) return null;
      [M[c], M[p]] = [M[p], M[c]];
      for (let r = c + 1; r < n; r++) { const f = M[r][c] / M[c][c]; for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k]; }
    }
    const x = new Array(n).fill(0);
    for (let r = n - 1; r >= 0; r--) { let s = M[r][n]; for (let k = r + 1; k < n; k++) s -= M[r][k] * x[k]; x[r] = s / M[r][r]; }
    return x;
  }
  function ridge(eq, lambda) {
    const K = eq.Xty.length, A = eq.XtX.map((r, i) => { const c = Array.from(r); c[i] += lambda * eq.n / 1000; return c; });
    return solve(A, Array.from(eq.Xty));
  }
  // IC-weighted: weight = mean per-day IC of each standalone feature (sign kept),
  // zeroed when |t| < tMin. Less flexible than ridge, far harder to overfit.
  function icWeights(panel, days, keys, h, tMin) {
    return keys.map(k => {
      const fn = featFn(panel, k);
      const r = crossIC(panel, fn, h, { days });
      return r.mean !== null && r.t !== null && Math.abs(r.t) >= (tMin || 2) ? r.mean : 0;
    });
  }
  function modelFrom(keys, w, stats, meta) {
    const norm = w.reduce((s, x) => s + Math.abs(x), 0) || 1;
    return Object.assign({
      version: VERSION,
      features: keys.map((k, i) => ({ key: k, w: w[i] / norm, lo: stats[i].lo, hi: stats[i].hi, mu: stats[i].mu, sd: stats[i].sd })).filter(p => p.w !== 0),
    }, meta || {});
  }
  const modelScorer = (panel, model) => {
    const idx = model.features.map(p => panel.keys.indexOf(p.key));
    return row => {
      let s = 0;
      for (let k = 0; k < idx.length; k++) {
        const p = model.features[k], x = idx[k] >= 0 ? row.x[idx[k]] : NaN;
        if (isNum(x)) s += p.w * clip((clip(x, p.lo, p.hi) - p.mu) / (p.sd || 1), -4, 4);
      }
      return s;
    };
  };

  const DEFAULT_GATES = { minTestIC: 0.02, minTestT: 2.0, maxDecay: 0.5, minTestDays: 40, minItems: 30 };
  function train(panel, opts) {
    const o = Object.assign({ h: 14, keys: null, lambdas: [0.3, 3, 30, 300], folds: 4, testFrac: 0.2, method: 'auto', gates: DEFAULT_GATES, tMin: 2, active: null, baselines: {} }, opts || {});
    const h = o.h, keys = o.keys || panel.keys.filter(k => !k.startsWith('lab'));
    const purge = Math.ceil((h + panel.lag) / panel.step);
    const matured = panel.days.filter(d => (panel.byDay.get(d) || []).filter(r => isNum(panel.rows[r].y[h])).length >= o.gates.minItems);
    if (matured.length < 120) return { ok: false, reason: '已到期的采样日不足120个（当前 ' + matured.length + '），样本库需要更多商品或更长历史' };
    const nTest = Math.max(o.gates.minTestDays, Math.floor(matured.length * o.testFrac));
    const testDays = matured.slice(-nTest), devDays = matured.slice(0, matured.length - nTest - purge);
    if (devDays.length < 80) return { ok: false, reason: '训练窗太短（' + devDays.length + '天）' };
    const idsOf = days => days.flatMap(d => panel.byDay.get(d) || []);
    // walk-forward inside dev: fold k validates on chunk k, trains on everything before it minus purge
    const chunk = Math.floor(devDays.length / (o.folds + 1));
    const cand = [];
    for (const lam of o.lambdas) cand.push({ method: 'ridge', lambda: lam });
    cand.push({ method: 'icw', lambda: null });
    const results = cand.map(c => ({ c, ics: [], weights: [] }));
    for (let f = 1; f <= o.folds; f++) {
      const vStart = f * chunk, vEnd = f === o.folds ? devDays.length : (f + 1) * chunk;
      const trDays = devDays.slice(0, Math.max(0, vStart - purge)), vaDays = devDays.slice(vStart, vEnd);
      if (trDays.length < 60 || !vaDays.length) continue;
      const st = fitStats(panel, idsOf(trDays), keys);
      const eq = normalEq(panel, trDays, keys, st, h);
      const icw = icWeights(panel, trDays, keys, h, o.tMin);
      for (const res of results) {
        const w = res.c.method === 'ridge' ? ridge(eq, res.c.lambda) : icw;
        if (!w) continue;
        const m = modelFrom(keys, w, st);
        const r = crossIC(panel, modelScorer(panel, m), h, { days: vaDays });
        if (r.mean !== null) { res.ics.push(r.mean); res.weights.push(w); }
      }
    }
    const scored = results.filter(r => r.ics.length).map(r => ({ method: r.c.method, lambda: r.c.lambda, valIC: mean(r.ics), folds: r.ics.length, signStability: keys.map((k, i) => { const s = r.weights.map(w => Math.sign(w[i])); const pos = s.filter(x => x > 0).length, neg = s.filter(x => x < 0).length; return Math.max(pos, neg) / Math.max(1, s.length); }) }));
    if (!scored.length) return { ok: false, reason: '走步验证没有得到有效折' };
    const pool = o.method === 'auto' ? scored : scored.filter(s => s.method === o.method);
    const best = pool.slice().sort((a, b) => b.valIC - a.valIC)[0];
    // holdout: fit on all dev days, evaluate on the untouched test days
    const stDev = fitStats(panel, idsOf(devDays), keys);
    const wDev = best.method === 'ridge' ? ridge(normalEq(panel, devDays, keys, stDev, h), best.lambda) : icWeights(panel, devDays, keys, h, o.tMin);
    const mDev = modelFrom(keys, wDev, stDev);
    const test = evaluateModel(panel, mDev, h, testDays);
    // final suggestion: refit on every matured day (dev + purge + test)
    const stAll = fitStats(panel, idsOf(matured), keys);
    const wAll = best.method === 'ridge' ? ridge(normalEq(panel, matured, keys, stAll, h), best.lambda) : icWeights(panel, matured, keys, h, o.tMin);
    const model = modelFrom(keys, wAll, stAll, {
      id: 'sel-' + h + 'd-' + dayStr(matured[matured.length - 1]) + '-' + best.method,
      createdAt: new Date().toISOString(), source: 'trained', horizon: h, method: best.method, lambda: best.lambda,
      train: { firstDay: dayStr(matured[0]), lastDay: dayStr(matured[matured.length - 1]), days: matured.length, items: panel.nItems || panel.items.length, testFirst: dayStr(testDays[0]), testLast: dayStr(testDays[testDays.length - 1]), rules: panel.rules || null, rulesKey: rulesKey(panel.rules || { enabled: false }) },
    });
    const baselines = {};
    for (const [name, fn] of Object.entries(o.baselines || {})) baselines[name] = evaluateModel(panel, null, h, testDays, fn);
    const active = o.active ? evaluateModel(panel, o.active, h, testDays) : null;
    const g = o.gates, gates = [
      { name: '样本外IC ≥ ' + g.minTestIC, pass: test.ic.mean !== null && test.ic.mean >= g.minTestIC, value: test.ic.mean },
      { name: '样本外t ≥ ' + g.minTestT + '（不重叠日）', pass: test.ic.t !== null && test.ic.t >= g.minTestT, value: test.ic.t },
      { name: '样本外IC衰减 ≤ ' + (g.maxDecay * 100) + '%', pass: best.valIC > 0 && test.ic.mean !== null && test.ic.mean >= best.valIC * (1 - g.maxDecay), value: best.valIC > 0 && test.ic.mean !== null ? 1 - test.ic.mean / best.valIC : null },
      { name: '测试期 ≥ ' + g.minTestDays + ' 个采样日', pass: testDays.length >= g.minTestDays, value: testDays.length },
      { name: '不差于当前启用模型', pass: !active || active.ic.mean === null || (test.ic.mean !== null && test.ic.mean >= active.ic.mean), value: active ? active.ic.mean : null },
    ];
    model.test = { ic: pick(test.ic), quint: test.quint, portfolio: test.portfolio && { top: test.portfolio.top, universe: test.portfolio.universe, market: test.portfolio.market, beatUniverseRate: test.portfolio.beatUniverseRate, periods: test.portfolio.periods } };
    model.calib = calibrate(panel, mDev, testDays, panel.horizons);
    model.reference = referenceScores(panel, model);
    model.gatesPassed = gates.every(x => x.pass);
    return {
      ok: true, h, model, gates, passed: model.gatesPassed,
      selection: { best, candidates: scored.map(s => ({ method: s.method, lambda: s.lambda, valIC: s.valIC, folds: s.folds })) },
      signStability: keys.map((k, i) => ({ key: k, stability: best.signStability[i], w: model.features.find(p => p.key === k) ? model.features.find(p => p.key === k).w : 0 })),
      test: { ic: pick(test.ic), quint: test.quint, portfolio: test.portfolio }, active: active && { ic: pick(active.ic), quint: active.quint }, baselines: Object.fromEntries(Object.entries(baselines).map(([k, v]) => [k, { ic: pick(v.ic), quint: v.quint }])),
      note: '走步验证用于选择方法和λ；报告的样本外成绩来自从未参与选择的最后' + testDays.length + '个采样日（每' + panel.step + '天一个，与训练窗之间隔离' + purge + '个采样日）。最终建议参数用全部到期样本重拟合。',
    };
  }
  // Rolling (expanding-window) retrain: every `every` days fit on all matured
  // days that ended >= purge before the refit date, score the next block.
  // Returns Map(row -> out-of-sample score) covering everything after the
  // first `minTrainDays`. This is the honest full-history backtest of the
  // LEARNING procedure itself (not of one frozen parameter set).
  function walkForward(panel, opts) {
    const o = Object.assign({ h: 14, keys: null, lambda: 30, method: 'ridge', every: 30, minTrainDays: 240, tMin: 2, onProgress: null }, opts || {});
    const keys = o.keys || panel.keys.filter(k => !k.startsWith('lab'));
    const purge = Math.ceil((o.h + panel.lag) / panel.step);
    const days = panel.days, oos = new Map(), fits = [];
    const idsOf = ds => ds.flatMap(d => panel.byDay.get(d) || []);
    for (let s = o.minTrainDays + purge; s < days.length; s += Math.max(1, Math.round(o.every / panel.step))) {
      const trDays = days.slice(0, s - purge).filter(d => (panel.byDay.get(d) || []).some(r => isNum(panel.rows[r].y[o.h])));
      if (trDays.length < o.minTrainDays * 0.8) continue;
      const st = fitStats(panel, idsOf(trDays), keys);
      const w = o.method === 'ridge' ? ridge(normalEq(panel, trDays, keys, st, o.h), o.lambda) : icWeights(panel, trDays, keys, o.h, o.tMin);
      if (!w) continue;
      const m = modelFrom(keys, w, st), sc = modelScorer(panel, m);
      const block = days.slice(s, s + Math.max(1, Math.round(o.every / panel.step)));
      for (const d of block) for (const r of panel.byDay.get(d) || []) oos.set(panel.rows[r], sc(panel.rows[r]));
      fits.push({ at: dayStr(days[s]), trainDays: trDays.length, top: m.features.slice().sort((a, b) => Math.abs(b.w) - Math.abs(a.w)).slice(0, 5).map(p => p.key + (p.w > 0 ? '+' : '−')) });
      if (o.onProgress) o.onProgress(s / days.length);
    }
    return { oos, fits, scorer: row => { const v = oos.get(row); return v === undefined ? NaN : v; }, firstDay: fits.length ? fits[0].at : null };
  }
  const pick = ic => ic && { n: ic.n, nonOverlap: ic.nonOverlap, mean: ic.mean, sd: ic.sd, ir: ic.ir, t: ic.t, posRate: ic.posRate, avgItems: ic.avgItems, byYear: ic.byYear };
  function evaluateModel(panel, model, h, days, fn) {
    const sc = fn || modelScorer(panel, model);
    return { ic: crossIC(panel, sc, h, { days }), quint: quantiles(panel, sc, h, { days }), portfolio: portfolioSim(panel, sc, { h, days }) };
  }
  // Percentile bucket (quintile) -> forward stats on the given (OOS) days.
  function calibrate(panel, model, days, horizons) {
    const sc = modelScorer(panel, model), out = {};
    for (const h of horizons || panel.horizons) {
      const q = quantiles(panel, sc, h, { days, q: 5, cost: 0 });
      out['h' + h] = q.groups.map((g, i) => ({ bucket: (i * 20) + '–' + ((i + 1) * 20), n: g.n, avgRet: g.avgNet, avgExcess: g.avgExcess, medExcess: g.medExcess, beatRate: g.beatRate }));
    }
    return out;
  }
  // Sorted scores of the latest cross-section (for percentile mapping on a single item).
  function referenceScores(panel, model) {
    const sc = modelScorer(panel, model);
    for (let k = panel.days.length - 1; k >= 0; k--) {
      const ids = panel.byDay.get(panel.days[k]) || [];
      if (ids.length >= 30) return { day: dayStr(panel.days[k]), scores: ids.map(r => sc(panel.rows[r])).filter(isNum).sort((a, b) => a - b).map(x => Math.round(x * 1e4) / 1e4) };
    }
    return null;
  }

  // ---- paper tracking (forward test of what the plugin actually showed) -------
  const dayNumOf = str => Math.round(Date.parse(String(str).slice(0, 10) + 'T00:00:00Z') / DAY);
  function realized(s, day, h, lag) {
    if (!s || !s.ok) return NaN;
    const a = day + (lag === undefined ? 1 : lag) - s.day0, b = a + h;
    if (a < 0 || b >= s.n || !s.real[a] || !s.real[b]) return NaN;
    return LN(s.c[b] / s.c[a]);
  }
  // snaps: [{day,h,modelId,items:[[id,score,close]]}], seriesById: Map(id -> series)
  function paperTrack(snaps, seriesById, opts) {
    const o = Object.assign({ cost: 0.01, lag: 1, minN: 10 }, opts || {});
    const rows = [];
    for (const sn of snaps || []) {
      const d = dayNumOf(sn.day), xs = [], ys = [];
      for (const it of sn.items || []) {
        const y = realized(seriesById.get(String(it[0])), d, sn.h, o.lag);
        if (isNum(it[1]) && isNum(y)) { xs.push(it[1]); ys.push(y); }
      }
      if (xs.length < o.minN || xs.length !== (sn.items || []).filter(it => isNum(it[1])).length) { rows.push({ day: sn.day, h: sn.h, modelId: sn.modelId, matured: false, n: xs.length, total: (sn.items || []).length }); continue; }
      const order = xs.map((x, i) => i).sort((i, j) => xs[j] - xs[i]), k = Math.max(1, Math.floor(xs.length / 5));
      const simple = ys.map(y => Math.exp(y) - 1), all = mean(simple);
      const top = order.slice(0, k).map(i => simple[i]), bot = order.slice(-k).map(i => simple[i]);
      rows.push({ day: sn.day, h: sn.h, modelId: sn.modelId, matured: true, n: xs.length, ic: spearman(xs, ys), topNet: EX.netReturn(mean(top), o.cost), allNet: EX.netReturn(all, o.cost), topExcess: mean(top) - all, bottomExcess: mean(bot) - all, topBeat: top.filter(r => r > all).length / top.length });
    }
    const byH = {};
    for (const r of rows) if (r.matured) (byH[r.h] = byH[r.h] || []).push(r);
    const summary = Object.keys(byH).map(h => {
      const a = byH[h];
      return { h: +h, snaps: a.length, ic: mean(a.map(r => r.ic)), icPos: a.filter(r => r.ic > 0).length / a.length, topExcess: mean(a.map(r => r.topExcess)), bottomExcess: mean(a.map(r => r.bottomExcess)), topNet: mean(a.map(r => r.topNet)), first: a[a.length - 1].day, last: a[0].day };
    }).sort((a, b) => a.h - b.h);
    return { rows, summary, pending: rows.filter(r => !r.matured).length };
  }
  // views: [{day,id,h,score,pct,close}] -> realized net return once matured
  function viewOutcomes(views, seriesById, opts) {
    const o = Object.assign({ cost: 0.01, lag: 1 }, opts || {});
    return (views || []).map(v => {
      const y = realized(seriesById.get(String(v.id)), dayNumOf(v.day), v.h, o.lag);
      return Object.assign({}, v, { matured: isNum(y), ret: isNum(y) ? Math.exp(y) - 1 : null, net: isNum(y) ? EX.netReturn(Math.exp(y) - 1, o.cost) : null });
    });
  }

  const api = {
    VERSION, DAY, FEATURE_DEFS, FEATURE_KEYS, FEATURE_MIN_ROWS, REGIME, DEFAULT_GATES,
    num, mean, median, std, quantile, ranks, spearman, pearson, gaussRank, probit, rng, dayStr, dayOf,
    toSeries, mergeSeries, truncate, marketRegime, featuresAt, labBranches, scoreFeatures, percentileOf,
    buildPanel, buildPanelAsync, lastUsableIndex, scoreAt, ownHistory, bucketOf, explain, QUINTILE_NAMES, FEATURE_HINTS, featFn, col, crossIC, summarizeIC, bootstrapMeanCI, quantiles, portfolioSim, itemTimingIC, timingIC,
    dayNumOf, realized, paperTrack, viewOutcomes,
    WEARS, DEFAULT_RULES, RULE_REASONS, classifyName, normRules, ruleReasonName, ruleReasonPrice, ruleCheck, rulesText, rulesKey,
    fitStats, normalEq, ridge, solve, icWeights, modelFrom, modelScorer, train, walkForward, evaluateModel, calibrate, referenceScores,
  };
  root.MarketLensFactor = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
