/* User-entered bookkeeping is independent of recommendation eligibility. */
(function(root){
'use strict';
const dayOK=s=>typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&Number.isFinite(Date.parse(s+'T00:00:00Z'))&&new Date(s+'T00:00:00Z').toISOString().slice(0,10)===s;
function itemId(text){let s=String(text||'').trim();if(/^https:/.test(s)){const u=new URL(s);if(!['firepulse.com.cn','www.firepulse.com.cn'].includes(u.hostname))throw Error('仅接受 FirePulse 商品链接；不能混入其他站点 ID。');const m=u.pathname.match(/^\/cs2\/([1-9]\d{0,24})\/?$/);if(!m)throw Error('请填写 /cs2/商品ID 链接。');s=m[1];}if(!/^[1-9]\d{0,24}$/.test(s))throw Error('商品 ID 必须是数字字符串，或完整 FirePulse 商品链接。');return s;}
function build(x,ctx={}){
 const id=itemId(x.item),name=String(x.name||'').trim();if(!name||name.length>300)throw Error('请填写并核对商品名称与磨损（最多300字）。');
 for(const k of ['buyPrice','buyFee'])if(!Number.isFinite(x[k])||x[k]<(k==='buyPrice'?0.01:0)||x[k]>1e10||Math.abs(x[k]*100-Math.round(x[k]*100))>0.0001)throw Error('实际买入单价需大于零，整笔买入费用不能为负；金额最多两位小数。');
 if(!Number.isSafeInteger(x.qty)||x.qty<1||x.qty>1e6||x.buyPrice*x.qty+x.buyFee>1e12)throw Error('数量需为1至100万的整数，整笔成本不能超过1万亿元。');
 if(!dayOK(x.buyDay)||!dayOK(ctx.today)||x.buyDay>ctx.today)throw Error('买入日期无效或在未来；这里只登记已完成交易。');
 if(![7,14,30].includes(x.h))throw Error('计划持有期应为7、14或30日。');
 const note=String(x.note||'').trim();if(note.length>500)throw Error('备注最多500字。');
 return {id,name,url:'https://firepulse.com.cn/cs2/'+id,buyDay:x.buyDay,buyPrice:x.buyPrice,buyFee:x.buyFee,qty:x.qty,h:x.h,sellBy:new Date(Date.parse(x.buyDay+'T00:00:00Z')+x.h*86400000).toISOString().slice(0,10),entrySource:'manual',decisionNote:String(ctx.decisionNote||'未取得完整推荐判断；自主买入，不代表模型推荐。').slice(0,1000),userNote:note,decisionCapturedAt:ctx.observedAt||new Date().toISOString(),pctAtBuy:null,modelId:null};
}
const api={itemId,build};root.MarketLensManual=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
