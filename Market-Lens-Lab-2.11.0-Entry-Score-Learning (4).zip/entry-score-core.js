/* Quantitative Entry Readiness Score (User Weight Architecture 10/50/10/25 - Risk 5, Category Discounter) */
(function(root){'use strict';
const VERSION='entry-readiness-2.0',finite=Number.isFinite;

const CORE_RIFLES=new Set(['AK-47','M4A4','M4A1消音版','AWP','AUG','SG 553','SG553','SSG 08','SSG08','法玛斯','加利尔AR','SCAR-20','G3SG1']);
const CORE_PISTOLS=new Set(['格洛克18型','USP消音版','沙漠之鹰','P250','FN57','Tec-9','CZ75自动型','双持贝瑞塔','P2000','R8左轮手枪']);
const AGENT_KEYWORDS=['指挥官','特工','中尉','少尉','上校','军官','士兵','达里尔','罗曼诺夫','列赞','克拉斯沃特','小凯夫','迈克','萨莉','反抗者','叛军','教授','特种兵','铅弹','老K','黑狼','波兹曼','索尔曼','达比西','贾米森'];

function getCategoryDiscount(row){
 const fam=String(row?.family||''),name=String(row?.name||'');
 if(fam.includes('手套')||name.includes('手套'))return {category:'手套',discount:1.0};
 if(CORE_RIFLES.has(fam))return {category:'步枪/狙击',discount:1.0};
 if(CORE_PISTOLS.has(fam))return {category:'手枪',discount:1.0};
 if(AGENT_KEYWORDS.some(k=>fam.includes(k)||name.includes(k)))return {category:'探员',discount:1.0};
 return {category:'其余武器(微冲/霰弹/机枪)',discount:0.85};
}

function evaluate(row,signal){
 const r=row||{},s=signal||{},base={version:VERSION,score:null,code:s.code||'insufficient',label:s.label||'数据不足',reason:s.summary||'缺少判断',rank:finite(r.selPct)?r.selPct:null};

 if(!finite(r.selPct)||r.selPct<0||r.selPct>100)return {...base,code:'insufficient',label:'数据不足',reason:'选品分位不可用，不打入场分。'};

 // 1. 底子 (选品分位占 10 分)
 const scoreBase=(r.selPct/100.0)*10.0;

 // 2. 形态多维 (占 50 分，以右侧止跌转折、趋势确认为核心)
 const deepEntry=finite(r.deepEntry)?r.deepEntry:(finite(r['lab-2.1入场分'])?r['lab-2.1入场分']:0.0);
 const scoreShape=(Math.min(100,Math.max(0,deepEntry))/100.0)*50.0;

 // 3. 在售价是否超标 (占 10 分)
 const q=r.quote||r.askQuote||(r.ask!==null&&r.ask!==undefined?{ok:true,price:r.ask}:null);
 const limit=finite(r.limit)?r.limit:(finite(r.close)?Math.round(r.close*1.02*100)/100:null);
 const hasQuote=q&&q.ok&&finite(q.price)&&q.price>0;
 const priceOk=hasQuote&&finite(limit)&&limit>0&&q.price<=limit;
 const scorePrice=priceOk?10.0:0.0;

 // 4. 成交量配合 (占 25 分)
 const relVol=finite(r.relativeVolume)?r.relativeVolume:(finite(r.volumeEvidence?.relativeVolume)?r.volumeEvidence.relativeVolume:0.0);
 const isEligible=(r.eligible===true||r.eligible==='是');
 let scoreVolume=0.0;
 if(isEligible&&relVol>=1.2){
   scoreVolume=25.0;
 }else if(isEligible&&relVol>=1.0){
   scoreVolume=20.0;
 }else if(isEligible&&relVol>=0.8){
   scoreVolume=12.0;
 }else if(relVol>0){
   scoreVolume=5.0;
 }

 // 5. 风险扣分项 (每项扣 5 分)
 let penalty=0.0;
 const risks=Array.isArray(r.risks)?r.risks.join('；'):String(r.risks||'');
 if(risks.includes('创新低')||risks.includes('新的20根收盘低点')){
   penalty+=5.0;
 }
 if(risks.includes('收盘动量仍未转正')||risks.includes('动量仍未转正')){
   penalty+=5.0;
 }
 if(s.code==='blocked'||String(r.触发判断依据||'').includes('大盘风险闸门')){
   penalty+=5.0;
 }

 const rawScore=Math.max(0.0,scoreBase+scoreShape+scorePrice+scoreVolume-penalty);
 const {category,discount}=getCategoryDiscount(r);
 const finalScore=Math.min(100,Math.max(0,Math.round(rawScore*discount)));

 // 衍生状态标签
 let derivedState='outside';
 if(finalScore>=75){
   derivedState='trigger';
 }else if(finalScore>=50){
   derivedState='volume';
 }else if(finalScore>=35){
   derivedState='price';
 }else{
   derivedState='outside';
 }

 return {
   ...base,
   score:finalScore,
   category,
   discount,
   breakdown:{
     base:Number(scoreBase.toFixed(1)),
     shape:Number(scoreShape.toFixed(1)),
     price:Number(scorePrice.toFixed(1)),
     volume:Number(scoreVolume.toFixed(1)),
     penalty:Number(penalty.toFixed(1))
   },
   stage:derivedState,
   marketBlocked:s.code==='blocked'||penalty>=5.0
 };
}

const api={VERSION,evaluate,getCategoryDiscount};
root.MarketLensEntryScore=api;
if(typeof module!=='undefined')module.exports=api;
})(globalThis);
