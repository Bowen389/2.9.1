/* 2.9.1: shared cancellable request scheduler. No credentials or background networking. */
(function(root) {
  'use strict';
  const abortError = () => Object.assign(new Error('操作已取消'), { name: 'AbortError' });
  function wait(ms, signal) {
    return new Promise((resolve, reject) => {
      if (signal && signal.aborted) return reject(abortError());
      const done = () => { if (signal) signal.removeEventListener('abort', stop); resolve(); };
      const timer = setTimeout(done, Math.max(0, ms));
      const stop = () => { clearTimeout(timer); signal.removeEventListener('abort', stop); reject(abortError()); };
      if (signal) signal.addEventListener('abort', stop, { once: true });
    });
  }
  function createClient(opts) {
    const o = opts || {}, budgets = new WeakMap();
    let throttleUntil = 0;
    const setBudget = (signal, max) => { if (signal) budgets.set(signal, { left: max }); };
    async function request(path, body, signal, timeoutMs) {
      while (throttleUntil > Date.now()) await wait(throttleUntil - Date.now(), signal);
      if (signal && signal.aborted) throw abortError();
      const budget = signal && budgets.get(signal);
      if (budget && budget.left <= 0) throw Object.assign(Error('本批实际请求数已达上限'), { budget: true });
      if (budget) budget.left--;
      const c = new AbortController();
      const cancel = () => c.abort();
      if (signal) signal.addEventListener('abort', cancel, { once: true });
      let timedOut = false, rejectAbort;
      const abortPromise = new Promise((_, reject) => { rejectAbort = reject; });
      const aborted = () => rejectAbort(timedOut ? Object.assign(Error('请求超时'), { name: 'TimeoutError', retryable: true }) : abortError());
      c.signal.addEventListener('abort', aborted, { once: true });
      const timer = setTimeout(() => { timedOut = true; c.abort(); }, timeoutMs || 20000);
      if (o.onAttempt) o.onAttempt();
      try {
        return await Promise.race([abortPromise, (async () => {
          const r = await o.fetch(path, { method: 'POST', credentials: 'omit', cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: c.signal });
          if (r.status === 429) {
            const value = r.headers && r.headers.get('Retry-After');
            const secs = value == null ? NaN : Number(value);
            const retryAt = value && !Number.isFinite(secs) ? Date.parse(value) : NaN;
            const ms = Number.isFinite(secs) ? secs * 1000 : Number.isFinite(retryAt) ? retryAt - Date.now() : 0;
            throttleUntil = Math.max(throttleUntil, Date.now() + Math.max(o.cooldownMs ? o.cooldownMs() : 8000, ms));
            throw Object.assign(Error('接口 HTTP 429（全局冷却后重试）'), { retryable: true });
          }
          if (r.status >= 500) throw Object.assign(Error('接口 HTTP ' + r.status), { retryable: true });
          if (!r.ok) throw Error('接口 HTTP ' + r.status);
          const text = await r.text();
          if (text.length > 2000000) throw Error('接口响应超过2MB限制');
          const j = JSON.parse(text);
          if (j && typeof j.code === 'number' && j.code !== 200) {
            if (j.code === 429) throttleUntil = Math.max(throttleUntil, Date.now() + (o.cooldownMs ? o.cooldownMs() : 8000));
            throw Object.assign(Error('接口 code ' + j.code), { retryable: j.code === 429 || j.code >= 500 });
          }
          return j;
        })()]);
      } catch (e) {
        if (signal && signal.aborted) throw abortError();
        if (timedOut) throw Object.assign(Error('请求超时'), { name: 'TimeoutError', retryable: true });
        if (e instanceof TypeError) e.retryable = true;
        throw e;
      } finally {
        clearTimeout(timer); c.signal.removeEventListener('abort', aborted);
        if (signal) signal.removeEventListener('abort', cancel);
      }
    }
    async function retry(path, body, signal, tries, timeoutMs) {
      for (let i = 0; i < (tries || 3); i++) {
        try { return await request(path, body, signal, timeoutMs); }
        catch (e) {
          if (!e.retryable || i === (tries || 3) - 1 || (signal && signal.aborted)) throw e;
          await wait(o.retryDelay !== undefined ? o.retryDelay : 700 * Math.pow(2.2, i) + Math.random() * 300, signal);
        }
      }
    }
    return { request, retry, setBudget };
  }
  const api = { wait, createClient };
  root.MarketLensReliability = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
