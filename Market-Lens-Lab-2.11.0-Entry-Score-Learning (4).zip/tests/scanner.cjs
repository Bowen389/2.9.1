'use strict';
const assert = require('node:assert/strict'), S = require('../scanner-core.js'), WL = require('../whitelist.js');
let t = 0; const test = (n, f) => { f(); t++; console.log('PASS', n); };
function row(id, name, family, opts = {}) {
  const o = Object.assign({ drift: 0.004, vol: 0.02, start: 100, sell: 800, price: null, trendLen: 31, platform: 'youpin' }, opts);
  const trend = []; let p = o.start;
  for (let i = 0; i < o.trendLen; i++) { p = p * Math.exp(o.drift + (i % 5 === 0 ? o.vol : -o.vol * 0.6)); trend.push(Math.round(p * 100) / 100); }
  return { id: String(id), name, family, platform_key: o.platform, price: o.price === null ? trend[trend.length - 1] : o.price, sell_count: o.sell, ratio: 0, trend };
}
const DAYNUM = s => Math.round(Date.parse(s + 'T00:00:00Z') / 86400000);
const TODAY = 20000, dayStr = n => new Date(n * 86400000).toISOString().slice(0, 10);

// ---- whitelist ----------------------------------------------------------------
test('whitelist ships 816 entries with unique numeric ids', () => {
  assert.equal(WL.COUNT, 816);
  const ids = WL.ITEMS.map(x => x.id);
  assert(ids.every(id => /^\d+$/.test(id)), 'every entry has a numeric id');
  assert.equal(new Set(ids).size, ids.length, 'ids are unique');
  assert.equal(WL.unresolved().length, 0);
  assert.equal(WL.byId(ids[0]).name, WL.ITEMS[0].name);
  assert.equal(WL.allowed({ id: ids[3] }), true);
  assert.equal(WL.allowed({ name: 'AK-47 | 水栽竹 (崭新出厂)' }), true);
  assert.equal(WL.allowed({ name: '印花 | 某战队' }), false);
});
test('baseName strips wear suffix only; familyOf takes text before |', () => {
  assert.equal(S.baseName('AK-47 | 水栽竹 (崭新出厂)'), 'AK-47 | 水栽竹');
  assert.equal(S.baseName('运动手套（★） | 树篱迷宫 (久经沙场)'), '运动手套（★） | 树篱迷宫');
  assert.equal(S.baseName('残酷的达里尔爵士（迈阿密）| 专业人士'), '残酷的达里尔爵士（迈阿密）| 专业人士');
  assert.equal(S.familyOf('AK-47 | 水栽竹 (崭新出厂)'), 'AK-47');
  assert.equal(S.familyOf('弹弓 | 凤凰战士'), '弹弓');
});
test('resolvePlan: shipped ids need no search; directory overrides; missing grouped by base name', () => {
  const wl = [
    { market_hash_name: 'A (Factory New)', name: 'AK-47 | 甲 (崭新出厂)', id: '11' },
    { market_hash_name: 'A (Minimal Wear)', name: 'AK-47 | 甲 (略有磨损)', id: '' },
    { market_hash_name: 'A (Field-Tested)', name: 'AK-47 | 甲 (久经沙场)', id: '' },
    { market_hash_name: 'B', name: 'AWP | 乙 (崭新出厂)', id: '' },
    { market_hash_name: 'C', name: 'AWP | 丙 (崭新出厂)', id: '33' },
  ];
  const p = S.resolvePlan(wl, { B: '22', C: '999' });
  assert.deepEqual(p.items.map(x => x.id), ['11', '22', '999'], 'directory wins over shipped id');
  assert.equal(p.missing.length, 2);
  assert.deepEqual(p.terms, ['AK-47 | 甲'], 'one search term for both missing wears');
  assert.equal(p.items[0].family, 'AK-47');
  assert.equal(S.resolvePlan(WL.ITEMS, {}).terms.length, 0, 'real whitelist needs zero searches');
});
test('absorbSearch: exact hash/name matches only, skips already-known, ignores junk', () => {
  const wl = [{ market_hash_name: 'AK-47 | X (Factory New)', name: 'AK-47 | X (崭新出厂)', id: '' }, { market_hash_name: 'AK-47 | Y (Factory New)', name: 'AK-47 | Y (崭新出厂)', id: '5' }];
  const list = [
    { id: 101, market_hash_name: 'AK-47 | X (Factory New)', name: 'AK-47 | X (崭新出厂)' },
    { id: 102, market_hash_name: 'AK-47 | X (Minimal Wear)', name: 'AK-47 | X (略有磨损)' },   // not whitelisted
    { id: 103, market_hash_name: 'AK-47 | Y (Factory New)', name: 'AK-47 | Y (崭新出厂)' },   // already has id
    { id: 'abc', market_hash_name: 'AK-47 | X (Factory New)' },                             // bad id
    null,
  ];
  assert.deepEqual(S.absorbSearch(list, wl, {}), { 'AK-47 | X (Factory New)': '101' });
  assert.deepEqual(S.absorbSearch(list, wl, { 'AK-47 | X (Factory New)': '77' }), {});
  assert.deepEqual(S.absorbSearch(undefined, wl, {}), {});
});

// ---- K refresh planning ----------------------------------------------------------
test('kPlan: no cache → full at kDepth', () => {
  assert.deepEqual(S.kPlan(null, TODAY), { mode: 'full', range: 720 });
  assert.deepEqual(S.kPlan({ lastDay: dayStr(TODAY - 3) }, TODAY), { mode: 'full', range: 720 });   // n missing
  assert.equal(S.kPlan(null, TODAY, { kDepth: 1440 }).range, 1440);
});
test('kPlan: cache containing yesterday is fresh → no request', () => {
  assert.equal(S.kPlan({ lastDay: dayStr(TODAY - 1), n: 400 }, TODAY).mode, 'fresh');
  assert.equal(S.kPlan({ lastDay: dayStr(TODAY), n: 400 }, TODAY).mode, 'fresh');
});
test('kPlan: stale cache → short tail sized to the gap (+pad, ≥60)', () => {
  const p1 = S.kPlan({ lastDay: dayStr(TODAY - 2), n: 400 }, TODAY);
  assert.equal(p1.mode, 'tail'); assert.equal(p1.range, 60);
  const p2 = S.kPlan({ lastDay: dayStr(TODAY - 101), n: 400 }, TODAY);
  assert.equal(p2.mode, 'tail'); assert.equal(p2.range, 100 + 45);
});
test('kPlan: cache too old to bridge or too thin → full', () => {
  assert.equal(S.kPlan({ lastDay: dayStr(TODAY - 700), n: 400 }, TODAY).mode, 'full');
  assert.equal(S.kPlan({ lastDay: dayStr(TODAY - 2), n: 12 }, TODAY).mode, 'full');
});
test('estimate: counts × cost ÷ concurrency; full cost depends on the first-fetch depth', () => {
  const e = S.estimate({ full: 100, tail: 0 }, { concurrency: 1, delayMin: 0, delayMax: 0, kDepth: 1440 });
  assert.equal(e.requests, 100); assert(Math.abs(e.minutes - 100 * S.COST.full / 60) < 1e-9);
  const e720 = S.estimate({ full: 100, tail: 0 }, { concurrency: 1, delayMin: 0, delayMax: 0, kDepth: 720 });
  assert(Math.abs(e720.minutes - 100 * S.COST.full720 / 60) < 1e-9); assert(e720.minutes < e.minutes);
  const e3 = S.estimate({ full: 100 }, { concurrency: 3, delayMin: 0, delayMax: 0, kDepth: 1440 });
  assert(Math.abs(e3.minutes * 3 - e.minutes) < 1e-9);
  assert(e3.minutesHigh > e3.minutes && e3.minutes > e3.minutesLow);
  const daily = S.estimate({ tail: 800 }, { concurrency: 3 });
  assert(daily.minutes < 6, 'daily refresh of the whole whitelist at c=3 must be a few minutes, got ' + daily.minutes);
});

// ---- coarse (reference) --------------------------------------------------------
test('coarse bounded and named', () => { const c = S.coarse(row(1, 'AK-47 | 测试', 'AK-47')); assert.equal(c.ok, true); assert(c.entry >= 0 && c.entry <= 100); assert(['止跌转折型', '趋势回撤型', '突破适配型'].includes(c.branchName)); });
test('coarse rejects short series and invalid values', () => { assert.equal(S.coarse(row(2, 'AWP | 短', 'AWP', { trendLen: 6 })).ok, false); const r = row(3, 'AWP | 坏', 'AWP'); r.trend[5] = 0; assert.equal(S.coarse(r).ok, false); });

// ---- universe -------------------------------------------------------------------
const items = (n, fam, off = 0) => Array.from({ length: n }, (_, i) => ({ id: String(off + i), name: fam + ' | ' + i + ' (崭新出厂)', family: fam }));
test('universe: dedupes ids, applies reject hook, interleaves families', () => {
  const rows = items(60, 'AK-47', 100).concat(items(20, 'AWP', 200), [{ id: '100', name: 'AK-47 | 0 (崭新出厂)', family: 'AK-47' }, { id: 'x', name: 'bad' }, { id: '300', name: 'AK-47（StatTrak™） | s (崭新出厂)', family: 'AK-47' }]);
  const u = S.buildUniverse(rows, { reject: r => (/StatTrak/.test(r.name) ? 'stattrak' : null) });
  assert.equal(u.dropped.duplicate, 1); assert.equal(u.dropped.invalid, 1); assert.equal(u.dropped.rules, 1);
  assert.deepEqual(u.ruleReasons, { stattrak: 1 });
  assert.equal(u.items.length, 80);
  assert.equal(u.items[0].family, 'AK-47'); assert.equal(u.items[1].family, 'AWP');
  assert.equal(u.familyCounts['AWP'], 20);
});
test('universe: priority items (holdings) come first regardless of family', () => {
  const rows = items(30, 'AK-47', 100).concat(items(5, 'AWP', 200));
  const u = S.buildUniverse(rows, { priority: r => (r.id === '204' || r.id === '129' ? 2 : 0) });
  assert.deepEqual(u.items.slice(0, 2).map(x => x.id).sort(), ['129', '204']);
  assert.equal(u.items.length, 35);
});
test('universe: target caps the list but keeps every family represented', () => {
  const u = S.buildUniverse(items(60, 'AK-47', 100).concat(items(20, 'AWP', 200)), { target: 30 });
  assert.equal(u.items.length, 30); assert(u.familyCounts['AWP'] >= 10);
});

// ---- merge / csv / sort / summarize ---------------------------------------------
test('mergeRow marks pending when deep is null and carries deep scores', () => {
  const item = S.buildUniverse(items(1, 'AK-47', 1)).items[0];
  const m0 = S.mergeRow(item, null);
  assert.equal(m0.deepOk, false); assert.equal(m0.deepReason, '未精算'); assert.equal(m0.url, 'https://firepulse.com.cn/cs2/1'); assert.equal(m0.platform, 'youpin');
  const m = S.mergeRow(item, { ok: true, entry: 71, branchName: '止跌转折型', status: '可关注', trend: 44, pullback: 71, breakout: 9, reversal: 71, liquidity: 52, relativeVolume: 1.4, eligible: true, reasons: ['r'], risks: ['k'], invalidation: { price: 123 }, features: { sigma: 0.02 } });
  assert.equal(m.deepEntry, 71); assert.equal(m.invalidationPrice, 123);
});
test('csv has 选品分 / 买入价上限 / 悠悠在售价 columns, escapes quotes, BOM', () => {
  const item = S.buildUniverse([{ id: '1', name: 'AK-47 | " quoted " (崭新出厂)' }]).items[0];
  const r = Object.assign(S.mergeRow(item, null), { selPct: 88, selQ: 5, close: 12.345, limit: 12.59, ask: 12.4, askCount: 7, lastDay: '2026-09-25', fetch: '增量' });
  const csv = S.toCSV([r]), lines = csv.split('\r\n');
  assert.equal(lines.length, 2); assert.equal(lines[0].split(',').length, S.CSV_COLUMNS.length);
  assert(lines[0].includes('选品分百分位') && lines[0].includes('买入价上限') && lines[0].includes('悠悠在售价') && lines[0].includes('本次数据来源') && !lines[0].includes('今日买点状态'));
  assert(lines[1].includes('"" quoted ""') && lines[1].includes('12.345') && lines[1].includes('12.4') && lines[1].includes('增量'));
  assert(csv.charCodeAt(0) === 0xFEFF);
});
test('sortRows numbers first, honours direction, zh collation for strings', () => {
  const rows = [{ e: null }, { e: 5 }, { e: 90 }];
  assert.deepEqual(S.sortRows(rows, 'e', 'desc').map(r => r.e), [90, 5, null]);
  assert.deepEqual(S.sortRows(rows, 'e', 'asc').map(r => r.e), [5, 90, null]);
});
test('summarize counts quintiles, picks (≥P80), ranked, scanned and pending', () => {
  const s = S.summarize([{ deepOk: true, selPct: 92, selQ: 5, lastDay: 'd' }, { deepOk: true, selPct: 30, selQ: 2, lastDay: 'd' }, { deepOk: false, deepReason: 'K线不足' }, { deepOk: false, deepReason: '未精算' }, { deepOk: false, deepReason: '' }]);
  assert.equal(s.total, 5); assert.equal(s.deep, 2); assert.equal(s.scanned, 2); assert.equal(s.pending, 1);
  assert.equal(s.picks, 1); assert.equal(s.ranked, 2); assert.deepEqual(s.byQ, { Q5: 1, Q2: 1 }); assert.deepEqual(s.failedReasons, { 'K线不足': 1 });
});
test('report carries universe stats and a caveat', () => {
  const u = S.buildUniverse(items(3, 'AK-47'));
  const r = S.report({ config: { concurrency: 3 }, rows: [], universe: u });
  assert.equal(r.universe.kept, 3); assert.equal(r.version, S.VERSION); assert(r.caveat.includes('白名单'));
});
console.log(`${t} tests passed`);
