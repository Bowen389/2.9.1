// node tests/buy.cjs — Lab 2.6 今日买点 / 单品买点结论 / 我的持仓 (pure functions + store, no DOM).
'use strict';
const assert = require('node:assert/strict');
const BY = require('../buy-core.js');
const ST = require('../store.js');
let passed = 0;
const pending = [];
const test = (name, fn) => pending.push([name, fn]);

const rows = Array.from({ length: 50 }, (_, i) => ({ id: 1000 + i, name: '商品 ' + i, day: '2026-09-25', url: 'u' + i, close: 100 + i, sel30: i * 2, sel14: 98 - i * 2, why30: ['理由A', '理由B', '理由C', '理由D'] }));
rows.push({ id: 9, name: '规则外', close: 50, sel30: null, sel14: null });

// ---- dates ---------------------------------------------------------------------
test('dates: Beijing calendar day, addDays and daysBetween', () => {
  assert.equal(BY.bjDay(Date.UTC(2026, 8, 25, 16, 30)), '2026-09-26', '00:30 Beijing is already the 26th');
  assert.equal(BY.bjDay(Date.UTC(2026, 8, 25, 15, 59)), '2026-09-25');
  assert.equal(BY.addDays('2026-09-26', 30), '2026-10-26');
  assert.equal(BY.addDays('2026-12-30', 3), '2027-01-02');
  assert.equal(BY.daysBetween('2026-09-24', '2026-09-26'), 2);
});

// ---- recommend -------------------------------------------------------------------
test('recommend: only 选品分 ≥ P80, sorted desc, top-N flagged, reasons capped at 3', () => {
  const r = BY.recommend(rows, { h: 30, signalDay: '2026-09-25', today: '2026-09-26', regime: { score: 60 }, gate: 30, topN: 5 });
  assert.equal(r.ranked, 50); assert.deepEqual(r.picks.map(p => p.pct), [98, 96, 94, 92, 90, 88, 86, 84, 82, 80]);
  assert.equal(r.nTop, 5); assert(r.picks.slice(0, 5).every(p => p.top) && r.picks.slice(5).every(p => !p.top));
  assert.equal(r.picks[0].why.length, 3); assert.equal(r.picks[0].id, '1049');
  assert(!r.picks.some(p => p.name === '规则外'));
});
test('recommend: buy cap = last close × 1.02; hold-until and valid-until dates', () => {
  const r = BY.recommend(rows, { h: 30, signalDay: '2026-09-25', today: '2026-09-26', gate: 30 });
  assert.equal(r.picks[0].close, 149); assert.equal(r.picks[0].limit, 151.98);
  assert.equal(r.holdTo, '2026-10-26'); assert.equal(r.validTo, '2026-09-27'); assert.equal(r.stale, false);
});
test('recommend: horizon picks its own column (14 vs 30)', () => {
  const r = BY.recommend(rows, { h: 14, signalDay: '2026-09-25', today: '2026-09-26', gate: 30 });
  assert.equal(r.picks[0].id, '1000'); assert.equal(r.picks.length, 10);
});
test('recommend: signals older than 2 days are stale', () => {
  assert.equal(BY.recommend(rows, { h: 30, signalDay: '2026-09-24', today: '2026-09-26', gate: 30 }).stale, false);
  const r = BY.recommend(rows, { h: 30, signalDay: '2026-09-23', today: '2026-09-26', gate: 30 });
  assert.equal(r.stale, true); assert.equal(r.age, 3);
});
test('recommend: weak market (score < gate) turns the list into a watch list; missing index blocks execution', () => {
  assert.equal(BY.recommend(rows, { h: 30, signalDay: '2026-09-25', today: '2026-09-26', regime: { score: 22 }, gate: 30 }).gateOn, true);
  assert.equal(BY.recommend(rows, { h: 30, signalDay: '2026-09-25', today: '2026-09-26', regime: null, gate: 30 }).blocked, true);
});
test('recommend: fewer than 30 ranked items flagged; empty input is safe', () => {
  assert.equal(BY.recommend(rows.slice(0, 20), { h: 30, today: '2026-09-26', gate: 30 }).tooFew, true);
  const e = BY.recommend([], { h: 30, today: '2026-09-26', gate: 30 });
  assert.equal(e.picks.length, 0); assert.equal(e.stale, true);
});

// ---- verdict ---------------------------------------------------------------------
const V = o => BY.verdict(Object.assign({ ok: true, pct: 85, tradable: true, ruleOk: true, regime: { score: 60 }, gate: 30, h: 30, close: 100, signalDay: '2026-09-25', today: '2026-09-26', coverage: 1 }, o));
test('verdict: P≥80 + tradable + in rules + market OK → 符合买点 with a price cap', () => {
  const v = V({}); assert.equal(v.level, 'yes'); assert.equal(v.buy, true); assert.equal(v.limit, 102);
});
test('verdict: same item in a weak market → 暂缓 (still marked as a buy point)', () => {
  const v = V({ regime: { score: 20 } }); assert.equal(v.level, 'wait'); assert.equal(v.buy, true); assert(v.text.includes('暂缓'));
});
test('verdict: rules, liquidity and data problems override the score', () => {
  assert.equal(V({ ruleOk: false, ruleText: '刀具' }).level, 'no');
  assert(V({ ruleOk: false, ruleText: '刀具' }).text.startsWith('刀具'));
  assert.equal(V({ tradable: false }).level, 'no');
  assert.equal(V({ ok: false, reason: '历史不足' }).level, 'na');
  assert.equal(V({ pct: null }).level, 'na');
});
test('verdict: P60–80 / P40–60 → 观望, below P40 → 不建议', () => {
  assert.equal(V({ pct: 70 }).level, 'watch'); assert.equal(V({ pct: 50 }).level, 'watch');
  assert.equal(V({ pct: 30 }).level, 'no'); assert.equal(V({ pct: 30 }).buy, false);
});

// ---- holdings ----------------------------------------------------------------------
const H = { hid: 'x', id: '1', name: 'A', buyDay: '2026-09-20', buyPrice: 100, qty: 2, sellBy: '2026-10-20', status: 'open' };
test('holding: P&L is net of the 1% sale cost; cooldown for the first 7 days', () => {
  const s = BY.holdingState(H, 110, '2026-09-24', { fee: 0.01 });
  assert.equal(s.status, 'lock'); assert(s.label.includes('3 天后可卖'));
  assert(Math.abs(s.pnl - 2 * (110 * 0.99 - 100)) < 1e-9); assert(Math.abs(s.pnlPct - 0.089) < 1e-9);
});
test('holding: open after cooldown with days left; due on/after sell-by', () => {
  const s = BY.holdingState(H, 100, '2026-10-01', { fee: 0.01 });
  assert.equal(s.status, 'open'); assert.equal(s.daysLeft, 19); assert(s.pnl < 0, 'break-even needs +1%');
  assert.equal(BY.holdingState(H, 100, '2026-10-20').status, 'due');
});
test('holding: no current price → no P&L; sold → realized return', () => {
  assert.equal(BY.holdingState(H, null, '2026-10-01').pnl, null);
  const s = BY.holdingState(Object.assign({}, H, { status: 'sold', sellDay: '2026-10-21', sellPrice: 120 }), null, '2026-10-22', { fee: 0.01 });
  assert.equal(s.status, 'sold'); assert.equal(s.heldDays, 31); assert(Math.abs(s.pnl - 2 * (120 * 0.99 - 100)) < 1e-9);
});
test('holding: summary adds open cost/value/P&L and realized separately', () => {
  const list = [H, Object.assign({}, H, { hid: 'y', id: '2', qty: 1 }), Object.assign({}, H, { hid: 'z', id: '3', status: 'sold', sellPrice: 90, qty: 1 })];
  const s = BY.summarizeHoldings(list, { 1: 110, 2: 90 }, '2026-10-01', { fee: 0.01 });
  assert.equal(s.open, 2); assert.equal(s.sold, 1); assert.equal(s.cost, 300);
  assert(Math.abs(s.pnl - (2 * (108.9 - 100) + (89.1 - 100))) < 1e-9); assert(Math.abs(s.realized - (89.1 - 100)) < 1e-9);
  assert.equal(BY.summarizeHoldings(list, { 1: 110 }, '2026-10-01').pnlPct, null, 'no % while an item is unpriced');
});

// ---- store --------------------------------------------------------------------------
test('store: holdings add / update / remove; export → reset → import round trip', async () => {
  await ST.resetAll();
  assert.equal(ST.DEFAULT_SETTINGS.h, 30, '2.6 default horizon');
  const a = await ST.addHolding({ id: '11', name: 'A', buyPrice: 10 });
  const b = await ST.addHolding({ id: '12', name: 'B', buyPrice: 20, qty: 2 });
  assert(a.hid && b.hid && a.hid !== b.hid); assert.equal(a.qty, 1); assert.equal(a.status, 'open');
  assert.deepEqual((await ST.holdings()).map(h => h.id), ['12', '11'], 'newest first');
  await ST.updateHolding(a.hid, { qty: 5, hid: 'hijack' });
  assert.equal((await ST.holdings()).find(h => h.id === '11').qty, 5);
  assert((await ST.holdings()).every(h => h.hid !== 'hijack'), 'hid cannot be overwritten');
  const dump = await ST.exportAll({});
  assert.equal(dump.holdings.length, 2);
  await ST.resetAll();
  assert.equal((await ST.holdings()).length, 0, 'reset clears holdings');
  await assert.rejects(() => ST.importAll(Object.assign({}, dump, { holdings: dump.holdings.concat([{ id: 'no-hid' }, null]) })), /持仓/);
  await ST.importAll(dump);
  assert.equal((await ST.holdings()).length, 2, 'import restores valid holdings only');
  await ST.removeHolding(b.hid);
  assert.deepEqual((await ST.holdings()).map(h => h.id), ['11']);
});

// 2.9: a browser coming from 2.7 / 2.8 keeps its trades — ledger `lots` are
// converted into 2.6.1 holdings once (flag holdingsFrom28); the old key stays.
test('store: 2.7/2.8 lots are migrated into holdings once; sold lots keep sell day/price; old key kept as backup', async () => {
  await ST.resetAll();
  await ST.set('lots', [
    { key: 'lot-a', id: '501', name: 'A', price: 100, quantity: 2, at: '2026-09-10T04:00:00.000Z', targetDays: 14, status: 'open' },
    { key: 'lot-b', id: '502', name: 'B', price: 50, quantity: 1, at: '2026-08-01T04:00:00.000Z', targetDays: 30, status: 'sold', soldPrice: 60, soldAt: '2026-09-01T04:00:00.000Z' },
    { key: 'bad', id: 'x', price: 1, quantity: 1, status: 'open' },
  ]);
  const hs = await ST.holdings();
  assert.deepEqual(hs.map(h => [h.id, h.qty, h.h, h.buyDay, h.sellBy, h.status, h.sellDay, h.sellPrice]), [
    ['501', 2, 14, '2026-09-10', '2026-09-24', 'open', null, null],
    ['502', 1, 30, '2026-08-01', '2026-08-31', 'sold', '2026-09-01', 60],
  ]);
  assert.equal((await ST.get('lots', [])).length, 3, 'old key untouched');
  await ST.removeHolding(hs[0].hid);
  assert.equal((await ST.holdings()).length, 1, 'migration runs once: removed record does not come back');
  const added = await ST.addHolding({ id: '503', name: 'C', buyPrice: 9 });
  assert.equal((await ST.holdings())[0].hid, added.hid);
  await ST.resetAll();
  assert.equal((await ST.holdings()).length, 0);
});

(async () => {
  for (const [name, fn] of pending) { await fn(); passed++; console.log('PASS', name); }
  console.log(passed + ' buy tests passed');
})().catch(e => { console.error(e); process.exitCode = 1; });
