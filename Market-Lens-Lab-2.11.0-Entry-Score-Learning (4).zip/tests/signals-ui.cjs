'use strict';
const assert=require('node:assert/strict'),{boot,waitFor,txt,wait,windows}=require('./panel.cjs');let n=0;
async function test(label,fn){await fn();console.log('PASS SIGNAL UI',++n,label);}
(async()=>{try{
await test('main view exposes deep review and independent state/reason columns',async()=>{
 const b=boot('https://firepulse.com.cn/home',{items:40});b.root.getElementById('open').click();await wait(40);assert(b.root.getElementById('deepReview'));b.mock.askOf=()=>1;b.root.getElementById('buyScan').click();await waitFor(b.root,()=>txt(b.root).includes('悠悠在售价已读取'),'quote loaded',10000);
 assert([...b.root.querySelectorAll('th')].some(x=>x.textContent==='触发状态'));assert([...b.root.querySelectorAll('th')].some(x=>x.textContent==='判断理由'));assert(b.root.querySelector('.signal-state'));assert(b.root.querySelector('.signal-reason details'));assert(txt(b.root).includes('全平台'));
 const before=b.calls.k; b.root.getElementById('deepReview').click();await waitFor(b.root,()=>txt(b.root).includes('市场扫盘')&&txt(b.root).includes('扫描完成'),'deep review',10000);assert.equal(b.calls.k,before);assert(b.root.querySelector('.signal-state'));assert(b.root.querySelector('.signal-reason'));b.w.close();
});
await test('weak market never displays triggered confirmation',async()=>{const b=boot('https://firepulse.com.cn/home',{items:40});b.root.getElementById('open').click();await wait(30);b.mock.marketWeak=true;b.mock.askOf=()=>1;b.root.getElementById('buyScan').click();await waitFor(b.root,()=>txt(b.root).includes('悠悠在售价已读取'),'weak quote',10000);assert.equal(b.root.querySelectorAll('[data-signal="trigger"]').length,0);assert(b.root.querySelector('[data-signal="blocked"]'));b.w.close();});
console.log(`${n} signal UI tests passed`);
}finally{for(const w of windows)w.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
