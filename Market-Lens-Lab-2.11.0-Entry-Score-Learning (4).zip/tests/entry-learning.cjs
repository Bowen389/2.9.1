'use strict';
const A=require('node:assert/strict'),E=require('../entry-score-core'),L=require('../learning-core'),S=require('../store');let n=0;async function test(t,f){await f();console.log('PASS ENTRY LEARNING',++n,t);}

const rowGoodRifle={
  id:'101',name:'AK-47 | 火神 (崭新出厂)',family:'AK-47',
  selPct:90,deepEntry:80,ask:500,limit:520,relativeVolume:1.3,eligible:true,risks:''
};

const rowBadShotgun={
  id:'102',name:'新星 | 古董枪 (崭新出厂)',family:'新星',
  selPct:99.9,deepEntry:20,ask:60,limit:65,relativeVolume:1.3,eligible:true,
  risks:'最近3日收盘动量仍未转正；最近3根仍包含新的20根收盘低点'
};

const batch={
  version:L.VERSION,key:'test',captureDay:'2026-01-01',signalDay:'2025-12-31',capturedAt:'2026-01-01T04:00:00Z',
  fee:.01,model:{id:'m'},scoreRule:{version:E.VERSION},rows:[{...rowGoodRifle,entry:E.evaluate(rowGoodRifle,{code:'trigger'})}]
};

const day=s=>Date.parse(s+'T00:00:00Z')/86400000;
const series={ok:true,day0:day('2026-01-02'),n:32,c:Array.from({length:32},(_,i)=>100+i),real:Array(32).fill(1)};

(async()=>{
await test('good rifle gets high score (>=70)',()=>{
  const res=E.evaluate(rowGoodRifle,{code:'trigger'});
  A(res.score>=70, `Expected >=70 but got ${res.score}`);
  A.equal(res.category,'步枪/狙击');
  A.equal(res.discount,1.0);
});

await test('falling shotgun penalized and discounted to low score (<=40)',()=>{
  const res=E.evaluate(rowBadShotgun,{code:'blocked',summary:'大盘风险闸门'});
  A(res.score<=40, `Expected <=40 but got ${res.score}`);
  A.equal(res.category,'其余武器(微冲/霰弹/机枪)');
  A.equal(res.discount,0.85);
});

await test('missing selPct suppresses score',()=>A.equal(E.evaluate({...rowGoodRifle,selPct:null},{code:'trigger'}).score,null));

await test('next day proxy is later than observation and exact horizon',()=>{
  const o=L.outcomes(batch,{'101':series},Date.parse('2026-02-05'));
  A.equal(o[0].entryDay,'2026-01-02');
  A.equal(o[0].exitDay,'2026-01-09');
  A.equal(o[0].net,107*.99/100-1);
  A.equal(o.length,3);
});

await test('unfinished UTC day cannot settle',()=>A.equal(L.outcomes(batch,{'101':series},Date.parse('2026-01-09T23:59:59Z'))[0].status,'pending'));
await test('future cache does not leak',()=>A(L.outcomes(batch,{'101':series},Date.parse('2026-01-02')).every(o=>o.net===null)));
await test('missing exit does not forward fill',()=>{const s={...series,real:series.real.slice()};s.real[7]=0;const o=L.outcomes(batch,{'101':s},Date.parse('2026-02-05'));A.equal(o[0].status,'missing');A.equal(o[0].net,null);});
await test('saved first snapshot immutable',async()=>{await S.clearLearning();await S.saveLearningBatch(batch);await S.saveLearningBatch({...batch,rows:[{...rowGoodRifle,entry:{score:0}}]});A( (await S.learningData()).batches[0].rows[0].entry.score > 0);});
await test('duplicate goods rejected',async()=>{await A.rejects(async()=>S.saveLearningBatch({...batch,key:'dup',rows:[...batch.rows,...batch.rows]}));});
await test('results stored separately first observed immutable',async()=>{const o=L.outcomes(batch,{'101':series},Date.parse('2026-02-05'));await S.saveLearningOutcomes(o);await S.saveLearningOutcomes(o);const d=await S.learningData();A.equal(d.outcomes.length,3);});
await test('invalid future result rejected',async()=>{const o=L.outcomes(batch,{'101':series},Date.parse('2026-02-05'))[0];await A.rejects(async()=>S.saveLearningOutcomes([{...o,observedAt:'2026-01-09T12:00:00Z'}]));});
await test('invalid result math rejected',async()=>{const o=L.outcomes(batch,{'101':series},Date.parse('2026-02-05'))[0];await A.rejects(async()=>S.saveLearningOutcomes([{...o,net:999}]));});
await test('clearing learning preserves holdings',async()=>{const h=await S.holdings();await S.clearLearning();A.deepEqual(await S.holdings(),h);A.equal((await S.learningData()).batches.length,0);});
console.log(n+' entry learning tests passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
