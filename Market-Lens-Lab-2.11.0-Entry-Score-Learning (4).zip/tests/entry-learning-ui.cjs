'use strict';
const A=require('node:assert/strict'),{boot,waitFor,txt,wait,windows}=require('./panel.cjs');let n=0;async function test(t,f){await f();console.log('PASS LEARNING UI',++n,t);}
(async()=>{try{
let b=boot('https://firepulse.com.cn/home',{items:40});b.root.getElementById('open').click();await wait(40);b.mock.askOf=()=>1;
await test('learning export accessible without scan',()=>A(b.root.getElementById('learningJson')));
b.root.getElementById('buyScan').click();await waitFor(b.root,()=>txt(b.root).includes('悠悠在售价已读取'),'scan',15000);
await test('main table simplified and numeric scores visible',()=>{const heads=[...b.root.querySelectorAll('#liveResults th')].map(x=>x.textContent);A(heads.includes('入场评分'));A(!heads.includes('选品分'));A([...b.root.querySelectorAll('[data-entry-score]')].some(e=>e.dataset.entryScore!==''));A(b.root.querySelector('[data-buy]'));});
const before=JSON.stringify(b.calls);
await test('freezes all scanned goods with full factors without network',async()=>{b.root.getElementById('learningCapture').click();await waitFor(b.root,()=>txt(b.root).includes('已冻结全扫描学习样本')||txt(b.root).includes('未完成：'),'capture',10000);A(!txt(b.root).includes('未完成：'),txt(b.root).slice(-2000));const d=await b.ST.learningData();A.equal(d.batches.length,1);A(d.batches[0].rows.length>30);A(d.batches[0].rows.some(r=>!r.candidate));A(d.batches[0].rows.some(r=>r.factorEvidence?.[30]?.features));A.equal(JSON.stringify(b.calls),before);A(b.root.getElementById('learningBox').open);});
await test('same day repeated freeze does not overwrite',async()=>{const old=JSON.stringify(await b.ST.learningData());b.root.getElementById('learningCapture').click();await waitFor(b.root,()=>txt(b.root).includes('首份已存在'),'repeat');A.equal(JSON.stringify(await b.ST.learningData()),old);});
await test('immature settlement keeps result storage empty',async()=>{b.root.getElementById('learningSettle').click();await waitFor(b.root,()=>txt(b.root).includes('已保存 0 条到期结果'),'settle');A.equal((await b.ST.learningData()).outcomes.length,0);A.equal(JSON.stringify(b.calls),before);});
await test('scan detail defaults to score ordering, supports manual entry',async()=>{b.root.getElementById('buyGoAdv').click();A.equal(b.root.getElementById('sortKey').value,'entryScore');const scores=[...b.root.querySelectorAll('[data-entry-score]')].map(e=>e.dataset.entryScore).filter(x=>x!=='').map(Number);A.deepEqual(scores,scores.slice().sort((a,b)=>b-a));A(b.root.querySelector('[data-buy]'));});
b.w.close();
console.log(n+' entry learning UI tests passed');
}finally{for(const w of windows)w.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
