// node tests/youpin.cjs — 悠悠有品口径 + 1% 成本 (pure functions + store, no DOM). 2.9: quote helpers kept, list/quote-round tests dropped with the code.
'use strict';
const assert = require('node:assert/strict');
const S = require('../scanner-core.js');
const L = require('../legacy-core.js');
const ST = require('../store.js');
const DAY = 86400000;
let passed = 0;
const pending = [];
const test = (name, fn) => pending.push([name, fn]);

const quote = (sell, extra) => ({ code: 200, data: Object.assign({ sell }, extra || {}) });
const listRow = (id, name, family, price, sell) => ({ id: String(id), name, family, price, sell_count: sell, platform_key: 'buff', trend: [] });

// ---- youpinQuote -------------------------------------------------------------
test('youpinQuote: takes the youpin row only, never another platform', () => {
  const q = S.youpinQuote(quote([
    { platform_key: 'buff', price: 170, count: 9000, trend: [1, 2] },
    { platform_key: 'youpin', price: 175, count: 11103, trend: [178.29, 176, 172.9, 174, 175, 174.48, 175], trade_fee: 1 },
    { platform_key: 'ecosteam', price: 174, count: 2396 },
  ]));
  assert.equal(q.ok, true); assert.equal(q.platform, 'youpin'); assert.equal(q.price, 175); assert.equal(q.count, 11103);
  assert.equal(q.tradeFee, 1); assert.equal(q.points, 7);
  assert(Math.abs(q.chg7 - (175 / 178.29 - 1)) < 1e-12);
  assert(q.liquidity > 0 && q.liquidity <= 100);
});
test('youpinQuote: no youpin row / price 0 (no listing) / duplicate rows / bad response are rejected', () => {
  assert.equal(S.youpinQuote(quote([{ platform_key: 'buff', price: 170 }])).reason, '悠悠无报价');
  assert.equal(S.youpinQuote(quote([{ platform_key: 'youpin', price: 0, count: 0, trend: [0] }])).reason, '悠悠当前无在售');
  assert.equal(S.youpinQuote(quote([{ platform_key: 'youpin', price: 1 }, { platform_key: 'youpin', price: 2 }])).ok, false);
  assert.equal(S.youpinQuote({ code: 500 }).ok, false);
  assert.equal(S.youpinQuote(null).ok, false);
});

// ---- universe (listOnly) + deep order -----------------------------------------
// 2.9: the keyword list phase, the per-item quote round (rankForDeep /
// estimatePlan) and the list-price pre-filter are gone. The youpin ask is only
// read for the recommended picks; rows carry it as ask/askCount/askDay.
test('mergeRow + CSV (2.9): platform youpin, price = youpin K close / ask columns; CSV headers say 悠悠', () => {
  const item = { id: '9', name: 'AK-47 | a (崭新出厂)', family: 'AK-47', hash: 'AK-47 | a (Factory New)', row: { platform_key: 'youpin', price: null, rarity: '' }, coarse: {} };
  const m = S.mergeRow(item, null);
  assert.equal(m.platform, 'youpin'); assert.equal(m.price, null); assert.equal(m.hash, 'AK-47 | a (Factory New)');
  assert.equal(m.url, 'https://firepulse.com.cn/cs2/9');
  m.close = 175; m.ask = 176.5; m.askCount = 120; m.askDay = '2026-09-26'; m.limit = 178.5; m.selPct = 91;
  const csv = S.toCSV([m]).split('\r\n');
  assert(csv[0].includes('悠悠在售价') && csv[0].includes('悠悠日K收盘') && csv[0].includes('悠悠在售数') && csv[0].includes('买入价上限') && !csv[0].includes('清单价') && !csv[0].includes('今日买点状态'));
  assert(csv[1].includes('"176.5"') && csv[1].includes('"175"') && csv[1].includes('"120"'));
  assert(S.report({ rows: [m] }).caveat.includes('悠悠有品日K'));
  const sum = S.summarize([m, Object.assign(S.mergeRow(item, null), { selPct: 40 })]);
  assert.equal(sum.picks, 1); assert.equal(sum.ranked, 2);
});
test('youpinQuote liquidity proxy: more youpin listings → higher, bounded 0–100, never a price signal', () => {
  assert.equal(S.liquidityOf(0), 0);
  assert(S.liquidityOf(10) < S.liquidityOf(100) && S.liquidityOf(100) < S.liquidityOf(5000));
  assert(S.liquidityOf(1e9) <= 100);
  assert.equal(S.youpinQuote(quote([{ platform_key: 'youpin', price: '9.9', count: 3 }])).liquidity, S.liquidityOf(3));
});

// ---- legacy snapshot changes on the youpin basis --------------------------------
function kPayload(closes, endDay) {
  // one bar per calendar day ending at endDay (UTC ms, 00:00), plus an in-progress bar for endDay+1
  const data = closes.map((c, i) => [String((endDay - (closes.length - 1 - i) * DAY) / 1000), c, c, c * 0.99, c * 1.01, 10, 10 * c]);
  data.push([String((endDay + DAY) / 1000), 999, 999, 999, 999, 1, 999]);
  return { code: 200, data };
}
test('youpinBasis: d1/d7/d30 = youpin ask vs youpin daily-K closes; in-progress bar ignored; reference kept apart', () => {
  const end = Date.UTC(2026, 8, 25), now = end + DAY + 3600000;
  const closes = Array.from({ length: 60 }, (_, i) => 100 + i); // last close 159, 7d-back (day-6) 153, 30d-back (day-29) 130
  const k = L.kchart(kPayload(closes, end), now);
  const f = { price: 165, d1: 1, d7: 2, d30: 4, d7youpin: 7.8, changeBasis: 'firepulse-ref', crossWarnings: ['悠悠在售价近7点涨跌与参考价近7天背离', '接口d1数值不一致'] };
  const g = L.youpinBasis(f, k);
  assert.equal(g.changeBasis, 'youpin-k');
  assert(Math.abs(g.d1 - (165 / 159 - 1) * 100) < 1e-9, 'd1 ' + g.d1);
  assert(Math.abs(g.d7 - (165 / 153 - 1) * 100) < 1e-9, 'd7 ' + g.d7);
  assert(Math.abs(g.d30 - (165 / 130 - 1) * 100) < 1e-9, 'd30 ' + g.d30);
  assert.deepEqual(g.ref, { d1: 1, d7: 2, d30: 4, basis: 'firepulse-ref' });
  assert.deepEqual(g.crossWarnings, ['接口d1数值不一致'], 'reference-price warnings dropped');
  assert.equal(f.changeBasis, 'firepulse-ref', 'input not mutated');
  const w = L.score(g, k).warnings.join('|');
  assert(w.includes('悠悠口径') && !w.includes('FirePulse参考价口径'));
});
test('youpinBasis: missing K => changes null, basis none (never falls back to the reference price)', () => {
  const g = L.youpinBasis({ price: 10, d1: 1, d7: 2, d30: 3, changeBasis: 'firepulse-ref' }, null);
  assert.equal(g.d1, null); assert.equal(g.d7, null); assert.equal(g.d30, null); assert.equal(g.changeBasis, 'none');
});
test('youpinBasis: gaps use the last close on or before the target day', () => {
  const end = Date.UTC(2026, 8, 25), now = end + DAY + 1000;
  const closes = Array.from({ length: 40 }, () => 100);
  const p = kPayload(closes, end);
  p.data = p.data.filter((r, i) => i !== 40 - 7); // drop day-6
  p.data[40 - 8 - 0][2] = 90; p.data[40 - 8][1] = 90; p.data[40 - 8][3] = 89; p.data[40 - 8][4] = 91; // day-7 close 90
  const g = L.youpinBasis({ price: 99 }, L.kchart(p, now));
  assert(Math.abs(g.d7 - (99 / 90 - 1) * 100) < 1e-9, 'd7 ' + g.d7);
});

// ---- cost default 1% + one-time migration ---------------------------------------
test('store: default round-trip cost is 1%', async () => {
  await ST.resetAll();
  assert.equal(ST.DEFAULT_SETTINGS.fee, 0.01);
  assert.equal((await ST.settings()).fee, 0.01);
});
test('store: settings saved by ≤2.4 with the old 2% default move to 1% once; other values kept', async () => {
  await ST.resetAll();
  await ST.set('settings', { fee: 0.02, topN: 7 });
  const s = await ST.settings();
  assert.equal(s.fee, 0.01); assert.equal(s.topN, 7); assert.equal(s.feeV25, true);
  await ST.set('settings', { fee: 0.03 });
  assert.equal((await ST.settings()).fee, 0.03, 'a non-default custom fee is never touched');
});
test('store: a manual 2% saved in 2.5 is left alone', async () => {
  await ST.resetAll();
  await ST.saveSettings({ fee: 0.02 });
  assert.equal((await ST.settings()).fee, 0.02);
  assert.equal((await ST.settings()).fee, 0.02);
});

(async () => {
  for (const [name, fn] of pending) {
    try { await fn(); passed++; console.log('PASS', name); } catch (e) { console.error('FAIL', name); console.error(e); process.exitCode = 1; }
  }
  console.log(passed + '/' + pending.length + ' tests passed');
})();
