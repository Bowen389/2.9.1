'use strict';
const assert = require('node:assert/strict'), fs = require('node:fs'), vm = require('node:vm'), path = require('node:path');
const BY = require('../buy-core'), ST = require('../store'), F = require('../factor-core'), B = require('../model-builtin'), RPC = require('../store-rpc'), R = require('../reliability');
const DIR = path.join(__dirname,'..'), DAY=86400000;
let count=0;
async function test(name, fn) { await fn(); count++; console.log('PASS FIX', name); }
const clone=x=>JSON.parse(JSON.stringify(x));
const v = patch => BY.verdict(Object.assign({ok:true,pct:95,tradable:true,ruleOk:true,regime:{score:65},gate:30,h:30,close:100,coverage:1,signalDay:'2026-09-26',today:'2026-09-27',referenceOk:true},patch));
const rows = Array.from({length:50},(_,i)=>({id:String(i+1),name:'test',day:'2026-09-26',sel30:i*2,close:100}));
const rec = patch => BY.recommend(rows,Object.assign({h:30,signalDay:'2026-09-26',today:'2026-09-27',regime:{score:65},gate:30,complete:true},patch));
const ok=()=>({ok:true,status:200,text:async()=>'{"code":200,"data":[]}'});
const base = Date.UTC(2025,0,1);
const series=F.toSeries(Array.from({length:200},(_,i)=>[(base+i*DAY)/1000,100,100,99,101,50,5000]),{end:base+201*DAY});
function serviceHarness() {
  const data={}, writes=[], listeners=[], messages=[];
  const local={get:async keys=>{const out={};for(const k of(Array.isArray(keys)?keys:[keys]))if(k in data)out[k]=clone(data[k]);return out;},set:async x=>{writes.push(Object.keys(x));Object.assign(data,clone(x));},remove:async keys=>{for(const k of keys)delete data[k];}};
  function worker() {
    const w=vm.createContext({console,setTimeout,clearTimeout,btoa,atob,chrome:{storage:{local},runtime:{id:'ext',onMessage:{addListener:f=>listeners.push(f)}}}});
    w.importScripts=(...files)=>files.forEach(f=>vm.runInContext(fs.readFileSync(path.join(DIR,f),'utf8'),w));
    vm.runInContext(fs.readFileSync(path.join(DIR,'background.js'),'utf8'),w);
    return w;
  }
  worker();
  function client(url='https://firepulse.com.cn/home') {
    const c=vm.createContext({document:{},console,setTimeout,clearTimeout,btoa,atob,chrome:{storage:{local},runtime:{sendMessage:msg=>{messages.push(clone(msg));return new Promise(resolve=>listeners.at(-1)(clone(msg),{id:'ext',url},reply=>resolve(clone(reply))));}}}});
    for(const f of ['store-rpc.js','store.js'])vm.runInContext(fs.readFileSync(path.join(DIR,f),'utf8'),c);
    return c.MarketLensStore;
  }
  return {data,writes,client,restart:worker,listeners,messages};
}
(async()=>{
await test('stale historical score cannot become a current buy',()=>{const sc=F.scoreAt(series,null,{features:[{key:'mom7',w:1,mu:0,sd:1,lo:-10,hi:10}]});assert(sc.ok);assert.equal(v({signalDay:sc.day}).level,'na');});
await test('future dates are invalid, boundary 2 days accepted, impossible dates rejected',()=>{assert(BY.fresh('2026-09-25','2026-09-27'));assert(!BY.fresh('2026-09-24','2026-09-27'));assert(!BY.fresh('2026-09-28','2026-09-27'));assert(!BY.fresh('2026-02-30','2026-03-01'));});
await test('invalid recommendation date fails closed without RangeError',()=>assert(rec({signalDay:'bad'}).blocked));
await test('each pick has the exact decision day; newest item cannot freshen old items',()=>{const old=rows[49].day;rows[49].day='2026-01-26';assert(!rec().picks.some(p=>p.id==='50'));rows[49].day=old;assert(rec().picks.some(p=>p.id==='50'));});
await test('missing market blocks scan and single-item buys',()=>{assert(rec({regime:null}).blocked);assert.equal(v({regime:null}).level,'na');});
await test('weak market and incomplete/small scans block execution',()=>{assert(rec({regime:{score:20}}).blocked);assert(rec({complete:false}).blocked);assert(!rec().blocked);assert(BY.recommend(rows.slice(0,10),{h:30,signalDay:'2026-09-26',today:'2026-09-27',regime:{score:60},gate:30}).blocked);});
await test('missing factor coverage / stale reference blocks single item',()=>{assert.equal(v({coverage:.89}).level,'na');assert.equal(v({coverage:undefined}).level,'na');assert.equal(v({referenceOk:false}).level,'na');assert.equal(v().level,'yes');});
await test('API timeout works even with external non-aborted signal and hung fetch',async()=>{let attempts=0;const c=R.createClient({fetch:()=>new Promise(()=>{}),onAttempt:()=>attempts++});const ctrl=new AbortController();await assert.rejects(c.request('/x',{},ctrl.signal,20),e=>e.name==='TimeoutError');assert.equal(ctrl.signal.aborted,false);assert.equal(attempts,1);});
await test('API timeout also bounds a hung response body',async()=>{const c=R.createClient({fetch:async()=>({ok:true,status:200,text:()=>new Promise(()=>{})})});await assert.rejects(c.request('/x',{},new AbortController().signal,20),/超时/);});
await test('user cancellation interrupts hung request without retry',async()=>{let n=0;const c=R.createClient({fetch:()=>{n++;return new Promise(()=>{});},retryDelay:0});const a=new AbortController();setTimeout(()=>a.abort(),10);await assert.rejects(c.retry('/x',{},a.signal,3,1000),e=>e.name==='AbortError');assert.equal(n,1);});
await test('429 applies cooldown to retry and honors Retry-After',async()=>{const times=[];const c=R.createClient({fetch:async()=>{times.push(Date.now());return times.length===1?{status:429,headers:{get:()=>'.05'}}:ok();},cooldownMs:()=>25,retryDelay:0});await c.retry('/x',{},new AbortController().signal,2,500);assert.equal(times.length,2);assert(times[1]-times[0]>=45);});
await test('all workers share cooldown, including new calls',async()=>{let n=0;const times=[];const c=R.createClient({fetch:async()=>{times.push(Date.now());return ++n===1?{status:429}:ok();},cooldownMs:()=>40});await assert.rejects(c.request('/x',{},null,500),/429/);await c.request('/x',{},null,500);assert(times[1]-times[0]>=35);});
await test('failed attempts count; concurrent retries cannot exceed hard budget',async()=>{let n=0,attempts=0;const a=new AbortController(),c=R.createClient({fetch:async()=>{n++;return {status:500};},onAttempt:()=>attempts++,retryDelay:0});c.setBudget(a.signal,3);await Promise.allSettled(Array.from({length:5},()=>c.retry('/x',{},a.signal,3,500)));assert.equal(n,3);assert.equal(attempts,3);});
await test('cancellation interrupts shared cooldown',async()=>{const a=new AbortController(),c=R.createClient({fetch:async()=>({status:429}),cooldownMs:()=>5000,retryDelay:0});const p=c.retry('/x',{},a.signal,3,500);setTimeout(()=>a.abort(),15);await assert.rejects(p,e=>e.name==='AbortError');});
await test('import blocks cache namespace injection before any mutation',async()=>{await ST.resetAll();await ST.saveSettings({fee:.02});await assert.rejects(ST.importAll({app:'market-lens-lab',settings:{fee:.01},kidx:{},k:{settings:{fee:.09}}}),/缓存键/);assert.equal((await ST.settings()).fee,.02);assert.equal(await ST.exportBackup(),null);});
await test('invalid model normalization and invalid registry history rejected',async()=>{const m=clone(B.models.h14);m.features[0].sd=0;await assert.rejects(ST.importAll({app:'market-lens-lab',registry:{candidates:[m]}}),/模型/);await assert.rejects(ST.importAll({app:'market-lens-lab',registry:{candidates:[],history:[{}]}}),/历史/);});
await test('active model references must resolve',async()=>await assert.rejects(ST.importAll({app:'market-lens-lab',registry:{active:{h14:'missing'},candidates:[]}}),/不存在/));
await test('invalid fee, holdings price/quantity/date/URL are rejected atomically',async()=>{await assert.rejects(ST.importAll({app:'market-lens-lab',settings:{fee:5}}),/范围/);const h={hid:'h1',id:'1',name:'A',buyPrice:100,qty:1,status:'open',buyDay:'2026-09-01'};for(const patch of [{qty:-1},{buyPrice:NaN},{buyDay:'2026-02-30'},{url:'javascript:alert(1)'}])await assert.rejects(ST.importAll({app:'market-lens-lab',holdings:[{...h,...patch}]}));});
await test('prototype fields rejected',async()=>await assert.rejects(ST.importAll(JSON.parse('{"app":"market-lens-lab","settings":{"__proto__":{"polluted":true}}}')),/不允许/));
await test('corrupt cache encodings and mismatched arrays rejected',async()=>{const pack=ST.packSeries(series);pack.v='';await assert.rejects(ST.importAll({app:'market-lens-lab',kidx:{1:{}},k:{'k:1':{id:'1',lastDay:series.lastDay,pack}}}),/长度/);});
await test('valid import retains pre-import backup; old cross-sections invalidated',async()=>{await ST.resetAll();const h=await ST.addHolding({id:'1',name:'old',buyPrice:100});await ST.putXsec(30,{day:'2026-09-26'});await ST.importAll({app:'market-lens-lab',holdings:[]});assert.equal((await ST.holdings()).length,0);assert.equal((await ST.exportBackup()).holdings[0].hid,h.hid);assert.equal(await ST.getXsec(30),null);});
await test('export/import cache roundtrip derives index instead of trusting imported index',async()=>{await ST.resetAll();await ST.putK({id:'1',name:'A'},series);const out=await ST.exportAll({includeK:true});out.kidx['1'].n=9999;await ST.resetAll();await ST.importAll(out);assert.equal((await ST.kIndex())['1'].n,series.n);assert.equal((await ST.getK('1')).series.n,series.n);});
await test('501st holding is refused without dropping any open or sold record',async()=>{await ST.resetAll();for(let i=0;i<500;i++)await ST.addHolding({id:String(i),buyPrice:100});const before=await ST.holdings();await assert.rejects(ST.addHolding({id:'501',buyPrice:100}),/500/);assert.deepEqual(await ST.holdings(),before);});
await test('legacy migration preserves >500 records rather than truncating',async()=>{await ST.resetAll();await ST.set('lots',Array.from({length:501},(_,i)=>({key:String(i),id:String(i),price:10,quantity:1,at:'2026-09-01T00:00:00Z',targetDays:30,status:'open'})));assert.equal((await ST.holdings()).length,501);await ST.resetAll();});
await test('RPC codec preserves Map, typed arrays, null, NaN and undefined',()=>{const x=new Map([['a',{n:new Float64Array([1,NaN]),none:null,missing:undefined}]]);const y=RPC.decode(clone(RPC.encode(x)));assert(y instanceof Map);assert(y.get('a').n instanceof Float64Array);assert(Number.isNaN(y.get('a').n[1]));assert.equal(y.get('a').missing,undefined);});
const harness=serviceHarness(),a=harness.client(),b=harness.client();
await test('actual background handler serializes concurrent writes from 2 content instances',async()=>{await Promise.all([a.addHolding({id:'1',name:'A',buyPrice:10}),b.addHolding({id:'2',name:'B',buyPrice:20})]);assert.equal((await a.holdings()).length,2);assert.equal(harness.data.holdings.length,2);});
await test('concurrent cache writes retain both entries and decode typed arrays',async()=>{await Promise.all([a.putK({id:'1',name:'A'},series),b.putK({id:'2',name:'B'},series)]);assert.equal(Object.keys(await a.kIndex()).length,2);const result=await a.getKMany(['1','2']);assert.equal(result.size,2);assert.equal(result.get('1').series.c[0],100);assert.equal(result.get('1').series.c.constructor.name,'Float64Array');});
await test('worker restart retains acknowledged cache index and holdings',async()=>{harness.restart();assert.equal((await a.holdings()).length,2);assert.equal(Object.keys(await b.kIndex()).length,2);assert.equal((await a.getK('2')).series.n,200);});
await test('background rejects untrusted page and non-allowlisted operations',async()=>{await assert.rejects(harness.client('https://evil.example/').holdings(),/不允许/);const reply=await new Promise(resolve=>harness.listeners.at(-1)({type:'market-lens-store-v1',method:'set',args:RPC.encode(['registry',{}])},{id:'ext',url:'https://firepulse.com.cn/home'},resolve));assert.equal(reply.ok,false);});
await test('RPC storage failure is reported, never silently redirected to per-tab local writes',async()=>{const ctx=vm.createContext({document:{},console,setTimeout,clearTimeout,btoa,atob,chrome:{storage:{local:{set:()=>{throw Error('must not write directly');}}},runtime:{sendMessage:async()=>{throw Error('service offline');}}}});for(const f of ['store-rpc.js','store.js'])vm.runInContext(fs.readFileSync(path.join(DIR,f),'utf8'),ctx);await assert.rejects(ctx.MarketLensStore.addHolding({id:'3',buyPrice:10}),/service offline/);assert.equal(ctx.MarketLensStore.set,undefined);});
await test('large cache reads are split into bounded 50-item Chrome messages',async()=>{for(let i=3;i<=121;i++)await a.putK({id:String(i),name:'A'},series);harness.messages.length=0;const rows=await a.allK();assert.equal(rows.length,121);const calls=harness.messages.filter(m=>m.method==='getKMany');assert.equal(calls.length,3);assert(calls.every(m=>RPC.decode(m.args)[0].length<=50));assert(!harness.messages.some(m=>m.method==='allK'));});
await test('typed-array RPC uses bounded binary encoding and preserves subarray offsets',()=>{const base=new Float64Array([1,2,3,NaN]),x=base.subarray(1,4),encoded=RPC.encode(x);assert.equal(encoded[0],'b');assert.equal(typeof encoded[2],'string');const y=RPC.decode(encoded);assert.deepEqual(Array.from(y),[2,3,NaN]);assert.throws(()=>RPC.decode(['b','Float64Array',btoa('x')]),/长度/);});
console.log(`${count} fix regression tests passed`);
})().catch(e=>{console.error(e);process.exitCode=1;});
