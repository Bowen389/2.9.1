'use strict';
const assert=require('node:assert/strict');
const {boot,waitFor,txt,wait,windows}=require('./panel.cjs');
const WL=require('../whitelist');
let count=0;
async function test(name,fn){await fn();count++;console.log('PASS UI FIX',name);}
async function open(b){b.root.getElementById('open').click();await wait(30);}
(async()=>{try{
await test('stale item is excluded; incomplete scan does not publish reference; resume fetches only failed item',async()=>{
 const b=boot('https://firepulse.com.cn/home',{items:40});await open(b);const id=b.WL.ITEMS[0].id;b.mock.staleIds.add(id);
 b.root.getElementById('buyScan').click();await waitFor(b.root,()=>txt(b.root).includes('件待补扫'),'stale pause',8000);
 assert(txt(b.root).includes('扫描不完整'));assert.equal(await b.ST.getXsec(30),null);assert.equal((await b.ST.snapshots()).length,0);
 assert(!Array.from(b.root.querySelectorAll('[data-buy]')).some(x=>x.dataset.buy===id));
 assert(Array.from(b.root.querySelectorAll('[data-buy]')).every(x=>!x.disabled&&x.textContent.includes('自主买入记账')));
 const before=b.calls.k;b.mock.staleIds.clear();b.root.getElementById('buyScan').click();await waitFor(b.root,()=>txt(b.root).includes('扫描完成')&&!txt(b.root).includes('待补扫'),'resume',8000);
 assert.equal(b.calls.k,before+1);const x=await b.ST.getXsec(30);assert(x&&x.schema===2&&x.complete);assert.equal((await b.ST.snapshots()).length,3);b.w.close();
});
await test('network failure is retained for explicit retry instead of skipped by cursor',async()=>{
 const b=boot('https://firepulse.com.cn/home',{items:40});await open(b);const id=b.WL.ITEMS[1].id;b.mock.failIds.add(id);
 b.root.getElementById('buyScan').click();await waitFor(b.root,()=>txt(b.root).includes('件待补扫'),'network partial',8000);assert.equal(await b.ST.getXsec(30),null);
 const before=b.calls.k;b.mock.failIds.clear();b.root.getElementById('buyScan').click();await waitFor(b.root,()=>txt(b.root).includes('扫描完成')&&!txt(b.root).includes('待补扫'),'network resume',8000);assert.equal(b.calls.k,before+1);b.w.close();
});
await test('missing market produces observation-only UI and no formal reference',async()=>{
 const b=boot('https://firepulse.com.cn/home',{items:40});await open(b);b.mock.marketFail=true;b.root.getElementById('buyScan').click();
 await waitFor(b.root,()=>txt(b.root).includes('扫描完成'),'missing market',8000);assert(txt(b.root).includes('大盘数据不可用'));assert.equal(await b.ST.getXsec(30),null);assert(Array.from(b.root.querySelectorAll('[data-buy]')).every(x=>!x.disabled&&x.textContent.includes('自主买入记账')));b.w.close();
});
await test('weak market retains warning but permits independent manual bookkeeping',async()=>{
 const b=boot('https://firepulse.com.cn/home',{items:40});await open(b);b.mock.marketWeak=true;b.mock.askOf=()=>1;b.root.getElementById('buyScan').click();
 await waitFor(b.root,()=>txt(b.root).includes('悠悠在售价已读取'),'weak market',8000);assert(txt(b.root).includes('只作观察名单'));assert(!Array.from(b.root.querySelectorAll('.ask')).some(x=>x.textContent.includes('可买')));assert(Array.from(b.root.querySelectorAll('[data-buy]')).every(x=>!x.disabled&&x.textContent.includes('自主买入记账')));b.w.close();
});
await test('single-item rule check uses K close, not low live ask',async()=>{
 const it=WL.ITEMS[1],b=boot('https://firepulse.com.cn/cs2/'+it.id,{items:5,title:it.name});
 const day=new Date(Math.floor(Date.now()/86400000)*86400000-86400000).toISOString().slice(0,10);
 b.w.MarketLensBuiltin.models.h30.reference={day,n:40,sorted:Array(40).fill(-999),rulesKey:b.F.rulesKey(b.F.normRules(null))};
 b.mock.askOf=()=>1;await open(b);await waitFor(b.root,()=>txt(b.root).includes('买点结论'),'single item',8000);
 const s=(await b.ST.getK(it.id)).series;
 assert(b.F.ruleCheck(it.name,s.c[s.n-1],b.F.normRules(null)).ok);assert(!b.F.ruleCheck(it.name,1,b.F.normRules(null)).ok);
 assert(b.root.getElementById('verdict').textContent.includes('符合买点'));assert(b.root.getElementById('itemBuy'));b.w.close();
});
console.log(`${count} UI fix regression tests passed`);
}finally{for(const w of windows)w.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
