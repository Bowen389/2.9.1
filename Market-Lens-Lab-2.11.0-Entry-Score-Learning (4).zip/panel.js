/* Market Lens Lab 2.9 panel — 今日买点 / 单品 / 我的持仓 / 高级（扫盘明细 · 回测 · 学习 · 筛选规则）.
   2.9 = the 2.6.1 product (P80 选品分买点、买点结论卡、我的持仓记账、悠悠有品口径、
   默认 1% 成本、14/30 天持有周期) on the 2.8 speed pipeline. Only *how* the data
   is fetched changed:
     ① 扫描范围    fixed whitelist with embedded FirePulse ids → 0 list requests
                  (2.6.1: keyword paging + a youpin quote per item ≈ 1,000+ requests).
     ② 悠悠日K     cache-aware: fresh cache = no request; stale cache = short tail
                  fetch merged into the cache (≈1/15 of the data); first sight =
                  kDepth days. 2–4 parallel requests, jitter, 429 cool-down, brake.
     ③ 结论        selection scores are computed as data arrives; the 今日买点 list
                  refreshes live instead of after the whole scan.
     ④ 悠悠在售价  fetched only for the recommended picks after the scan (a few
                  dozen requests), so 2.6.1's "在售价 vs 买入价上限" check survives.
   Same-origin public requests only, credentials omitted, a local-only storage service,
   no automatic trading. Data and models stay in this browser (chrome.storage). */
(function () {
  'use strict';
  if (window.top !== window || globalThis.__ML_LAB__) return;
  globalThis.__ML_LAB__ = true;
  const L = globalThis.MarketLensItem, N = globalThis.MarketLensLab, S = globalThis.MarketLensScanner, WL = globalThis.MarketLensWhitelist;
  const F = globalThis.MarketLensFactor, B = globalThis.MarketLensBuiltin, ST = globalThis.MarketLensStore;
  const BY = globalThis.MarketLensBuy;
  const DAY = 86400000, HS = [7, 14, 30];
  const VERSION = '2.11.0';
  const MC=globalThis.MarketLensManual,VA=globalThis.MarketLensVolumeAudit,EC=globalThis.MarketLensEntryStudy;
  const manual={open:false,busy:false,draft:{},error:'',decision:''};let entryMessage='',entryStudyOpen=false;
  const ES=globalThis.MarketLensEntryScore, LC=globalThis.MarketLensLearning;
  let learningOpen=false,learningBusy=false,learningMessage='';
  const SV = globalThis.MarketLensSignalView;
  const EM = globalThis.MarketLensExperiment;
  const ADV_TABS = [['scan', '扫盘明细'], ['bt', '回测'], ['learn', '学习'], ['exp', '实验室']];
  const isAdv = t => t === 'scan' || t === 'bt' || t === 'learn' || t === 'exp';
  const KEYSETS = {
    LEAN: B.keys.slice(),
    CURATED: 'mom3,mom7,ma20dist,rsi14,pos180,upLow,ddHigh,mom30s7,mom90,volLvl,volRatio,beta,logPrice,liq,obvAgree,trendR2,alpha90'.split(','),
    FULL: 'mom7,mom30,mom90,mom30s7,ret30,volLvl,volRatio,relVol3,volTrend,liq,zeroVol,logPrice,pos180,ddHigh,upLow,ma20dist,ma5_20,ma20slope,ma60dist,rsi14,trendR2,maxRet,minRet,skew60,obvAgree,beta,betaAsym,idioVol,corrMkt,alpha7,alpha30,alpha90'.split(','),
  };
  const PANEL_KEYS = F.FEATURE_KEYS.filter(k => !k.startsWith('lab'));

  const host = document.createElement('div');
  host.id = 'market-lens-lab';
  document.documentElement.append(host);
  const root = host.attachShadow({ mode: 'open' });

  const css = `:host{all:initial;font:13px/1.6 system-ui,-apple-system,'Microsoft YaHei',sans-serif;color:#e7edf7}*{box-sizing:border-box}button,input,select,textarea{font:inherit}button{cursor:pointer;border:1px solid #34435b;border-radius:8px;padding:7px 11px;background:#223149;color:#eef5ff}button:hover{background:#304663}button:disabled{opacity:.45;cursor:not-allowed}button.primary{background:#2c5a4a;border-color:#3f7a63}button.danger{background:#4a2630;border-color:#7a3f4c}.launch{position:fixed;right:22px;bottom:24px;background:#a8f0d0;color:#122820;font-weight:700;box-shadow:0 8px 30px #0005;z-index:2147483000}.panel{position:fixed;right:18px;bottom:18px;width:900px;max-width:calc(100vw - 24px);max-height:90vh;background:#111b2b;border:1px solid #35445c;border-radius:16px;box-shadow:0 15px 65px #0008;overflow:auto;z-index:2147483000}header{padding:16px 20px 0;border-bottom:1px solid #2a384d;display:flex;justify-content:space-between;align-items:flex-start;gap:10px;position:sticky;top:0;background:#111b2b;z-index:3}h2{font-size:17px;margin:0}h3{font-size:14px;margin:16px 0 8px}.sub,small{color:#a7b6cb;font-size:11px}.body{padding:0 20px 20px}.note{background:#202f43;padding:10px 12px;border-radius:8px;font-size:12px;margin:12px 0}.warn{color:#ffcf8a}.bad{color:#ff9d9d}.good{color:#a8f0d0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}.grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:9px}.card{border:1px solid #2e4059;padding:10px 12px;border-radius:10px;margin:10px 0}.card.l1{border-color:#5a6f95}.card.l2{border-color:#70b99b}.card.l3{border-color:#b99b70}.big{font-size:30px;font-weight:650;color:#a8f0d0;line-height:1.3}.mid{font-size:20px;font-weight:650;line-height:1.3}.row{display:flex;gap:7px;flex-wrap:wrap;margin:10px 0;align-items:center}input,select,textarea{background:#17253a;color:#e7edf7;border:1px solid #40516c;border-radius:7px;padding:6px;min-width:0}textarea{width:100%;height:74px;font-size:11px;line-height:1.5}table{width:100%;border-collapse:collapse;font-size:11px}.entry-score b{font-size:22px}.signal-state{min-width:128px;max-width:155px;white-space:normal;text-align:left;font-weight:600}.signal-reason{min-width:220px;max-width:340px;white-space:normal;text-align:left;line-height:1.65}td,th{text-align:right;padding:5px 3px;border-bottom:1px solid #29384e;white-space:nowrap}td:first-child,th:first-child{text-align:left}details{margin:10px 0}summary{cursor:pointer;color:#bfd4ef}pre{white-space:pre-wrap;word-break:break-all;font-size:11px}a{color:#a8f0d0;text-decoration:none}a:hover{text-decoration:underline}.tabs{display:flex;gap:4px;margin:12px 0 0}.tab{border-radius:8px 8px 0 0;border-bottom:none;padding:6px 13px;background:#182639;color:#a7b6cb}.tab.on{background:#22344e;color:#eaf6ff;border-color:#4a6183}.scroll{max-height:330px;overflow:auto;border:1px solid #2e4059;border-radius:10px}.scroll table{margin:0}.scroll th{position:sticky;top:0;background:#16233a;z-index:1}.bar{height:7px;background:#1d2c42;border-radius:5px;overflow:hidden;margin:6px 0}.bar>i{display:block;height:100%;background:#a8f0d0;width:0}.pill{display:inline-block;padding:1px 7px;border-radius:20px;background:#22344e;border:1px solid #3b4f6d;font-size:10px;color:#cfe2ff}.hit{background:#20463a;border-color:#3f7a63;color:#b9f2da}.hsel button{padding:4px 10px}.hsel button.on{background:#2c5a4a;border-color:#3f7a63}.kv{display:flex;justify-content:space-between;gap:8px;font-size:12px;border-bottom:1px dashed #26364c;padding:3px 0}.plus{color:#a8f0d0}.minus{color:#ffb4a8}.legend i{display:inline-block;width:10px;height:3px;margin:0 4px 2px 8px;vertical-align:middle}label.ck{display:inline-flex;gap:4px;align-items:center;font-size:12px}
.tabs.sub2{margin:14px 0 4px}.tabs.sub2 .tab{border-radius:8px;border-bottom:1px solid #34435b;padding:4px 11px;font-size:12px}
.verdict{border-width:2px}.verdict .vt{font-size:19px;font-weight:700;line-height:1.35}
.verdict.yes{border-color:#3f9a78;background:#12291f}.verdict.yes .vt{color:#a8f0d0}
.verdict.wait{border-color:#b99b50;background:#2a2412}.verdict.wait .vt{color:#ffcf8a}
.verdict.watch{border-color:#5a6f95}.verdict.watch .vt{color:#cfe2ff}
.verdict.no,.verdict.na{border-color:#7a3f4c;background:#26151a}.verdict.no .vt,.verdict.na .vt{color:#ffb4a8}
tr.top td{background:#132a21}
td.why{white-space:normal;text-align:left;max-width:170px;color:#a7b6cb;font-size:10px;line-height:1.35}
td input{width:66px;padding:2px 4px;font-size:11px}
.bsel button{padding:4px 10px}.bsel button.on{background:#2c5a4a;border-color:#3f7a63}
.ask{font-size:11px;white-space:nowrap}.ask.ok{color:#8fe3b8}.ask.high{color:#ffb4a8}
.pill.src{background:#1c2a3d;color:#a7b6cb}
`;

  // ---- state ---------------------------------------------------------------
  let identity = null, opened = false, tab = 'buy', advTab = 'scan';
  // 今日买点 / 我的持仓
  const buy = { msg: '' };
  const hold = { list: [], prices: {}, priceDay: {}, busy: false, msg: '', loaded: false };
  // 悠悠在售价 (detail_price_compare) — only for the recommended picks and the
  // item page: id -> {ok, price, count, reason, at, day}. Never used for ranking.
  const quotes = new Map();
  const qs = { busy: false, done: 0, total: 0, at: null, msg: '', abort: null };
  let cfg = Object.assign({ useCache: true }, ST.DEFAULT_SETTINGS, { rules: F.normRules(ST.DEFAULT_SETTINGS.rules) });
  let rulesOpen = false, rulesMsg = '';
  let reg = { active: { h7: null, h14: null, h30: null }, candidates: [], history: [] };
  let mkt = null;               // {series,lastDay,fetchedAt}
  const xsec = {};              // h -> latest scan cross-section {day,n,sorted,modelId}
  let ready = false;
  // item
  let busy = false, epoch = 0, controller = null, fields = null, payload = null, series = null, report = null,
    legacy = null, historical = null, outcomes = null, batch = null, itemError = '', date = '', step = '7', working = false,
    fx = null, look = null, lookDate = '', itemFetch = '';
  // scan
  const scan = {
    phase: 'idle', generation: 0, universeRulesKey: null, universe: null, rows: [], rowIdx: new Map(), series: new Map(), plan: null, coverage: '',
    progress: { done: 0, total: 0, ok: 0, fail: 0, requests: 0, cached: 0, tail: 0, full: 0, netMs: 0, netN: 0 },
    resolved: null, queue: [], failed: new Set(), completed: new Set(), cursor: 0, pause: false, abort: null, error: '', note: '', autoPaused: '',
    sortKey: 'entryScore', sortDir: 'desc', startedAt: null, finishedAt: null, shown: 150, cross: null, liveAt: 0, liveTimer: null,
  };
  const net = globalThis.MarketLensReliability.createClient({
    fetch: (...args) => fetch(...args), cooldownMs: () => S.DEFAULTS.cooldownMs,
    onAttempt: () => { scan.progress.requests++; },
  });
  // backtest
  const bt = { phase: 'idle', msg: '', prog: 0, h: 14, model: 'active', gate: false, wf: false, lab: true, oosOnly: false, panel: null, panelKey: '', result: null, error: '', abort: null };
  // learn
  const lr = { phase: 'idle', msg: '', prog: 0, trainH: 'all', results: {}, error: '', paper: null, viewsOut: null, stats: null, info: '' };

  const exp = { h:30, busy:false, ctrl:null, message:'', error:'', state:null, result:null, outcomes:null };
  // ---- helpers -------------------------------------------------------------
  const esc = s => String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fin = v => typeof v === 'number' && Number.isFinite(v);
  const num = (v, d = 1) => (fin(v) ? v.toFixed(d) : '—');
  const pc = (v, d = 1) => (fin(v) ? (v * 100).toFixed(d) + '%' : '—');
  const spc = (v, d = 1) => (fin(v) ? (v >= 0 ? '+' : '') + (v * 100).toFixed(d) + '%' : '—');
  const sn = (v, d = 3) => (fin(v) ? (v >= 0 ? '+' : '') + v.toFixed(d) : '—');
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const todayNum = () => Math.floor(Date.now() / DAY);
  const ageDays = dayStr => (dayStr ? todayNum() - F.dayNumOf(dayStr) : Infinity);
  const ask = msg => (typeof window.confirm === 'function' ? window.confirm(msg) : true);
  const labels = { entry: '入场总分', reversal: '止跌转折', trend: '新版趋势', pullback: '回撤适配', breakout: '突破适配', liquidity: '流动性代理', oldStrength: '旧版强弱', oldEntry: '旧版入场', momentum30: '30日标准化动量' };

  const api = (path, body, signal, timeoutMs) => net.request(path, body, signal, timeoutMs || 15000);
  const apiRetry = (path, body, signal, tries) => net.retry(path, body, signal, tries || 3, 20000);
  const mins = m => (fin(m) ? (m < 1 ? '不到 1 分钟' : m < 60 ? '约 ' + m.toFixed(m < 10 ? 1 : 0) + ' 分钟' : '约 ' + (m / 60).toFixed(1) + ' 小时') : '—');
  // Bounded worker pool: N parallel workers, jitter between network requests
  // (none after a cache hit), shared 429 cool-down, auto-pause on a failure
  // streak, hard request budget per batch.
  async function pool(items, worker, opts) {
    const o = opts || {};
    const concurrency = Math.max(1, Math.min(6, o.concurrency || 2));
    if (o.signal && o.maxRequests) net.setBudget(o.signal, Math.max(0, o.maxRequests - (scan.progress.requests - (o.requestBase || 0))));
    let idx = 0, done = 0, ok = 0, fail = 0, streak = 0, stopped = '', budgetHit = false;
    const runners = [];
    for (let w = 0; w < concurrency; w++) runners.push((async () => {
      while (!stopped) {
        if (o.signal && o.signal.aborted) { stopped = 'aborted'; break; }
        if (o.shouldStop && o.shouldStop()) { stopped = 'paused'; break; }
        if (o.maxRequests && scan.progress.requests - (o.requestBase || 0) >= o.maxRequests) { stopped = 'budget'; budgetHit = true; break; }
        const i = idx++;
        if (i >= items.length) break;
        let res = null;
        try { res = await worker(items[i], i); ok++; streak = 0; }
        catch (e) {
          fail++; streak++;
          if (e.budget) { stopped = 'budget'; budgetHit = true; }
          if (e.name === 'AbortError') stopped = 'aborted';
          if (o.onError) o.onError(e, items[i]);
          if (streak >= (o.failStreak || 10)) { stopped = 'streak'; if (o.onStreak) o.onStreak(e, streak); }
        }
        done++;
        if (o.onTick) o.onTick({ done, total: items.length, ok, fail });
        if (res === 'cached') await sleep(0);
        else await sleep((o.delayMin ?? 150) + Math.random() * ((o.delayMax ?? 350) - (o.delayMin ?? 150)));
      }
    })());
    await Promise.all(runners);
    return { processed: done, ok, fail, stopped, budgetHit, nextIndex: idx };
  }
  function download(name, text, mime) {
    const url = URL.createObjectURL(new Blob([text], { type: mime || 'application/json' }));
    const a = document.createElement('a');
    a.href = url; a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
  }
  const kParams = (id, range) => ({ id, type: 2, timestamp: Math.floor(Date.now() / 1000), date_range: Math.max(30, Math.min(S.DEFAULTS.kDepthMax, Math.round(range || cfg.kDepth))), platform: 'youpin' });
  // Rebuild a lab-2.1 compatible payload from a cached series (real bars only).
  // lab-2.1 only reads the last 180 bars, so the scan passes maxRows=220 (same
  // result, ~5× less parsing per item); the item page keeps the full history
  // for the historical / batch tools.
  function payloadFromSeries(s, maxRows) {
    const data = [], from = maxRows ? Math.max(0, s.n - maxRows) : 0;
    for (let i = from; i < s.n; i++) if (s.real[i]) data.push([String((s.day0 + i) * 86400), s.o[i], s.c[i], s.l[i], s.h[i], s.v[i], s.v[i] * s.c[i]]);
    return { code: 200, data };
  }
  // Fetch (or reuse) the youpin daily K of one item, cache-aware. Returns
  // {series, mode: 'cache'|'tail'|'full', ms}. `cached` = store record or null.
  async function fetchK(id, meta, cached, name, family, price, signal) {
    const now = Date.now(), end = Math.floor(now / DAY) * DAY;
    const plan = cfg.useCache ? S.kPlan(meta, todayNum(), { kDepth: cfg.kDepth }) : { mode: 'full', range: cfg.kDepth };
    if (plan.mode === 'fresh' && cached && cached.series && cached.series.ok) return { series: cached.series, mode: 'cache', ms: 0 };
    const t0 = Date.now();
    let s = null, mode = plan.mode === 'tail' && cached && cached.series && cached.series.ok ? 'tail' : 'full';
    if (mode === 'tail') {
      const k = await apiRetry('/v1/market/facade/quote/skin_k_chart', kParams(id, plan.range), signal, S.DEFAULTS.tries);
      const recent = F.toSeries(k, { end });
      s = recent.ok ? F.mergeSeries(cached.series, recent) : recent;
      if (!s.ok || s.gap) mode = 'full';       // could not bridge the gap: fall back
    }
    if (mode === 'full') {
      const k = await apiRetry('/v1/market/facade/quote/skin_k_chart', kParams(id, cfg.kDepth), signal, S.DEFAULTS.tries);
      s = F.toSeries(k, { end });
    }
    const ms = Date.now() - t0;
    // A storage failure (e.g. quota) must not count as a request failure.
    if (s.ok) { try { await ST.putK({ id, name, family, price: price || null }, s); } catch (e) { scan.note = '本地缓存写入失败（' + e.message + '），扫描继续但不会保存日K。'; } }
    return { series: s, mode, ms };
  }


  // ---- models --------------------------------------------------------------
  const modelH = m => (m && (m.h || m.horizon)) || null;
  function modelOf(h) {
    const id = reg.active['h' + h];
    const m = id && reg.candidates.find(c => c.id === id);
    return m || B.models['h' + h];
  }
  const isBuiltin = m => !m || m.source === 'builtin';
  const modelName = m => (isBuiltin(m) ? '内置 ' + m.id : m.id);
  function refFor(h, model) {
    const x = xsec[h];
    if (x && x.schema === 2 && x.complete && x.modelId === model.id && x.n >= 30 && BY.fresh(x.day, BY.bjDay(), 3) && (x.rulesKey || 'off') === rkey()) return { sorted: x.sorted, day: x.day, n: x.n, src: 'scan' };
    const r = model.reference;
    if (!r) return null;
    const sorted = r.sorted || r.scores;
    const refKey = r.rulesKey || (model.train && model.train.rulesKey) || (isBuiltin(model) ? B.rulesKey : null);
    return { sorted, day: r.day, n: sorted.length, src: isBuiltin(model) ? 'builtin' : 'trained', mismatch: !!refKey && refKey !== rkey() };
  }
  function calibFor(model, h, bucket) {
    if (!bucket) return null;
    if (isBuiltin(model)) {
      const q = model.oos && model.oos.quintiles[bucket - 1];
      return q && { excess: q.avgExcess, med: q.medExcess, beat: q.beatRate, n: q.n, src: '滚动训练样本外 ' + model.oos.firstDay + '→' + model.oos.lastDay + (model.oos.universe === 'rules' ? '，默认筛选规则范围内' : '') };
    }
    const c = model.calib && model.calib['h' + h], q = c && c[bucket - 1];
    return q && { excess: q.avgExcess, med: q.medExcess, beat: q.beatRate, n: q.n, src: '留出测试期 ' + (model.train ? model.train.testFirst + '→' + model.train.testLast : '') };
  }
  const tradableF = f => f && f.liq >= Math.log1p(cfg.minLiq) && f.zeroVol <= cfg.maxZeroVol;
  function regimeLine(g) {
    if (!g) return { cls: 'warn', text: '大盘指数数据不足或未能读取，本层暂不可用。' };
    const ev = B.models.h14.oos;
    if (g.score < cfg.gate) return { cls: 'bad', text: '显著弱势（' + g.score.toFixed(0) + ' < ' + cfg.gate + '）。旧口径历史研究（未按2.10账务重算）中，暂停新开仓可把 14 日 Top10 组合最大回撤从 ' + pc(ev.top10.maxDD, 0) + ' 降到 ' + pc(ev.top10Gate30.maxDD, 0) + '。建议暂缓或减小仓位。' };
    if (g.score < 45) return { cls: 'warn', text: '偏弱。指数自身有一定趋势延续性（样本外 IC≈' + num(B.regimeEvidence.icIndex.h14, 2) + '），偏弱时更要控制仓位。' };
    return { cls: 'good', text: g.label + '。未触发大盘风险闸门。' };
  }

  // ---- filter rules ------------------------------------------------------------
  // One rule set (settings.rules) drives scan universe, backtest/learning panels,
  // the percentile reference and the single-item warning.
  const rulesOn = () => !!(cfg.rules && cfg.rules.enabled);
  const rkey = () => F.rulesKey(cfg.rules);
  function reasonsText(obj) { return Object.entries(obj || {}).filter(e => e[1]).map(([k, n]) => (F.RULE_REASONS[k] || k) + ' ' + n).join('、') || '无'; }
  // Whitelist filtered by the current name rules (price is checked later on the youpin close).
  function whitelistView() {
    let kept = 0; const why = {};
    for (const w of WL.ITEMS) { const c = rulesOn() ? F.ruleReasonName(w.name, cfg.rules) : null; if (c) why[c] = (why[c] || 0) + 1; else kept++; }
    return { kept, why, total: WL.ITEMS.length };
  }
  function rulesBlock() {
    const r = F.normRules(cfg.rules);
    const ck = (id, on, label) => `<label class="ck"><input type="checkbox" id="${id}" ${on ? 'checked' : ''}>${label}</label>`;
    return `<details class="card" id="rulesBox" ${rulesOpen ? 'open' : ''}><summary><b>筛选规则</b> <small id="rulesNow">${esc(F.rulesText(r))}</small></summary>` +
      `<div class="row">${ck('ruOn', r.enabled, '启用筛选（扫盘、回测、学习、单品提示共用）')}</div>` +
      `<div class="row"><small>枪皮磨损只要</small>${F.WEARS.map((w, i) => ck('ruW' + i, r.gunWears.indexOf(w) >= 0, w)).join('')}</div>` +
      `<div class="row">${ck('ruKnife', r.excludeKnife, '去掉刀具')}${ck('ruSt', r.excludeStatTrak, '去掉 StatTrak™')}${ck('ruSouv', r.excludeSouvenir, '去掉纪念品枪皮')}</div>` +
      `<div class="row"><small>价格 ¥</small><input id="ruMin" type="number" min="0" step="1" value="${r.priceMin}" style="width:84px"><small>–</small><input id="ruMax" type="number" min="0" step="1" value="${r.priceMax === null ? '' : r.priceMax}" placeholder="不限" style="width:92px"><small>名称排除词</small><input id="ruWords" value="${esc(r.excludeWords.join('，'))}" placeholder="可选，如：印花，武器箱" style="width:150px"></div>` +
      `<div class="row"><button id="ruSave" class="primary">保存规则</button><button id="ruReset">恢复默认</button>${rulesMsg ? `<small class="good" id="rulesMsg">${esc(rulesMsg)}</small>` : ''}</div>` +
      `<small>手套、涂鸦、印花、武器箱等非枪皮商品只按价格和排除词筛。扫盘按最新价判断；回测和学习按<b>每个采样日当天的价格</b>判断，不用今天的价格去筛历史（避免未来数据）。内置模型就是在默认规则的范围内训练和验证的。</small></details>`;
  }
  const rulesLine = () => `<div class="row" style="margin:6px 0"><small>筛选规则：${esc(F.rulesText(cfg.rules))}</small><button id="goRules" style="padding:2px 9px">修改</button></div>`;
  async function saveRules(reset) {
    const v = id => root.getElementById(id);
    const on = id => !!(v(id) && v(id).checked);
    const r = reset ? F.normRules(F.DEFAULT_RULES) : F.normRules({
      enabled: on('ruOn'), gunWears: F.WEARS.filter((w, i) => on('ruW' + i)),
      excludeKnife: on('ruKnife'), excludeStatTrak: on('ruSt'), excludeSouvenir: on('ruSouv'),
      priceMin: v('ruMin') ? v('ruMin').value : 0, priceMax: v('ruMax') && v('ruMax').value !== '' ? v('ruMax').value : null,
      excludeWords: v('ruWords') ? v('ruWords').value : '',
    });
    try { cfg = Object.assign(cfg, await ST.saveSettings({ rules: r })); } catch (e) { /* storage unavailable: keep in memory */ }
    cfg.rules = F.normRules(r);
    bt.panel = null; bt.panelKey = '';
    if (series) fx = computeFactor();
    if (scan.rows.length) applyCross();
    rulesOpen = true;
    rulesMsg = (reset ? '已恢复默认：' : '已保存：') + F.rulesText(cfg.rules) + (scan.universe ? '。已扫描的结果已按新规则重新排名；要按新规则增减商品，请重新载入样本池或抓取清单。' : '');
    render();
  }

  // ---- market index ----------------------------------------------------------
  async function ensureMarket(signal) {
    const fresh = m => m && m.fetchedAt && (Date.now() - Date.parse(m.fetchedAt) < 6 * 3600000) && ageDays(m.lastDay) <= 2;
    if (fresh(mkt)) return mkt;
    const cached = await ST.getMarket();
    if (fresh(cached)) { mkt = cached; return mkt; }
    try {
      const j = await apiRetry('/v1/market/facade/category/k/data', { category_id: 11, date_type: 2, date_range: 1440, date_time: Math.floor(Date.now() / 1000), platform: 'all' }, signal, 3);
      const s = F.toSeries(j, { cols: 'market' });
      if (!s.ok) throw Error('大盘指数：' + s.reason);
      await ST.putMarket(s);
      mkt = { series: s, lastDay: s.lastDay, fetchedAt: new Date().toISOString() };
    } catch (e) { if (cached) mkt = cached; else if (!mkt) throw e; }
    return mkt;
  }

  // ---- charts ----------------------------------------------------------------
  function curveSvg(curve, labelsOf) {
    if (!curve || curve.length < 2) return '';
    const W = 510, H = 170, P = 30;
    const keys = ['top', 'uni', 'mkt'], colors = { top: '#a8f0d0', uni: '#8fb3ff', mkt: '#ffcf8a' };
    let lo = Infinity, hi = -Infinity;
    for (const p of curve) for (const k of keys) if (fin(p[k]) && p[k] > 0) { lo = Math.min(lo, Math.log(p[k])); hi = Math.max(hi, Math.log(p[k])); }
    lo = Math.min(lo, 0); hi = Math.max(hi, 0); if (hi - lo < 0.05) { hi += 0.03; lo -= 0.03; }
    const x = i => P + (W - P - 6) * i / (curve.length - 1), y = v => 6 + (H - 22) * (1 - (Math.log(v) - lo) / (hi - lo));
    const path = k => { let pen=false;return curve.map((p,i)=>{if(!fin(p[k])||p[k]<=0){pen=false;return '';}const command=(pen?'L':'M')+x(i).toFixed(1)+' '+y(p[k]).toFixed(1);pen=true;return command;}).join(' '); };
    const ticks = [Math.exp(lo), 1, Math.exp(hi)].map(v => `<text x="2" y="${(y(v) + 3).toFixed(1)}" fill="#8a9ab3" font-size="9">${spc(v - 1, 0)}</text><line x1="${P}" x2="${W - 6}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}" stroke="#26364c" stroke-dasharray="3 3"/>`).join('');
    return `<svg viewBox="0 0 ${W} ${H}" width="100%" style="background:#0f1826;border-radius:8px;margin-top:6px">${ticks}` +
      keys.map(k => `<path d="${path(k)}" fill="none" stroke="${colors[k]}" stroke-width="${k === 'top' ? 2 : 1.3}"/>`).join('') +
      `<text x="${P}" y="${H - 3}" fill="#8a9ab3" font-size="9">${esc(curve[0].d)}</text><text x="${W - 70}" y="${H - 3}" fill="#8a9ab3" font-size="9">${esc(curve[curve.length - 1].d)}</text></svg>` +
      `<div class="sub legend"><i style="background:#a8f0d0"></i>${esc(labelsOf.top)}<i style="background:#8fb3ff"></i>${esc(labelsOf.uni)}<i style="background:#ffcf8a"></i>${esc(labelsOf.mkt)} · 对数纵轴</div>`;
  }

  // ---- item view -----------------------------------------------------------
  function hSelector(id) {
    return `<span class="hsel">${HS.map(h => `<button data-h="${h}" class="${cfg.h === h ? 'on' : ''}" id="${id}${h}">${h}日</button>`).join('')}</span>`;
  }
  function factorCards() {
    if (!fx) return '';
    const r = fx.byH[cfg.h];
    const g = fx.regime, rl = regimeLine(g);
    let html = `<div class="card l1"><small>① 大盘环境 · FirePulse 饰品指数（多平台合成，只看大盘方向，不作价格用）</small><div class="row" style="margin:4px 0"><span class="mid ${rl.cls}">${g ? num(g.score, 0) + ' · ' + esc(g.label) : '—'}</span>` +
      (g ? `<small>z7 ${num(g.z7, 2)} · z30 ${num(g.z30, 2)} · z90 ${num(g.z90, 2)} · 距180日高点 ${spc(g.drawdown180)}</small>` : '') + `</div><div class="sub ${rl.cls}">${esc(rl.text)}</div></div>`;
    if (!r || !r.ok) return html + `<div class="note warn">选品分不可用：${esc(r ? r.reason : '无数据')}</div>`;
    const ref = r.ref, stale = ref && ref.src !== 'scan' ? ageDays(ref.day) : 0;
    const rc = fields ? F.ruleCheck(fields.title, fields.price, cfg.rules) : { ok: true };
    html += `<div class="card l2"><small>② 选品分 · ${cfg.h}日 · 与同期其他饰品比较（横截面）</small>` +
      `<div class="row" style="margin:2px 0"><span class="big">${fin(r.pct) ? 'P' + num(r.pct, 0) : '—'}</span><span class="pill ${r.bucket >= 4 ? 'hit' : ''}">${r.bucket ? esc(F.QUINTILE_NAMES[r.bucket - 1]) : ''}</span><small>原始分 ${sn(r.sc.score, 3)} · 覆盖 ${pc(r.sc.coverage, 0)}</small></div>` +
      `<div class="sub">P = 在参考截面中的百分位（越高越靠前）。参考：${ref ? (ref.src === 'scan' ? '最近一次扫盘 ' + esc(ref.day) + ' · ' + ref.n + ' 件' : (ref.src === 'builtin' ? '内置截面 ' : '训练截面 ') + esc(ref.day) + ' · ' + ref.n + ' 件') : '无'}` +
      (stale > 3 ? ` <span class="warn">（已过 ${stale} 天，大盘整体涨跌会让百分位偏移；建议先到“今日买点”扫一次白名单刷新截面）</span>` : '') +
      (ref && ref.mismatch ? ` <span class="warn">（参考截面按模型训练时的筛选规则计算，与你当前的规则不同；按当前规则扫一次盘即可对齐）</span>` : '') + `</div>` +
      (!rc.ok ? `<div class="note warn" style="margin:8px 0">不在你的筛选范围（${esc(rc.text)}${rc.code === 'cheap' || rc.code === 'expensive' ? ' · 当前 ¥' + num(fields.price, 2) : ''}）。选品分是拿它和范围内的商品比较得出的，模型没有在这类商品上验证过，仅供参考。</div>` : '') +
      (r.calib ? `<div class="note" style="margin:8px 0">历史同档（${esc(r.calib.src)}）：${cfg.h}日这一档<b>跑赢样本池平均的期数占 ${pc(r.calib.beat, 0)}</b>；相对样本池的平均超额 ${spc(r.calib.excess)}${fin(r.calib.med) ? '，中位数口径超额 ' + spc(r.calib.med) : ''}。<br><small>这是整档的统计，单件波动极大，很多个体仍会跑输；“跑赢的次数多”不等于“赚得多”——少数暴涨商品会把样本池平均拉高。分数不是概率，也不是目标价。</small></div>` : '') +
      (!r.tradable ? `<div class="sub warn">该商品成交偏少（30日中位量或零成交比例未达可交易标准），不在模型训练范围内，分数仅供参考。</div>` : '') +
      `<div style="margin-top:6px">${r.why.map(w => `<div class="kv"><span class="${w.contrib > 0 ? 'plus' : 'minus'}">${w.sign} ${esc(w.text)}</span><small>${esc(w.label)} · z ${num(w.z, 2)} · 贡献 ${sn(w.contrib, 3)}</small></div>`).join('')}</div></div>`;
    const own = fx.own, p180 = r.sc.f.pos180;
    const posTxt = !fin(p180) ? '—' : p180 <= 0.3 ? '低位' : p180 >= 0.7 ? '高位' : '中位';
    html += `<div class="card l3"><small>③ 买点 · 单品择时（与自己的历史比较）</small><div class="grid" style="margin-top:4px">` +
      `<div><small>180日区间位置</small><div class="mid">${pc(p180, 0)} <small>${posTxt}</small></div></div>` +
      `<div><small>选品分在自身近一年的分位</small><div class="mid">${own && own.ok ? 'P' + num(own.pct, 0) : '—'} <small>${own && own.ok ? 'n=' + own.n : esc(own ? own.reason : '')}</small></div></div></div>` +
      `<div class="sub" style="margin-top:6px">研究结论：同一件饰品在180日区间低位、刚回调时买，之后7–14日的超额收益略好，但证据弱（全市场择时 IC≈0.07；在默认筛选规则范围内只有约 0.02–0.04），远弱于选品层；“等待止跌确认/突破”的旧思路在数据里是负效果。建议只在已选中的商品里用它挑时机、分批进场。</div></div>`;
    return html;
  }
  function cards(r) {
    if (!r || !r.ok) return `<div class="note warn">${esc(r && r.reason || '等待数据')}</div>`;
    return `<div class="card"><small>旧入场总分 · ${esc(r.branchName)}</small><div class="big">${num(r.entry, 0)}<small> /100</small></div></div>` +
      `<div class="note">${esc(r.status)} · 数据截至 ${esc(r.asOf)} UTC</div>` +
      `<div class="grid">${['reversal', 'pullback', 'breakout', 'trend'].map(k => `<div class="card" style="margin:0"><small>${esc(labels[k])}</small><div class="mid">${num(r[k], 0)}<small> /100</small></div></div>`).join('')}</div>` +
      `<h3>形态依据</h3>${r.reasons.map(x => `<div class="sub">＋ ${esc(x)}</div>`).join('') || '<div class="sub">无</div>'}` +
      `<h3>风险 / 待确认</h3>${r.risks.concat(r.conditions || []).map(x => `<div class="sub warn">• ${esc(x)}</div>`).join('') || '<div class="sub">未触发额外规则警告。</div>'}` +
      `<p class="sub">失效观察参考 ¥${num(r.invalidation.price, 2)}：${esc(r.invalidation.note)}</p>`;
  }
  function lookView() {
    if (!look) return '';
    if (!look.ok) return `<div class="note warn">${esc(look.reason)}</div>`;
    return `<table><tr><th>${esc(look.day)}</th><th>选品分</th><th>近似百分位</th><th>自身分位</th></tr><tr><td>${cfg.h}日模型</td><td>${sn(look.score, 3)}</td><td>${fin(look.pct) ? 'P' + num(look.pct, 0) : '—'}</td><td>${fin(look.own) ? 'P' + num(look.own, 0) : '—'}</td></tr></table>` +
      `<table><tr><th>之后</th><th>报价变化（次日入场）</th><th>同期指数</th></tr>${HS.map(h => `<tr><td>${h}日</td><td>${spc(look.ret[h])}</td><td>${spc(look.mret[h])}</td></tr>`).join('')}</table>` +
      `<small>近似百分位用的是当前参考截面；只看单个日期不能证明模型有效，请用“回测”页做多商品检验。</small>`;
  }
  function itemView() {
    const m = modelOf(cfg.h);
    const wlOk = fields ? WL.allowed({ id: identity.id, name: fields.title }) : true;
    return `<h3>${esc(fields ? fields.title : '商品 ' + identity.id)}</h3>` +
      `<div class="sub">${fields ? '悠悠在售报价 ¥' + num(fields.price, 2) : '公开接口 · 不读取登录凭据'} · 模型 ${esc(modelName(m))}${isBuiltin(m) ? '' : ' <span class="pill hit">已学习</span>'}${itemFetch ? ' · 日K' + esc(itemFetch) : ''}</div>` +
      `<div class="row"><button id="itemManual">自主买入记账</button><button id="refresh" ${busy ? 'disabled' : ''}>${busy ? '读取中…' : '刷新数据'}</button><button id="export" ${!payload ? 'disabled' : ''}>导出 JSON</button><small>持有周期</small>${hSelector('ih')}</div>` +
      (itemError ? `<div class="note bad">${esc(itemError)}</div>` : '') +
      (fields && !wlOk ? `<div class="note warn">该商品不在白名单（全部.csv）内，不会出现在“今日买点”里；下面的结论仅供参考。</div>` : '') +
      (fx ? itemVerdict() + factorCards() : (busy ? '<p class="sub">读取中…</p>' : '<p class="sub">打开后读取当前商品，不在后台定时采集。</p>')) +
      (series && series.ok ? volumeView(VA.audit(series,todayNum()-1)) : '') +
      (series && series.ok ? `<p class="sub">日K ${esc(series.firstDay)} → ${esc(series.lastDay)}${itemFetch ? ' · ' + esc(itemFetch) : ''} · 大盘 ${mkt ? esc(mkt.lastDay) : '未读取'} · 已写入本地样本库（用于回测/学习）</p>` : '') +
      `<details><summary>历史日期回看（新模型）</summary><div class="row"><input id="lookDate" type="date" value="${esc(lookDate)}"><button id="lookBtn" ${!series ? 'disabled' : ''}>计算</button></div>${lookView()}</details>` +
      `<details><summary>旧版 lab-2.1 形态分（研究显示与之后的超额收益负相关，仅作形态描述）</summary>` +
      `<div class="note warn">在 466 件饰品、2023-10→2026-09 的检验中，lab-2.1 入场/趋势/回撤/突破分的横截面 IC 均为负（约 −0.05 到 −0.09），单品择时 IC 也为负。保留它只为对照与形态描述，不建议据此买入。</div>` +
      (report ? cards(report) : '') +
      (legacy ? `<div class="note">更旧版（1.3）对照：强弱 ${num(legacy.score.total, 0)} / 入场 ${num(legacy.entry.total, 0)}</div>` : '') +
      `<h3>lab-2.1 历史日期验证</h3><div class="row"><input id="date" type="date" value="${esc(date)}"><button id="history" ${!payload ? 'disabled' : ''}>计算</button></div>` +
      (historical ? (historical.ok ? `<small>${esc(historical.timing)} · 报价 ¥${num(historical.current.price, 2)}</small>${cards(historical.current)}<div class="row"><button id="outcomes">查看后续表现</button></div>` : `<div class="note warn">${esc(historical.reason)}</div>`) : '') +
      (outcomes ? `<table><tr><th>期限</th><th>报价变化</th><th>最大收盘回撤</th></tr>${outcomes.periods.map(p => `<tr><td>${p.days}日</td><td>${num(p.changePct)}%</td><td>${num(p.maxDrawdownPct)}%</td></tr>`).join('')}</table>` : '') +
      `<h3>lab-2.1 单品批量验证</h3><div class="row"><select id="step"><option value="7" ${step === '7' ? 'selected' : ''}>每7日采样</option><option value="30" ${step === '30' ? 'selected' : ''}>每30日采样</option><option value="1" ${step === '1' ? 'selected' : ''}>每日采样</option></select><button id="batch" ${!payload || working ? 'disabled' : ''}>${working ? '计算中…' : '比较新旧规则'}</button></div>` +
      (batch ? `<p class="sub">共同样本 ${batch.n} · IC为秩相关，非准确率</p><table><tr><th>规则</th><th>IC 7日</th><th>14日</th><th>30日</th></tr>${batch.stats.map(s => `<tr><td>${esc(labels[s.key] || s.key)}</td><td>${num(s.ic7, 3)}</td><td>${num(s.ic14, 3)}</td><td>${num(s.ic30, 3)}</td></tr>`).join('')}</table><p class="sub">${esc(batch.note)}</p>` : '') +
      `</details>` +
      `<div class="note warn">仅供研究观察，不自动买卖，非投资建议。选品分只比较“相对强弱”，不预测涨跌；大盘整体下跌时，排名靠前的商品也可能亏钱。默认按 ${pc(cfg.fee, 1)} 往返成本（卖家手续费+价差/提现）评估，请按自己实际费率在“学习→设置”里修改。</div>`;
  }

  // ---- 今日买点 / 单品结论 / 我的持仓 (2.6) --------------------------------------
  const dStr = d => new Date(d * DAY).toISOString().slice(0, 10);
  const isHeld = id => hold.list.some(h => h.id === String(id) && h.status !== 'sold');
  function liveRegime(day) {
    const m = mkt && mkt.series, d = F.dayNumOf(day), i = m ? d - m.day0 : -1;
    if (!m || !m.ok || !BY.fresh(day, BY.bjDay()) || i < 0 || i >= m.n || !m.real[i]) return null;
    return F.marketRegime(m, d);
  }
  function regimeAt(day) {
    if (!mkt || !mkt.series || !mkt.series.ok) return null;
    const m = mkt.series, last = m.day0 + m.n - 1;
    return F.marketRegime(m, day ? Math.min(F.dayNumOf(day), last) : last);
  }
  function regimeCard(g) {
    if (!g) return `<div class="card l1"><b>① 大盘</b> <small>扫描时会读取大盘指数（FirePulse 综合指数，1 次请求，6 小时内复用）。</small></div>`;
    const rl = regimeLine(g);
    const verdictText = g.score < cfg.gate ? '今天不建议开新仓' : g.score < 45 ? '可以买，但控制仓位' : '可以正常开仓';
    return `<div class="card l1"><div class="row" style="margin:0;justify-content:space-between"><b>① 大盘 ${num(g.score, 0)} 分 · ${esc(g.label)}</b><b class="${rl.cls}">${verdictText}</b></div><small class="${rl.cls}">${esc(rl.text)}</small></div>`;
  }
  function bhSelector() {
    return `<span class="bsel">${[14, 30].map(h => `<button data-bh="${h}" id="bh${h}" class="${cfg.h === h ? 'on' : ''}">${h} 天</button>`).join('')}</span>`;
  }
  function buyView() {
    const running = scanBusy();
    const g = liveRegime(scan.cross ? scan.cross.day : F.dayStr(todayNum() - 1));
    const canResume = scan.phase === 'paused' && scan.universe && scan.cursor < scan.queue.length;
    const wv = whitelistView();
    const firstMin = S.estimate({ full: wv.kept }, { concurrency: cfg.concurrency, kDepth: cfg.kDepth }).minutes, dailyMin = S.estimate({ tail: wv.kept }, { concurrency: cfg.concurrency }).minutes;
    let html = `<h3>今日买点</h3><div class="row"><button id="buyManual">自主买入记账</button><small>不受大盘闸门限制，不会下单。</small></div><details><summary>触发状态与深度扫描说明（不改原排名）</summary><div class="note">触发状态为 2.10.1 新增展示规则：原模型 P80 候选 + 扫描/大盘/时效通过 + 有效在售价≤原上限，再核对相对量≥1及旧规则基础条件。量为全平台代理，不是悠悠独立成交量；不代表所有形态待确认项已满足。原排名与记账入口保持不变。<br>深度扫描会进入完整明细，读取或复用日K、重算旧规则与理由；“开始扫描”本来也包含这些计算，并非额外预测模型。默认遵守缓存，不强制拉满历史。</div></details>` +
      `<div class="note">用法：① 点“开始扫描” → ② 看入场评分、状态和理由，判断是否参与（分散并不消除风险）→ ③ 点“记为已买入”存进“我的持仓” → ④ 持有约 ${cfg.h} 天后卖出。所有价格均为悠悠有品口径。<br>` +
      `扫描范围固定为白名单 ${wv.total} 件（按筛选规则 ${wv.kept} 件），只读悠悠日K：首次${mins(firstMin)}，之后每天只补最近几十天，${mins(dailyMin)}；当天再扫不发请求。</div>` +
      regimeCard(g) +
      `<div class="row"><small>持有周期</small>${bhSelector()}` +
      `<button id="buyScan" class="primary" ${running ? 'disabled' : ''}>${running ? '扫描中…' : canResume ? '继续扫描' : scan.cross ? '重新扫描' : '开始扫描'}</button>` +
      `<button id="deepReview" ${running || exp.busy ? 'disabled' : ''}>深度扫描 / 查看依据</button><button id="scanPause" ${scan.phase !== 'deep' ? 'disabled' : ''}>暂停</button><button id="scanStop" ${!running && scan.phase !== 'paused' ? 'disabled' : ''}>停止</button>` +
      `<label class="ck"><input type="checkbox" id="useCache" ${cfg.useCache ? 'checked' : ''} ${running ? 'disabled' : ''}>今日已缓存的日K不重复请求</label></div>` +
      rulesLine() +
      (scan.phase !== 'idle' || scan.error ? progressHtml() : '') +
      (buy.msg ? `<div class="note good" id="buyMsg">${esc(buy.msg)}</div>` : '') +
      `<div id="liveResults">${liveBuyHtml()}</div>` +
      `<div class="row"><button id="buyGoAdv" style="padding:3px 10px">查看完整扫描明细（高级）</button></div>` +
      `<div class="note warn">仅供研究参考，不自动买卖，非投资建议。模型比较的是“同类里谁更强”，不预测涨跌；大盘整体下跌时买点也会亏钱。按 ${pc(cfg.fee, 1)} 往返成本评估。</div>`;
    return html;
  }
  // Current recommendation from the scan rows (BY.recommend = 2.6.1 rules: P80 picks, freshness, regime gate).
  const scanComplete = () => scan.queue.length > 0 && scan.completed.size === scan.queue.length && scan.universeRulesKey === rkey() && !(scan.resolved && scan.resolved.requiredMissing);
  function currentRec() {
    const cr = scan.cross;
    if (!cr) return null;
    const g = liveRegime(cr.day);
    return BY.recommend(scan.rows, { h: cfg.h, signalDay: cr.day, today: BY.bjDay(), regime: g, gate: cfg.gate, topN: cfg.topN, complete: scanComplete() && (scan.phase === 'done' || scan.phase === 'quote') });
  }
  function askCell(p, blocked) {
    const q = quotes.get(String(p.id));
    if (!q) return qs.busy ? '<small>读取中…</small>' : '<small>—</small>';
    if (!q.at || Date.now() - Date.parse(q.at) > S.DEFAULTS.quoteTtlMs || !Number.isFinite(Date.parse(q.at))) return '<small>报价已过期，请刷新</small>';
    if (!q.ok) return `<small title="${esc(q.reason)}">${esc(q.reason || '无在售')}</small>`;
    const high = fin(p.limit) && q.price > p.limit;
    return `<span data-limit="${esc(p.limit)}" class="ask ${high ? 'high' : 'ok'}" title="悠悠在售 ${q.count !== null ? q.count + ' 件 · ' : ''}${esc(q.at ? q.at.slice(11, 16) : '')} 读取">¥${num(q.price, 2)} ${high ? '高于上限' : blocked ? '仅价格匹配' : '价格匹配'}</span>`;
  }
  function quoteLine(rec) {
    const ids = rec.picks.map(p => String(p.id)), have = ids.filter(id => quotes.has(id)).length;
    const when = qs.at ? '（' + qs.at.slice(11, 16) + ' 读取）' : '';
    const text = qs.busy ? '正在读取买点商品的悠悠在售价 ' + qs.done + ' / ' + qs.total + '…'
      : have ? '悠悠在售价已读取 ' + have + ' / ' + ids.length + ' 件' + when + '，用来和“买入价上限”比较；下单前请以商品页实时价格为准。'
      : scanBusy() ? '扫描结束后会自动读取买点商品的悠悠在售价（每件 1 次请求，最多 ' + S.DEFAULTS.maxQuotes + ' 件）。' : '尚未读取悠悠在售价。';
    return `<div class="row" style="margin:4px 0"><small>${esc(text)}</small><button id="quoteRefresh" style="padding:2px 8px" ${qs.busy || scanBusy() || !ids.length ? 'disabled' : ''}>${have ? '刷新在售价' : '读取在售价'}</button>${qs.msg ? `<small class="warn">${esc(qs.msg)}</small>` : ''}</div>`;
  }
  function signalFor(row, rec, pick) {
    const blocks=[];
    if (!rec) blocks.push('尚无可用截面');
    else {if(rec.stale)blocks.push('信号已过期');if(rec.unknown)blocks.push('大盘数据不可用');if(rec.gateOn)blocks.push('大盘风险闸门');if(rec.tooFew)blocks.push('排名样本不足30件');}
    if (!scanComplete() || scanBusy()) blocks.push('扫描尚未完整结束 / 规则或覆盖未确认');
    return SV.evaluate(row,{contextReady:!!rec&&!rec.blocked&&scanComplete()&&!scanBusy(),blockReason:blocks.join('；'),candidate:!!pick,quote:row?quotes.get(String(row.id)):null,limit:pick?pick.limit:null,quoteTtlMs:S.DEFAULTS.quoteTtlMs,now:Date.now(),rankReasons:pick?pick.why:[]});
  }
  function entryFor(row,rec,pick){const q=quotes.get(String(row?.id));return ES.evaluate({...row,quote:q,limit:pick?.limit},signalFor(row,rec,pick));}
  function scoreHelp(){return `<details><summary>入场评分规则（底子10/形态50/价格10/量25 - 风险5，冷门枪85折）</summary><p><b>总分100分构成：</b><br>· 底子（选品分位）：0–10分<br>· 形态多维（右侧止跌与趋势）：0–50分<br>· 在售价不超标：0或10分<br>· 量配合（相对量放量承接）：0–25分<br>· 风险扣分项：跌势创新低/动量未转正/大盘弱势各扣5分<br>· 品类折扣：步枪、手枪、手套、探员不打折（1.0），其余微冲/霰弹/机枪打85折（0.85）。</p><small>规则 ${ES.VERSION}；单品成熟度评分不因大盘闸门关闭而清空。</small></details>`;}
  function signalCells(row,rec,pick){
    const q=quotes.get(String(row?.id));const v=signalFor(row,rec,pick),e=ES.evaluate({...row,quote:q,limit:pick?.limit},v),tone=e.code==='trigger'?'good':e.code==='blocked'?'bad':'warn';
    return `<td class="entry-score ${tone}" data-entry-score="${e.score===null?'':e.score}"><b>${e.score===null?'—':e.score}</b><small style="display:block">${e.score===null?'暂不评分':'/100 · 规则分'}</small></td><td class="signal-state ${tone}" data-signal="${esc(e.code)}">${esc(e.label)}</td>`+
      `<td class="signal-reason"><div>${esc(e.reason)}</div><details><summary>展开计算依据 / 量证据</summary><p>选品分 ${fin(row?.selPct)?'P'+num(row.selPct,0):'—'} · 悠悠收盘 ${num(row?.close,2)} · 价格上限 ${num(pick?.limit,2)} · 旧入场（仅对照） ${num(row?.deepEntry,0)} · 相对量 ${num(row?.relativeVolume,2)} · lab-2.1 状态 ${esc(row?.deepStatus||row?.deepReason||'未精算')}</p>`+
      v.reasons.map(t=>`<div>＋ ${esc(t)}</div>`).join('')+v.risks.map(t=>`<div class="warn">风险：${esc(t)}</div>`).join('')+
      v.conditions.map(t=>`<div class="warn">待确认：${esc(t)}</div>`).join('')+`<small>${esc(v.volumeBasis)}；不替代价格形态确认。</small>${volumeView(row&&row.volumeEvidence)}</details></td>`;
  }
  function learningView(){
    return `<details id="learningBox" class="card" ${learningOpen?'open':''}><summary>离线学习 · 冻结与导出</summary><p>完整扫盘后点“冻结本次学习样本”：保存全扫描清单（含未推荐/失败项），同日同规则只存首份，不自动上传。以后先正常扫描更新本机日K，再点“补充后续结果”。不为结算追加网络请求。</p><div class="row"><button id="learningCapture" ${learningBusy||!scanComplete()||scanBusy()||qs.busy?'disabled':''}>冻结本次学习样本</button><button id="learningSettle" ${learningBusy?'disabled':''}>补充7/14/30日结果</button><button id="learningJson" ${learningBusy?'disabled':''}>学习 JSON</button><button id="learningCsv" ${learningBusy?'disabled':''}>学习 CSV</button><button id="learningClear" ${learningBusy?'disabled':''}>清空学习档案</button></div><small>${esc(LC.POLICY)}。普通持仓备份不包含本档案，请单独导出JSON；不支持导入、自动调参或自动替换模型。CSV是分析摘要，JSON含完整特征。</small>${learningMessage?`<div class="note" role="status">${esc(learningMessage)}</div>`:''}</details>`;
  }
  async function learningAction(action){
    if(learningBusy)return;learningOpen=true;learningBusy=true;render();
    try{
      if(action==='capture'){
        const rec=currentRec();if(!rec||!scanComplete()||scanBusy()||qs.busy)throw Error('请等待完整扫描与报价读取结束。');
        const capturedAt=new Date().toISOString(),captureDay=BY.bjDay(),model=modelOf(cfg.h),picks=new Map(rec.picks.map(p=>[String(p.id),p]));
        const key=JSON.stringify([captureDay,rec.signalDay,cfg.h,model,rkey(),cfg.gate,cfg.topN,cfg.minLiq,cfg.maxZeroVol,cfg.fee,ES.VERSION]);
        const batch=JSON.parse(JSON.stringify({version:LC.VERSION,key,capturedAt,captureDay,signalDay:rec.signalDay,h:cfg.h,fee:cfg.fee,model,scoreRule:{version:ES.VERSION},outcomePolicy:LC.POLICY,settings:{rulesKey:rkey(),gate:cfg.gate,topN:cfg.topN,minLiq:cfg.minLiq,maxZeroVol:cfg.maxZeroVol},market:rec.regime,universe:scan.universe,rows:scan.rows.map(r=>{const pick=picks.get(String(r.id)),signal=signalFor(r,rec,pick);return {...r,_sig:undefined,id:String(r.id),entry:ES.evaluate(r,signal),signal,quote:quotes.get(String(r.id))||null,limit:pick?.limit??null,candidate:!!pick};})}));
        const saved=await ST.saveLearningBatch(batch);learningMessage=saved.capturedAt===capturedAt?'已冻结全扫描学习样本：'+saved.rows.length+'件，含未推荐商品。':'同日同模型同规则的首份已存在，未覆盖。';
      }else if(action==='clear'){
        if(ask('仅清空离线学习档案，不能撤销。请先导出JSON；不清持仓、日K或其他研究。')){await ST.clearLearning();learningMessage='学习档案已清空，持仓未改动。';}
      }else{
        let data=await ST.learningData();
        const ids=[...new Set(data.batches.flatMap(b=>b.rows.map(r=>r.id)))],cache=await ST.getKMany(ids),now=Date.now();
        const calculated=data.batches.flatMap(b=>LC.outcomes(b,cache,now));
        if(action==='settle'){
          for(const b of data.batches)await ST.saveLearningOutcomes(calculated.filter(o=>o.batchKey===b.key&&o.status==='matured'));
          data=await ST.learningData();learningMessage='已保存 '+data.outcomes.length+' 条到期结果；未到期 '+calculated.filter(o=>o.status==='pending').length+' 条，缺价 '+calculated.filter(o=>o.status==='missing').length+' 条（缺失不记零）。不回写旧判断。';
        }else{
          const saved=new Map(data.outcomes.map(o=>[o.batchKey+'|'+o.id+'|'+o.h,o]));
          const payload={app:'market-lens-entry-learning',schema:1,exportedAt:new Date(now).toISOString(),policy:LC.POLICY,batches:data.batches,outcomes:calculated.map(o=>saved.get(o.batchKey+'|'+o.id+'|'+o.h)||{...o,provisional:true})};
          download('market-lens-learning-'+Date.now()+'.'+(action==='json'?'json':'csv'),action==='json'?JSON.stringify(payload):LC.csv(payload),action==='json'?'application/json':'text/csv');learningMessage='已导出 '+data.batches.length+' 批学习档案；未点补充结果的计算标为provisional。';
        }
      }
    }catch(e){learningMessage='未完成：'+e.message;}finally{learningBusy=false;render();}
  }
  function signalExportRows(){
    const rec=currentRec(),picks=new Map((rec?rec.picks:[]).map(p=>[String(p.id),p]));
    return scan.rows.map(row=>{const q=quotes.get(String(row.id)),p=picks.get(String(row.id));const v=signalFor(row,rec,p);return {...row,entryScore:ES.evaluate({...row,quote:q,limit:p?.limit},v).score,entryScoreVersion:ES.VERSION,entryState:ES.evaluate(row,v).code,signalLabel:v.label,signalSummary:v.summary,signalVersion:v.version,signalAt:new Date().toISOString(),signalQuoteAt:q?q.at:null,signalAsk:q?q.price:null,signalLimit:p?p.limit:null,volumeAsOf:row.volumeEvidence?.asOf||null,lastVolume:row.volumeEvidence?.lastVolume??null,recentMean3:row.volumeEvidence?.recentMean3??null,baseMedian30:row.volumeEvidence?.baseMedian30??null,volumeCheck:row.volumeEvidence?.ok?'33日窗口完整':row.volumeEvidence?.reason||'未审计'};});
  }
  async function runDeepReview(){
    if(scanBusy()||exp.busy)return;
    tab=advTab='scan';render();await runScan();
  }
  function liveBuyHtml() {
    const running = scanBusy();
    const rec = currentRec();
    if (!rec) return `<p class="sub">${running ? '扫描进行中，排名达到 10 件后这里会实时出现买点清单…' : '还没有扫描结果。扫描只在你点按钮后进行；今天已缓存的日K不会重复请求。'}</p>`+learningView();
    const g = rec.regime, c = calibFor(modelOf(cfg.h), cfg.h, 5);
    let html = `<h3>② 买点清单 · 持有 ${cfg.h} 天</h3>` +
      `<p class="sub">信号日 ${esc(rec.signalDay)}（最近收盘）· ${rec.ranked} 件参与排名 · 买点 ${rec.picks.length} 件（选品分 ≥ P${BY.DEFAULTS.minPct}），前 ${rec.nTop} 件为首选 · 有效至 ${esc(rec.validTo)} · 建议持有到 ${esc(rec.holdTo)}</p>` +
      (rec.stale ? `<div class="note bad">这批结果基于 ${esc(rec.signalDay)} 的收盘，已过 ${rec.age} 天，信号可能已经失效。请重新扫描后再买。</div>` : '') +
      (rec.unknown ? '<div class="note warn">大盘数据不可用：仅供观察，暂不给出可买结论。</div>' : '') +
      (scan.resolved && scan.resolved.requiredMissing ? '<div class="note warn">规则内仍有商品ID未解析：本批只作观察，不保存正式参考截面。</div>' : '') +
      (scan.universeRulesKey && scan.universeRulesKey !== rkey() ? '<div class="note warn">筛选规则已改变，请重新扫描完整范围后再使用买点。</div>' : '') +
      (scan.failed.size ? `<div class="note warn">扫描不完整：${scan.failed.size} 件失败待补扫，不保存正式参考截面。</div>` : '') +
      (rec.gateOn ? `<div class="note bad"><b>大盘显著弱势</b>（${num(g.score, 0)} < ${cfg.gate}）：下面只作<b>观察名单</b>。历史上这种状态下暂停开新仓能明显降低回撤。</div>` : '') +
      (rec.tooFew ? `<div class="note warn">参与排名的商品不足 30 件，排名不稳定。${running ? '扫描仍在进行，稍等即可。' : '请检查筛选规则是否过严。'}</div>` : '') +
      (running ? `<div class="note warn">扫描进行中：清单随数据到达实时更新（已扫 ${scan.progress.done} / ${scan.progress.total}），排名会变化，请等扫描结束后再按最终清单下单。</div>` : '');
    if (!rec.picks.length) html += `<p class="sub">没有达到买点的商品。</p>`;
    else {
      html += quoteLine(rec) +
        `<div class="scroll"><table><tr><th>商品</th><th>入场评分</th><th>触发状态</th><th style="text-align:left">判断理由</th><th>悠悠在售价</th><th></th></tr>` +
        rec.picks.slice().sort((a,b)=>(entryFor(scan.rows.find(r=>String(r.id)===String(b.id)),rec,b).score??-1)-(entryFor(scan.rows.find(r=>String(r.id)===String(a.id)),rec,a).score??-1)).map(p => `<tr class="${p.top ? 'top' : ''}"><td><a href="${esc(p.url)}" title="${esc(p.name)}">${esc(p.name.length > 18 ? p.name.slice(0, 18) + '…' : p.name)}</a>${p.top ? ' <span class="pill hit">首选</span>' : ''}</td>` +
          `${signalCells(scan.rows.find(r=>String(r.id)===String(p.id)),rec,p)}<td>${askCell(p, rec.blocked)}</td>` +
          `<td>${isHeld(p.id) ? '<small class="good">已在持仓</small>' : `<button data-buy="${esc(p.id)}" style="padding:2px 8px">${rec.blocked?'自主买入记账':'记为已买入'}</button>`}</td></tr>`).join('') +
        `</table></div>`;
    }
    html += `<details><summary>持有计划与历史参考</summary><div class="note"><b>买卖计划</b><br>` +
      `· 买入：悠悠在售价不高于“买入价上限”（最近收盘 +${pc(BY.DEFAULTS.tol, 0)}）时买，高了就等或换下一件。信号在 ${esc(rec.validTo)} 之后作废，需重新扫描。<br>` +
      `· 分散：挑 5–10 件，每件金额差不多；首选优先。<br>` +
      `· 卖出：持有约 ${cfg.h} 天（到 ${esc(rec.holdTo)} 前后）卖出，不因中途涨跌提前判断。CS2 交易后通常有约 7 天冷却期不能卖。<br>` +
      (c ? `· 历史参考：这一档（前 20%）在${esc(c.src)}里持有 ${cfg.h} 天，平均超额 ${spc(c.excess)}、中位超额 ${spc(c.med)}、跑赢同类 ${pc(c.beat, 0)}（n=${c.n}）。单件仍常常亏钱，所以要分散。` : '') +
      `</div></details>`;
    return scoreHelp()+html+learningView();
  }
  function itemVerdict() {
    if (!fx) return '';
    const r = fx.byH[cfg.h] || {}, rc = fields ? F.ruleCheck(fields.title, r.ok ? r.sc.close : null, cfg.rules) : { ok: true };
    const close = r.ok ? r.sc.close : null;
    const v = BY.verdict({ ok: r.ok, reason: r.reason, pct: r.pct, tradable: r.tradable, ruleOk: rc.ok, ruleText: rc.ok ? '' : F.RULE_REASONS[rc.code] || '规则外', regime: fx.regime, gate: cfg.gate, h: cfg.h, close, signalDay: r.ok ? r.sc.day : null, today: BY.bjDay(), coverage: r.ok ? r.sc.coverage : null, referenceOk: !!(r.ref && !r.ref.mismatch && BY.fresh(r.ref.day, BY.bjDay(), 3)) });
    const icon = { yes: '✅', wait: '⏸', watch: '◐', no: '✕', na: '？' }[v.level];
    const today = BY.bjDay();
    const refAge = r.ok && r.ref ? ageDays(r.ref.day) : null;
    const askHigh = v.buy && fields && fin(fields.price) && v.limit && fields.price > v.limit;
    return `<div class="card verdict ${v.level}" id="verdict"><small>买点结论 · 持有 ${cfg.h} 天</small><div class="vt">${icon} ${esc(v.title)}</div>` +
      `<div style="font-size:12px;margin-top:4px">${esc(v.text)}</div>` +
      (v.buy ? `<div class="kv"><span>买入价上限（最近收盘 ¥${num(close, 2)} +${pc(BY.DEFAULTS.tol, 0)}）</span><b>¥${num(v.limit, 2)}</b></div>` +
        `<div class="kv"><span>建议持有到</span><b>${esc(BY.addDays(today, cfg.h))}</b></div>` +
        (askHigh ? `<div class="warn" style="font-size:12px">当前悠悠在售 ¥${num(fields.price, 2)} 已高于上限，建议等回落，不要追高。</div>` : '') +
        `<div class="row" style="margin:8px 0 0">${isHeld(identity.id) ? '<small class="good">已在“我的持仓”里</small>' : `<button id="itemBuy" ${v.level !== 'yes' || askHigh ? 'disabled' : ''} class="primary">记为已买入（¥${num(fields && fin(fields.price) ? fields.price : close, 2)}）</button>`}<small>只记录在本机，不会下单</small></div>` : '') +
      (r.ok && r.ref && r.ref.src !== 'scan' && refAge > 3 ? `<div class="warn" style="font-size:11px;margin-top:6px">对比基准是 ${esc(r.ref.day)} 的内置截面（已过 ${refAge} 天）。先在“今日买点”扫描一次，结论会更准。<button id="goBuy" style="padding:1px 8px">去扫描</button></div>` : '') +
      `<small>下面 ①②③ 是这个结论的依据。</small></div>`;
  }
  function advNav() {
    return `<div class="tabs sub2">${ADV_TABS.map(t => `<button class="tab ${tab === t[0] ? 'on' : ''}" data-tab="${t[0]}">${t[1]}</button>`).join('')}</div>` +
      `<small>高级功能：看完整扫描明细、回测和训练模型、改筛选规则。日常找买点用“今日买点”就够了。</small>`;
  }
  function holdView() {
    const today = BY.bjDay(), fee = cfg.fee;
    const open = hold.list.filter(h => h.status !== 'sold'), sold = hold.list.filter(h => h.status === 'sold');
    const sm = BY.summarizeHoldings(hold.list, hold.prices, today, { fee });
    const sel = new Map(scan.rows.filter(r => fin(r['sel' + cfg.h])).map(r => [String(r.id), r['sel' + cfg.h]]));
    const cls = v => (fin(v) ? (v >= 0 ? 'plus' : 'minus') : '');
    const money = v => (fin(v) ? (v >= 0 ? '+' : '−') + '¥' + Math.abs(v).toFixed(2) : '—');
    let html = `<h3>我的持仓</h3><div class="row"><button id="holdManual" class="primary">自主买入记账</button><small>无须扫描或模型许可；只登记已完成交易。</small></div>` +
      `<div class="grid"><div class="card"><small>持有中 ${sm.open} 件${sm.due ? ` · <b class="warn">${sm.due} 件已到期</b>` : ''}</small><div class="mid">成本 ¥${num(sm.cost, 2)}</div>` +
      `<small>浮动盈亏（扣 ${pc(fee, 1)} 卖出成本）<b class="${cls(sm.pnl)}">${sm.priced ? money(sm.pnl) : '—'}</b>${fin(sm.pnlPct) ? ` (${spc(sm.pnlPct)})` : sm.priced < sm.open ? ` · ${sm.open - sm.priced} 件无现价` : ''}</small></div>` +
      `<div class="card"><small>已卖出 ${sm.sold} 件</small><div class="mid ${cls(sm.realized)}">${sm.sold ? money(sm.realized) : '—'}</div><small>已实现盈亏${fin(sm.realizedPct) ? ' ' + spc(sm.realizedPct) : ''}（含买入费用；卖出费优先用实际填写，否则估算）</small></div></div>` +
      `<div class="row"><button id="holdRefresh" ${hold.busy || !open.length ? 'disabled' : ''}>${hold.busy ? '读取中…' : '刷新现价'}</button><small>现价 = 悠悠日K最近收盘；只读取持仓里的商品。</small></div>` +
      (hold.msg ? `<div class="note" id="holdMsg">${esc(hold.msg)}</div>` : '');
    if (!hold.list.length) return html + `<p class="sub">还没有持仓记录。在“今日买点”或单品页点“记为已买入”即可添加。</p>` + holdNote();
    if (open.length) {
      html += `<div class="scroll"><table><tr><th>商品</th><th>买入日</th><th>买入价</th><th>数量</th><th>买入费用</th><th>现价</th><th>浮盈</th><th>持有到</th><th>状态</th><th></th></tr>` +
        open.map(h => {
          const st = BY.holdingState(h, hold.prices[h.id], today, { fee });
          const p = sel.get(h.id);
          const weak = fin(p) && p < BY.DEFAULTS.avoidPct;
          return `<tr><td><a href="${esc(h.url || S.itemUrl(h.id))}" title="${esc(h.name)}">${esc(String(h.name).length > 14 ? String(h.name).slice(0, 14) + '…' : h.name)}</a>${holdingOrigin(h)}</td>` +
            `<td>${esc(String(h.buyDay).slice(5))}</td><td><input data-hbp="${esc(h.hid)}" type="number" step="0.01" min="0" value="${num(st.buy, 2)}"></td>` +
            `<td><input data-hqty="${esc(h.hid)}" type="number" step="1" min="1" value="${st.qty}" style="width:44px"></td>` +
            `<td><input data-hbf="${esc(h.hid)}" type="number" step="0.01" min="0" value="${num(st.buyFee,2)}" style="width:64px"></td><td>${st.cur !== null ? '¥' + num(st.cur, 2) : '—'}</td><td class="${cls(st.pnl)}">${fin(st.pnlPct) ? spc(st.pnlPct) : '—'}</td>` +
            `<td>${esc(String(h.sellBy || '').slice(5))}</td>` +
            `<td style="white-space:normal;max-width:110px;font-size:10px" class="${st.status === 'due' ? 'warn' : ''}">${esc(st.label)}${fin(p) ? `<br><span class="${weak ? 'bad' : ''}">当前 P${num(p, 0)}${weak ? ' 信号已转弱' : ''}</span>` : ''}</td>` +
            `<td><button data-hsell="${esc(h.hid)}" style="padding:2px 7px">卖出</button> <button data-hdel="${esc(h.hid)}" class="danger" style="padding:2px 7px">删</button></td></tr>`;
        }).join('') + `</table></div>`;
    }
    if (sold.length) {
      html += `<details ${open.length ? '' : 'open'}><summary>已卖出 ${sold.length} 件</summary><div class="scroll"><table><tr><th>商品</th><th>买入</th><th>卖出日</th><th>卖出价</th><th>整笔卖出费</th><th>持有</th><th>收益</th><th></th></tr>` +
        sold.map(h => {
          const st = BY.holdingState(h, null, today, { fee });
          return `<tr><td>${esc(String(h.name).length > 14 ? String(h.name).slice(0, 14) + '…' : h.name)}${holdingOrigin(h)}</td><td>¥${num(st.buy, 2)}×${st.qty}</td><td>${esc(String(h.sellDay || '').slice(5))}</td>` +
            `<td><input data-hsp="${esc(h.hid)}" type="number" step="0.01" min="0" value="${num(Number(h.sellPrice), 2)}"></td><td><input data-hsf="${esc(h.hid)}" type="number" min="0" step="0.01" value="${fin(h.sellFee)?num(h.sellFee,2):''}" placeholder="按设置估算" style="width:90px"><small>${st.sellFeeEstimated?'估算':'实际填写'}</small></td><td>${fin(st.heldDays) ? st.heldDays + '天' : '—'}</td>` +
            `<td class="${cls(st.pnl)}">${money(st.pnl)} <small>${spc(st.pnlPct)}</small></td>` +
            `<td><button data-hreopen="${esc(h.hid)}" style="padding:2px 7px">撤销</button> <button data-hdel="${esc(h.hid)}" class="danger" style="padding:2px 7px">删</button></td></tr>`;
        }).join('') + `</table></div></details>`;
    }
    return html + holdNote();
  }
  function holdingOrigin(h){return `<small style="display:block" class="${h.entrySource==='manual'?'warn':''}">${h.entrySource==='manual'?'自主买入 · 非模型推荐':h.entrySource==='model-assisted'?'原推荐流程记账':'历史记录 · 来源未标记'}</small>${h.entrySource==='manual'?`<details><summary>记账时观察 / 备注</summary><small>${esc(h.decisionCapturedAt||'')}<br>${esc(h.decisionNote||'')}<br>${esc(h.userNote||'')}<br>此为录入时观察，不回填买入日的模型结论。</small></details>`:''}`;}
  const holdNote = () => `<div class="note">· 这里只是记账：记录保存在本机浏览器，不会下单、不会连接你的账号；可在 高级→学习→数据 里导出备份。<br>` +
    `· 自主记账须填写实际买入价与整笔费用；旧推荐快捷记账仍预填报价，请核对。成本含买入费用；卖出费填实际金额时替代估算，不重复扣费。卖出价默认最近收盘，请改成实际成交价。<br>` +
    `· 持有期是你的计划，可自行决定是否卖出；“信号已转弱”只是提示，回测没有验证过提前卖出的效果。<br>` +
    `· CS2 饰品交易后通常约 7 天冷却期，期间无法卖出。</div>`;

  function openManual(it, decision){
    if(manual.busy)return;
    manual.assisted=null;manual.returnTab=tab;manual.open=true;manual.error='';manual.originalId=it?String(it.id):null;manual.observedAt=new Date().toISOString();manual.token='m-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);manual.decision=decision||'当前未取得完整模型推荐；自主买入，非模型推荐。';
    manual.draft={item:it?String(it.id):'',name:it?(it.name||''):'',buyDay:BY.bjDay(),buyPrice:'',qty:'1',buyFee:'0',h:String(cfg.h),note:''};
    opened=true;render();root.querySelector('#manualForm')?.scrollIntoView?.({block:'start'});
  }
  function manualView(){
    if(!manual.open)return '';
    const d=manual.draft;
    const field=(key,label,type='text',extra='')=>`<label>${label}<input data-manual="${key}" type="${type}" value="${esc(d[key])}" ${extra} ${manual.busy?'disabled':''}></label>`;
    return `<form id="manualForm" class="card manual-form"><h3>${manual.assisted?'标记为买入 · 核对实际成交':'自主买入记账 · 不会下单'}</h3><div class="note warn">${manual.assisted?'参考报价已预填，请改成实际成交价、数量和费用后确认；来源为推荐辅助记账，并非自动交易或模型业绩。':'模型判断不限制你记录实际交易。此笔标记为“自主买入，非模型推荐”，不会关闭风险闸门或改变排名。'}<br>${esc(manual.decision)}</div><div class="grid">`+
      field('item','FirePulse 商品 ID / 商品链接','text','required')+field('name','商品名称（含磨损，请核对）','text','required maxlength="300"')+
      field('buyDay','实际买入日期','date',`required max="${BY.bjDay()}"`)+field('buyPrice',manual.assisted?'实际成交单价 ¥（预填报价，请核对）':'实际成交单价 ¥（不自动填挂牌价）','number','required min="0.01" step="0.01"')+
      field('qty','数量','number','required min="1" max="1000000" step="1"')+field('buyFee','整笔买入费用 ¥（不是费率）','number','required min="0" step="0.01"')+
      `<label>你自己的计划持有期<select data-manual="h" ${manual.busy?'disabled':''}>${[7,14,30].map(h=>`<option value="${h}" ${String(h)===d.h?'selected':''}>${h}天</option>`).join('')}</select></label>`+field('note','自主买入备注（可选）','text','maxlength="500"')+
      `</div><p class="sub">没有接口也可保存。商品ID与名称由你核对；只支持人民币记录。费用若已计入单价，请勿重复填写。手动记录的日期与模型观察时间分开保存。</p>${manual.error?`<div id="manualError" class="note bad">${esc(manual.error)}</div>`:''}<div class="row"><button type="submit" id="manualSave" class="primary" ${manual.busy?'disabled':''}>${manual.busy?'保存中…':'确认已成交，保存记账'}</button><button type="button" id="manualCancel" ${manual.busy?'disabled':''}>取消</button></div></form>`;
  }
  async function saveManual(e){
    e.preventDefault();if(manual.busy)return;
    try{
      const d=manual.draft,rec=MC.build({item:d.item,name:d.name,buyDay:d.buyDay,buyPrice:d.buyPrice===''?NaN:Number(d.buyPrice),qty:Number(d.qty),buyFee:d.buyFee===''?NaN:Number(d.buyFee),h:Number(d.h),note:d.note},{today:BY.bjDay(),decisionNote:manual.originalId&&MC.itemId(d.item)!==manual.originalId?'用户改为其他商品ID；未取得该商品推荐判断，自主买入，非模型推荐。':manual.decision,observedAt:manual.observedAt});rec.recordToken=manual.token;
      if(manual.assisted&&rec.id===manual.originalId){rec.entrySource='model-assisted';rec.modelId=manual.assisted.modelId;rec.pctAtBuy=manual.assisted.pct;}
      if(!ask(`只记账，不下单。\n${rec.name}\nID ${rec.id}\n${rec.qty} 件 × ¥${rec.buyPrice}，整笔费用 ¥${rec.buyFee}\n买入日 ${rec.buyDay}\n确定信息与已完成交易一致？`))return;
      manual.busy=true;manual.error='';render();
      const saved=await ST.addHolding(rec);
      manual.open=false;manual.busy=false;await loadHoldings();if(saved.entrySource==='model-assisted'){buy.msg='已记入“我的持仓”：'+saved.name+'；已按你确认的实际成交信息保存。';tab=manual.returnTab;}else{hold.msg='已保存自主买入：'+saved.name+'；不代表模型推荐。';tab='hold';}render();
    }catch(err){manual.busy=false;manual.error=err.message;render();}
  }
  function volumeView(v){
    if(!v)return '<small>尚无量证据。请扫描或刷新商品数据；不据此猜测成交量。</small>';
    if(!v.ok)return `<small class="warn">量证据不可完整计算：${esc(v.reason)}</small>`;
    return `<details class="volume-audit"><summary>成交量证据 · 截至 ${esc(v.asOf)} · 末日 ${num(v.lastVolume,0)}</summary><div class="sub">${esc(v.source)}<br>${esc(v.basis)}<br>末日量：${num(v.lastVolume,2)}；近3日均量：${num(v.recentMean3,2)}<br>此前30日量中位数：${num(v.baseMedian30,2)}；相对量：${fin(v.relativeVolume)?num(v.relativeVolume,2)+'倍':'基准不足，无法计算'}<br>基准 ${esc(v.baseStart)} → ${esc(v.baseEnd)}；近3日 ${esc(v.recentStart)} → ${esc(v.recentEnd)}<br>近30日零量天数：${v.zeroDays30}。未用挂单数充当成交量。<br>${esc(v.verification)}</div><details><summary>查看33日缓存量字段</summary><pre style="max-height:180px;overflow:auto">${esc(v.rows.map(r=>r.day+'  '+num(r.volume,2)).join('\n'))}</pre></details></details>`;
  }
  function compareEntry(row,rec,pick){
    const q=quotes.get(String(row.id)),stamp=q?Date.parse(q.at):NaN,now=Date.now();
    const priceReady=!!rec&&!rec.blocked&&scanComplete()&&!scanBusy()&&!!pick&&q?.ok&&fin(q.price)&&q.price>0&&fin(stamp)&&now>=stamp&&now-stamp<=S.DEFAULTS.quoteTtlMs&&(!fin(q.count)||q.count>0)&&fin(pick.limit)&&q.price<=pick.limit;
    return EC.compare({...row,studyPriceReady:!!priceReady},signalFor(row,rec,pick));
  }
  function entryStudyView(){
    const rec=currentRec();
    return `<details id="entryStudyBox" class="card" ${entryStudyOpen?'open':''}><summary>入场条件 A/B/C 对照（研究，不改正式买点）</summary><p class="sub">A：原候选+价格门槛。B：2.10.1 统一量确认。C：分形态价量假设（突破相对量≥1.5；回调0.5–1且恢复；止跌≥1且恢复改善）。C不是已优化模型，未验证优于A/B；三组均不限制自主记账。</p><div class="row"><button id="entryCapture" ${!rec||!scanComplete()||scanBusy()?'disabled':''}>冻结当前入场条件</button><button id="entryExport">导出入场对照 JSON</button><button id="entryClear" class="danger">清空入场档案</button></div><small>仅保存当前数据与条件是否通过，不补历史报价、不计算未来收益。每信号日/周期/模型/规则组合仅首份；最多100批，重复不覆盖。此档案独立于持仓备份及四模型实验室档案。</small>${entryMessage?`<div class="note">${esc(entryMessage)}</div>`:''}</details>`;
  }
  async function captureEntry(){
    entryStudyOpen=true;try{
      const rec=currentRec();if(!rec||!scanComplete()||scanBusy())throw Error('请先完成扫描；缺少数据时不冻结伪完整结果。');
      const capturedAt=new Date().toISOString(),key=JSON.stringify([rec.signalDay,cfg.h,modelOf(cfg.h).id,rkey()]);
      const rows=rec.picks.map(p=>{const r=scan.rows.find(x=>String(x.id)===p.id),q=quotes.get(p.id);return {id:p.id,name:p.name,close:r.close,relativeVolume:r.relativeVolume,eligible:r.eligible,shapeEvidence:r.shapeEvidence,volumeEvidence:r.volumeEvidence,quote:q?{ok:q.ok,price:q.price??null,at:q.at??null,count:q.count??null}:null,limit:p.limit,comparison:compareEntry(r,rec,p)};});
      const record=await ST.saveEntryStudy({version:EC.VERSION,key,signalDay:rec.signalDay,h:cfg.h,modelId:modelOf(cfg.h).id,rulesKey:rkey(),capturedAt,universe:scan.rows.map(r=>String(r.id)),gateBlocked:rec.blocked,rows});
      entryMessage=record.capturedAt===capturedAt?'首份入场对照已冻结，不修改推荐或持仓。':'该组合已有首份快照，未覆盖、未补写后来的价格。';
    }catch(e){entryMessage='未记录：'+e.message;}render();
  }
  async function exportEntries(){
    entryStudyOpen=true;try{const rows=await ST.entryStudies();download('market-lens-entry-studies-'+Date.now()+'.json',JSON.stringify({app:'market-lens-entry-studies',schema:1,exportedAt:new Date().toISOString(),studies:rows},null,2));entryMessage='已导出 '+rows.length+' 批入场对照，不包含持仓；仅归档，暂不支持导入或自动收益结算。';}catch(e){entryMessage=e.message;}render();
  }

  async function loadHoldings() {
    try { hold.list = await ST.holdings(); } catch (e) { hold.msg = '读取持仓失败：' + e.message + '；保留当前显示，请勿重复记账。'; return; }
    const ids = [...new Set(hold.list.filter(h => h.status !== 'sold').map(h => h.id))];
    for (const id of ids) {
      const s = scan.series.get(id);
      if (s) { setHoldPrice(id, s); continue; }
      if (fin(hold.prices[id])) continue;
      try { const c = await ST.getK(id); if (c && c.series) setHoldPrice(id, c.series); } catch (e) { /* no cache */ }
    }
    hold.loaded = true;
  }
  function setHoldPrice(id, s) {
    const i = F.lastUsableIndex(s);
    if (i >= 0) { hold.prices[id] = s.c[i]; hold.priceDay[id] = dStr(s.day0 + i); }
  }
  // 2.9: cache-aware like the scan — an item whose youpin K is already fresh
  // today costs no request; a stale one only fetches the missing tail.
  async function refreshHoldPrices() {
    const list = hold.list.filter(h => h.status !== 'sold');
    const ids = [...new Set(list.map(h => String(h.id)))];
    if (hold.busy || !ids.length) return;
    hold.busy = true; hold.msg = '正在读取 ' + ids.length + ' 件的悠悠日K…'; render();
    let ok = 0, fail = 0, net = 0;
    let idx = {}, cached = new Map();
    try { idx = cfg.useCache ? await ST.kIndex() : {}; cached = await ST.getKMany(ids); } catch (e) { /* storage unavailable */ }
    for (const id of ids) {
      try {
        const h = list.find(x => String(x.id) === id);
        const kr = await fetchK(id, idx[id], cached.get(id) || null, h ? h.name : '', idx[id] ? idx[id].family : S.familyOf(h ? h.name : ''), null, null);
        if (!kr.series.ok) throw Error(kr.series.reason);
        if (kr.mode !== 'cache') net++;
        if (scan.series.has(id)) scan.series.set(id, kr.series);
        setHoldPrice(id, kr.series); ok++;
        if (kr.mode !== 'cache' && ids.length > 1) await sleep(S.DEFAULTS.delayMin + Math.random() * (S.DEFAULTS.delayMax - S.DEFAULTS.delayMin));
      } catch (e) { fail++; }
    }
    try { await ST.flushIdx(); } catch (e) { /* ignore */ }
    hold.busy = false;
    hold.msg = '现价已更新：成功 ' + ok + ' 件（其中 ' + (ok - net) + ' 件用今日缓存，未发请求）' + (fail ? '，失败 ' + fail + ' 件（可稍后再试）' : '') + '。';
    render();
  }
  async function editHolding(hid, patch) {
    try { await ST.updateHolding(hid, patch); } catch (e) { hold.msg = '保存失败：' + e.message; }
    await loadHoldings(); render();
  }
  async function sellHolding(hid) {
    const h = hold.list.find(x => x.hid === hid);
    if (!h) return;
    const price = fin(hold.prices[h.id]) ? hold.prices[h.id] : Number(h.buyPrice);
    hold.msg = '已标记卖出：' + h.name + '。卖出价默认 ¥' + num(price, 2) + '（最近收盘），请在“已卖出”里改成实际成交价。';
    await editHolding(hid, { status: 'sold', sellDay: BY.bjDay(), sellPrice: Math.round(price * 100) / 100 });
  }
  async function deleteHolding(hid) {
    const h = hold.list.find(x => x.hid === hid);
    if (!h || !ask('删除这条记录？' + h.name)) return;
    try { await ST.removeHolding(hid); } catch (e) { hold.msg = '删除失败：' + e.message; }
    hold.msg = '已删除：' + h.name;
    await loadHoldings(); render();
  }
  async function recordBuy(it, price) {
    if (!fin(price) || price <= 0) { buy.msg = '没有可用的价格，请使用自主记账。'; render(); return; }
    openManual(it,'来自原推荐候选流程；入场评分和风险仅供观察，请核对实际成交，报价并非成交证明。');
    manual.assisted={modelId:modelOf(cfg.h).id,pct:fin(it.pct)?Math.round(it.pct):null};manual.draft.buyPrice=String(Math.round(price*100)/100);render();root.querySelector('#manualForm')?.scrollIntoView?.({block:'start'});
  }
  // Price recorded by default: the youpin ask read for this pick (if any), else the latest youpin close.
  function recordBuyFromScan(id) {
    const r = scan.rowIdx.has(String(id)) ? scan.rows[scan.rowIdx.get(String(id))] : scan.rows.find(x => String(x.id) === String(id));
    if (!r) return;
    const rec = currentRec();
    if (!rec || rec.blocked || !rec.picks.some(p => String(p.id) === String(id))) {openManual(r,signalFor(r,rec,rec&&rec.picks.find(p=>String(p.id)===String(id))).summary+'；自主买入，非模型推荐。');return;}
    const q = quotes.get(String(id));
    if (!q || !q.ok || !q.at || !Number.isFinite(Date.parse(q.at)) || Date.now() - Date.parse(q.at) > S.DEFAULTS.quoteTtlMs || q.price > r.limit) {openManual(r,'报价无效、过期或高于原上限；请填写你已完成交易的实际价格，非模型推荐。');return;}
    recordBuy({ id: r.id, name: r.name, url: r.url, pct: r['sel' + cfg.h] }, q && q.ok ? q.price : fin(r.close) ? r.close : r.price);
  }
  function recordBuyFromItem() {
    if (!identity || !fx) return;
    const r = fx.byH[cfg.h] || {};
    const rc = fields && r.ok ? F.ruleCheck(fields.title, r.sc.close, cfg.rules) : { ok: false };
    const v = BY.verdict({ ok: r.ok, pct: r.pct, tradable: r.tradable, ruleOk: rc.ok, regime: liveRegime(r.ok ? r.sc.day : null), gate: cfg.gate, h: cfg.h, close: r.ok ? r.sc.close : null, signalDay: r.ok ? r.sc.day : null, today: BY.bjDay(), coverage: r.ok ? r.sc.coverage : null, referenceOk: !!(r.ref && !r.ref.mismatch && BY.fresh(r.ref.day, BY.bjDay(), 3)) });
    const q = quotes.get(String(identity.id));
    if (v.level !== 'yes' || !q || !q.ok || Date.now() - Date.parse(q.at) > S.DEFAULTS.quoteTtlMs || q.price > v.limit) { buy.msg = '信号或报价不可执行，请刷新后再判断。'; render(); return; }
    const price = fields && fin(fields.price) ? fields.price : (r.ok ? r.sc.close : null);
    recordBuy({ id: identity.id, name: fields ? fields.title : '商品 ' + identity.id, url: location.href, pct: r.pct }, price);
  }
  // ---- scan view -----------------------------------------------------------
  const scanBusy = () => scan.phase === 'resolve' || scan.phase === 'deep' || scan.phase === 'quote';
  function estimateLine() {
    const p = scan.plan;
    if (!p) return '';
    return `<small id="planText">本次预计：缓存命中 ${p.counts.cache} · 增量补齐 ${p.counts.tail} · 完整抓取 ${p.counts.full}${p.counts.search ? ' · 白名单解析 ' + p.counts.search : ''} → 请求 ${p.requests} 次，${mins(p.minutes)}（并发 ${cfg.concurrency}）</small>`;
  }
  function progressHtml() {
    const p = scan.progress;
    const pct = p.total ? Math.min(100, p.done / p.total * 100) : 0;
    const phaseText = { idle: '未开始', resolve: '① 解析白名单', deep: '② 读取悠悠日K', quote: '③ 读取买点在售价', paused: '已暂停', done: '完成', error: '出错' }[scan.phase] || scan.phase;
    return `<div class="row" style="margin-bottom:4px"><span class="pill">${esc(phaseText)}</span><small id="progText">${progressText()}</small></div>` +
      `<div class="bar"><i id="progBar" style="width:${pct.toFixed(1)}%"></i></div>` +
      estimateLine() +
      (scan.coverage ? `<div class="sub" style="margin-top:4px">${esc(scan.coverage)}</div>` : '') +
      (scan.autoPaused ? `<div class="note bad">${esc(scan.autoPaused)}</div>` : '') +
      (scan.error ? `<div class="note bad">${esc(scan.error)}</div>` : '') +
      (scan.note ? `<div class="note">${esc(scan.note)}</div>` : '');
  }
  function progressText() {
    const p = scan.progress;
    if (scan.phase === 'quote') return '买点在售价 ' + qs.done + ' / ' + qs.total + ' · 请求累计 ' + p.requests;
    if (!p.total) return '请求累计 ' + p.requests;
    let eta = '';
    if (scan.phase === 'deep' && p.done < p.total) {
      const left = p.total - p.done, avg = p.netN ? p.netMs / p.netN : S.COST.tail * 1000;
      const netShare = p.done ? Math.max(0.05, (p.tail + p.full) / p.done) : 1;
      eta = ' · 剩余' + mins(left * netShare * (avg + 250) / Math.max(1, cfg.concurrency) / 60000);
    }
    return p.done + ' / ' + p.total + ' · 成功 ' + p.ok + ' · 失败 ' + p.fail + ' · 缓存 ' + p.cached + ' · 增量 ' + p.tail + ' · 完整 ' + p.full + ' · 请求 ' + p.requests + eta;
  }
  function liveScanHtml() {
    if (!scan.rows.length) return '<p class="sub">尚无结果。到“今日买点”点“开始扫描”，或在这里点“开始扫描”。</p>'+learningView();
    const sum = S.summarize(scan.rows);
    const rec=currentRec(),pickMap=new Map((rec?rec.picks:[]).map(p=>[String(p.id),p]));
    const scored=scan.rows.map(r=>({...r,entryScore:entryFor(r,rec,pickMap.get(String(r.id))).score}));
    const sorted=(scan.sortKey==='entryScore'?scored.sort((a,b)=>{if(a.entryScore===null)return b.entryScore===null?0:1;if(b.entryScore===null)return -1;return (scan.sortDir==='asc'?1:-1)*(a.entryScore-b.entryScore);}):S.sortRows(scored,scan.sortKey,scan.sortDir)).slice(0,scan.shown);
    return scoreHelp()+`<p class="sub">本次清单 ${sum.total} 件 · 已精算 ${sum.deep} 件 · 选品分参与排名 ${scan.cross?.n||0} 件 · 未完成或规则变化时不出最终评分。原选品排名不变；此表默认按入场评分排序。</p>`+
      `<div class="row"><select id="sortKey">${[['entryScore','入场评分'],['selPct','选品分'],['relativeVolume','相对量'],['name','商品']].map(c=>`<option value="${c[0]}" ${scan.sortKey===c[0]?'selected':''}>按${c[1]}</option>`).join('')}</select><button id="sortDir">${scan.sortDir==='desc'?'降序':'升序'}</button><small>持有周期</small>${hSelector('sh')}<small>显示前 ${sorted.length} / ${scan.rows.length}</small>${scan.rows.length>scan.shown?'<button id="showMore">再显示 300</button>':''}</div>`+
      `<div class="scroll"><table><tr><th>商品</th><th>入场评分</th><th>触发状态</th><th>判断理由</th><th>在售价</th><th>记账</th></tr>`+
      sorted.map(r=>`<tr><td><a href="${esc(r.url)}">${esc(r.name)}</a></td>${signalCells(r,rec,pickMap.get(String(r.id)))}<td>${fin(r.ask)?'¥'+num(r.ask,2):'—'}</td><td><button data-buy="${esc(r.id)}">${pickMap.has(String(r.id))&&!rec?.blocked?'记为已买入':'自主买入记账'}</button></td></tr>`).join('')+'</table></div>'+learningView();
  }

  function scanView() {
    const running = scanBusy();
    const wv = whitelistView();
    const canResume = scan.phase === 'paused' && scan.universe && scan.cursor < scan.queue.length;
    return `<h3>市场扫盘 · 白名单 ${WL.COUNT} 件</h3><details><summary>触发状态与深度扫描说明（不改原排名）</summary><div class="note">触发状态为 2.10.1 新增展示规则：原模型 P80 候选 + 扫描/大盘/时效通过 + 有效在售价≤原上限，再核对相对量≥1及旧规则基础条件。量为全平台代理，不是悠悠独立成交量；不代表所有形态待确认项已满足。原排名与记账入口保持不变。<br>深度扫描会进入完整明细，读取或复用日K、重算旧规则与理由；“开始扫描”本来也包含这些计算，并非额外预测模型。默认遵守缓存，不强制拉满历史。</div></details><div class="note">扫描范围固定为白名单（全部.csv，${WL.COUNT} 个 market_hash_name，已内置 FirePulse 商品 ID ${WL.ITEMS.filter(x => x.id).length} 个）。筛选规则决定其中哪些参与排名（当前规则内 ${wv.kept} 件${Object.keys(wv.why).length ? '，排除 ' + esc(reasonsText(wv.why)) : ''}）。选品分和价格复核只用<b>悠悠日K</b>；不再抓关键词清单，也不再逐件请求悠悠报价（在售价只对买点清单读取）。</div>` + rulesBlock() +
      `<details class="card"><summary><b>速度设置</b> <small>并发 ${cfg.concurrency} · 首次深度 ${cfg.kDepth} 天 · ${cfg.useCache ? '使用缓存' : '不用缓存'}</small></summary>` +
      `<div class="row"><label><small>并发请求数</small> <select id="setConc">${[2, 3, 4].map(n => `<option value="${n}" ${cfg.concurrency === n ? 'selected' : ''}>${n}</option>`).join('')}</select></label>` +
      `<label><small>首次抓取深度</small> <select id="setDepth"><option value="720" ${cfg.kDepth === 720 ? 'selected' : ''}>720 天（选品分/回测足够）</option><option value="1440" ${cfg.kDepth === 1440 ? 'selected' : ''}>1440 天（完整历史，首次更慢）</option></select></label>` +
      `<label class="ck"><input type="checkbox" id="useCache2" ${cfg.useCache ? 'checked' : ''}>用本地缓存</label></div>` +
      `<small>每件商品每天只需一次请求：已缓存的当天不再请求；隔天只补最近几十天并合并进缓存（数据量约为完整抓取的 1/15）。并发 ${cfg.concurrency} 时白名单一天刷新${mins(wv.kept * (S.COST.tail + 0.25) / Math.max(1, cfg.concurrency) / 60)}。遇到 429 会自动降速 ${S.DEFAULTS.cooldownMs / 1000} 秒，连续 ${S.DEFAULTS.failStreak} 次失败自动暂停。请不要为了更快关闭缓存。</small></details>` +
      `<div class="row"><button id="scanRun" class="primary" ${running ? 'disabled' : ''}>${running ? '扫描中…' : canResume ? '继续扫描' : '开始扫描'}</button>` +
      `<button id="deepReview" ${running || exp.busy ? 'disabled' : ''}>深度扫描 / 查看依据</button><button id="scanPause" ${scan.phase !== 'deep' ? 'disabled' : ''}>暂停</button>` +
      `<button id="scanStop" ${running || scan.phase === 'paused' ? '' : 'disabled'}>停止</button>` +
      `<button id="scanCsv" ${!scan.rows.length ? 'disabled' : ''}>导出 CSV</button><button id="scanJson" ${!scan.rows.length ? 'disabled' : ''}>导出 JSON</button><button id="scanReset" ${running ? 'disabled' : ''}>清空</button></div>` +
      progressHtml() + `<div id="liveResults">${liveScanHtml()}</div>` + entryStudyView() +
      `<div class="note warn"><b>使用前必读</b><br>` +
      `· 选品分只在“同一批”商品之间比较相对强弱，批次越大越稳；&lt;50 件时仅供参考。<br>` +
      `· 研究显示有效的主要是“短期回调 + 低波动 + 未深跌”的相对规律，且在信号出现后 1–2 天内最强，之后衰减。<br>` +
      `· <b>多重比较</b>：扫几百件取前 20 名，总会有几个事后看起来很准；请看“回测”页的整体统计。<br>` +
      `· 筛选规则同时作用于扫盘、回测和学习；改规则后，已扫描的结果会立即按新规则重新排名。<br>` +
      `· 日K与扫描结果会保存在本机浏览器（用于回测/学习与纸面跟踪），不上传。<br>` +
      `· 请求强度已刻意压低（并发 ${cfg.concurrency} + 抖动 + 退避 + 429 冷却）；若连续失败会自动暂停，请不要调高频率。不自动下单、不读取登录凭据。</div>`;
  }

  // ---- backtest view ---------------------------------------------------------
  function btProgress() {
    return bt.phase === 'running' ? `<div class="row" style="margin-bottom:0"><span class="pill">计算中</span><small id="btMsg">${esc(bt.msg)}</small></div><div class="bar"><i id="btBar" style="width:${(bt.prog * 100).toFixed(1)}%"></i></div>` : '';
  }
  function btView() {
    const cands = reg.candidates.filter(m => modelH(m) === bt.h);
    const r = bt.result;
    let html = `<h3>多商品回测</h3>` + rulesLine() + `<div class="note">用本机样本库里已缓存的日K（来自扫盘/单品页）重放历史：每个采样日按模型给所有“可交易且符合筛选规则”的商品排序（价格按当天收盘判断），次日按悠悠日K收盘入场，持有 N 日，按卖出金额扣费（默认1%，本页未加滑点），对比同期等权样本池与饰品指数（多平台合成，仅作大盘参照）。</div>` +
      `<div class="row"><small>周期</small><select id="btH">${HS.map(h => `<option value="${h}" ${bt.h === h ? 'selected' : ''}>${h}日</option>`).join('')}</select>` +
      `<small>主模型</small><select id="btModel"><option value="active" ${bt.model === 'active' ? 'selected' : ''}>当前启用</option><option value="builtin" ${bt.model === 'builtin' ? 'selected' : ''}>内置默认</option>${cands.map(m => `<option value="${esc(m.id)}" ${bt.model === m.id ? 'selected' : ''}>${esc(m.id)}</option>`).join('')}</select>` +
      `<small>Top</small><input id="btTop" type="number" min="3" max="50" value="${cfg.topN}" style="width:56px"><small>成本%</small><input id="btFee" type="number" min="0" max="10" step="0.1" value="${(cfg.fee * 100).toFixed(1)}" style="width:60px"></div>` +
      `<div class="row"><label class="ck"><input type="checkbox" id="btGate" ${bt.gate ? 'checked' : ''}>大盘分&lt;${cfg.gate}时空仓</label><label class="ck"><input type="checkbox" id="btLab" ${bt.lab ? 'checked' : ''}>对照 lab-2.1（较慢）</label><label class="ck"><input type="checkbox" id="btWf" ${bt.wf ? 'checked' : ''}>滚动训练（评估学习流程，较慢）</label><label class="ck"><input type="checkbox" id="btOos" ${bt.oosOnly ? 'checked' : ''}>只看内置模型训练截止后</label></div>` +
      `<div class="row"><button id="btRun" class="primary" ${bt.phase === 'running' ? 'disabled' : ''}>运行回测</button><button id="btStop" ${bt.phase === 'running' ? '' : 'disabled'}>取消</button>${r ? '<button id="btExport">导出结果 JSON</button>' : ''}</div>` +
      btProgress() + (bt.error ? `<div class="note bad">${esc(bt.error)}</div>` : '');
    if (!r) return html + `<div class="note warn">提示：内置模型用 2023-10→2026-09 的数据训练，在这段时间内回测它属于<b>样本内</b>，成绩会偏好看；原口径历史样本外研究见“学习→模型说明”（未按2.10账务重算），或勾选“滚动训练”。样本库来自你今天扫到的商品，存在幸存者偏差（已经跌没或下架的商品不在里面）。</div>`;
    const prim = r.models[0];
    html += `<p class="sub">样本：${r.items} 件 · ${r.days} 个采样日（每 ${r.step} 天）· ${r.rows} 行 · ${esc(r.first)} → ${esc(r.last)} · ${r.h}日 · 成本 ${pc(r.cost, 1)} · Top${r.topN}${r.gate ? ' · 大盘闸门' : ''}` +
      `<br>筛选规则：${esc(r.rules || '未启用')}${r.ruleStats ? `（按名称排除 ${r.ruleStats.excludedTotal} 件：${esc(reasonsText(r.ruleStats.excludedItems))}；价格不在范围的采样行 ${r.ruleStats.priceRows}）` : ''}</p>` +
      `<div class="scroll"><table><tr><th>模型</th><th>IC</th><th>t</th><th>IC&gt;0</th><th>Q5−Q1</th><th>Top累计</th><th>未解决退出</th><th>回撤</th><th>单笔胜率</th><th>跑赢池</th></tr>` +
      r.models.map(m => `<tr><td>${esc(m.name)}</td><td>${sn(m.ic.mean)}</td><td>${num(m.ic.t, 1)}</td><td>${pc(m.ic.posRate, 0)}</td><td>${spc(m.q.topMinusBottom)}</td><td>${spc(m.pf.top.total, 0)}</td><td>${m.pf.audit.unresolved}</td><td>${pc(m.pf.top.maxDD, 0)}</td><td>${pc(m.pf.top.pickWinRate, 0)}</td><td>${pc(m.pf.beatUniverseRate, 0)}</td></tr>`).join('') +
      `<tr><td><small>等权样本池</small></td><td colspan="4"></td><td>${spc(prim.pf.universe.total, 0)}</td><td></td><td>${pc(prim.pf.universe.maxDD, 0)}</td><td colspan="2"></td></tr><tr><td><small>饰品指数（多平台，不扣费）</small></td><td colspan="4"></td><td>${spc(prim.pf.market.total, 0)}</td><td colspan="4"></td></tr></table></div>` +
      `<p class="sub">IC = 每日“分数排名 vs 之后收益排名”的相关系数均值，t 用不重叠日计算；未解决退出 = 到数据截止仍缺退出报价的持仓；单笔胜率 = 扣成本后赚钱的持仓占比。</p>` +
      (prim.q.incomplete ? `<div class="note warn">分位统计有 ${prim.q.incomplete} 期未来报价不完整，整期未计入平均；这些条件性分位数字不能作为可执行收益。组合模拟则保留缺价持仓，不替换选品。</div>` : '') +
      `<h3>${esc(prim.name)} · 五分位（${r.h}日）</h3><table><tr><th>分位</th><th>样本</th><th>平均净收益</th><th>相对池超额</th><th>中位超额</th><th>跑赢池比例</th></tr>${prim.q.groups.map(g => `<tr><td>Q${g.q}${g.q === 5 ? ' 最高' : g.q === 1 ? ' 最低' : ''}</td><td>${g.n}</td><td>${spc(g.avgNet)}</td><td>${spc(g.avgExcess)}</td><td>${spc(g.medExcess)}</td><td>${pc(g.beatRate, 0)}</td></tr>`).join('')}</table>` +
      `<h3>净值曲线（${esc(prim.name)} Top${r.topN}，目标持有 ${r.h} 日，缺价可延迟退出）</h3>` + curveSvg(prim.pf.curve, { top: 'Top' + r.topN, uni: '等权样本池', mkt: '饰品指数（多平台）' }) +
      `<h3>分年 IC</h3><table><tr><th>年份</th>${r.models.map(m => `<th>${esc(m.name)}</th>`).join('')}</tr>${r.years.map(y => `<tr><td>${y}</td>${r.models.map(m => `<td>${m.ic.byYear && m.ic.byYear[y] ? sn(m.ic.byYear[y].mean) : '—'}</td>`).join('')}</tr>`).join('')}</table>` +
      (prim.ci ? `<p class="sub">${esc(prim.name)} IC 的 95% 区块自助置信区间：[${sn(prim.ci[0])}, ${sn(prim.ci[1])}]</p>` : '') +
      (r.wfFits ? `<p class="sub">滚动训练：${r.wfFits} 次重训，首个样本外日 ${esc(r.wfFirst)}。</p>` : '') +
      `<div class="note warn">怎么读：先看 IC 与 t（排序能力是否稳定），再看 Q5−Q1（高低档差距），最后才看组合累计——组合收益受少数暴涨影响很大，请同时看“未解决退出”、报价覆盖与“单笔胜率”。等权池的简单平均收益会被右偏和报价噪声抬高，绝对收益不可当真，重点看相对池的差距。内置模型在训练期内为样本内结果。</div>`;
    return html;
  }

  // ---- learn view ------------------------------------------------------------
  function gateList(gates) { return gates.map(g => `<span class="${g.pass ? 'good' : 'bad'}">${g.pass ? '✓' : '✗'} ${esc(g.name)}${fin(g.value) ? '（' + (Number.isInteger(g.value) ? g.value : num(g.value, 3)) + '）' : ''}</span>`).join('<br>'); }
  function weightTable(model, base) {
    const bw = new Map((base ? base.features : []).map(f => [f.key, f.w]));
    return `<table><tr><th>因子</th><th>权重</th><th>${base ? '对比当前' : ''}</th></tr>${model.features.slice().sort((a, b) => Math.abs(b.w) - Math.abs(a.w)).map(f => `<tr><td>${esc(F.FEATURE_DEFS[f.key] || f.key)}</td><td class="${f.w > 0 ? 'plus' : 'minus'}">${sn(f.w, 3)}</td><td>${base ? (bw.has(f.key) ? sn(bw.get(f.key), 3) : '新增') : ''}</td></tr>`).join('')}</table>` +
      `<small>正权重 = 该因子越高越加分；负权重 = 越低越加分。权重已按绝对值和为 1 归一化。</small>`;
  }
  function resultCard(h, r) {
    if (!r) return '';
    if (!r.ok) return `<div class="card"><b>${h}日</b>：<span class="warn">${esc(r.reason)}</span></div>`;
    const m = r.model, t = r.test, act = r.active;
    const isActive = reg.active['h' + h] === m.id;
    return `<div class="card ${r.passed ? 'l2' : ''}"><div class="row" style="margin:0;justify-content:space-between"><b>${h}日候选 · ${esc(m.id)}</b>${isActive ? '<span class="pill hit">已启用</span>' : ''}</div>` +
      `<div class="sub">训练 ${esc(m.train.firstDay)}→${esc(m.train.lastDay)}（${m.train.days} 个采样日 · ${m.train.items} 件）· 留出测试 ${esc(m.train.testFirst)}→${esc(m.train.testLast)} · 选中 ${esc(r.selection.best.method)}${r.selection.best.lambda !== null ? ' λ=' + r.selection.best.lambda : ''}（走步验证 IC ${sn(r.selection.best.valIC)}）<br>训练范围：${esc(m.train.rules ? F.rulesText(m.train.rules) : '未启用筛选')}</div>` +
      `<table><tr><th>留出测试期</th><th>IC</th><th>t</th><th>IC&gt;0</th><th>Q5−Q1</th></tr>` +
      `<tr><td>候选</td><td>${sn(t.ic.mean)}</td><td>${num(t.ic.t, 1)}</td><td>${pc(t.ic.posRate, 0)}</td><td>${spc(t.quint.topMinusBottom)}</td></tr>` +
      (act ? `<tr><td>当前启用</td><td>${sn(act.ic.mean)}</td><td>${num(act.ic.t, 1)}</td><td>${pc(act.ic.posRate, 0)}</td><td>${spc(act.quint.topMinusBottom)}</td></tr>` : '') +
      Object.entries(r.baselines || {}).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${sn(v.ic.mean)}</td><td>${num(v.ic.t, 1)}</td><td>${pc(v.ic.posRate, 0)}</td><td>${spc(v.quint.topMinusBottom)}</td></tr>`).join('') + `</table>` +
      `<div class="sub" style="margin:6px 0">${gateList(r.gates)}</div>` +
      `<details><summary>权重与五分位</summary>${weightTable(m, modelOf(h))}<table><tr><th>分位</th><th>样本</th><th>平均净收益</th><th>超额</th><th>中位超额</th><th>跑赢率</th></tr>${t.quint.groups.map(g => `<tr><td>Q${g.q}</td><td>${g.n}</td><td>${spc(g.avgNet)}</td><td>${spc(g.avgExcess)}</td><td>${spc(g.medExcess)}</td><td>${pc(g.beatRate, 0)}</td></tr>`).join('')}</table></details>` +
      `<div class="row">${isActive ? '' : `<button class="primary" data-enable="${esc(m.id)}" data-h="${h}">${r.passed ? '启用此模型' : '强制启用（未过闸门）'}</button>`}<button data-del="${esc(m.id)}">删除候选</button></div>` +
      `<small>${esc(r.note)}</small></div>`;
  }
  function activeBlock() {
    return `<table><tr><th>周期</th><th>当前模型</th><th>样本外 IC</th><th></th></tr>${HS.map(h => {
      const m = modelOf(h), ic = isBuiltin(m) ? m.oos.ic : (m.test && m.test.ic ? m.test.ic.mean : null);
      return `<tr><td>${h}日</td><td style="white-space:normal">${esc(modelName(m))}</td><td>${sn(ic)}</td><td><button data-rb="${h}" ${reg.history.some(e => e.h === h && !e.undone) ? '' : 'disabled'}>回滚</button> <button data-builtin="${h}" ${isBuiltin(m) ? 'disabled' : ''}>恢复内置</button></td></tr>`;
    }).join('')}</table>`;
  }
  function paperBlock() {
    const p = lr.paper;
    let html = `<div class="row"><button id="paperRun">结算纸面跟踪</button><small>扫盘时会记录当天的截面分数；到期后用缓存日K结算（需要之后再扫一次来刷新日K）。</small></div>`;
    if (!p) return html;
    html += p.summary.length ? `<table><tr><th>周期</th><th>已结算批次</th><th>平均IC</th><th>IC&gt;0</th><th>Top档超额</th><th>Bottom档超额</th><th>Top档净收益</th></tr>${p.summary.map(s => `<tr><td>${s.h}日</td><td>${s.snaps}</td><td>${sn(s.ic)}</td><td>${pc(s.icPos, 0)}</td><td>${spc(s.topExcess)}</td><td>${spc(s.bottomExcess)}</td><td>${spc(s.topNet)}</td></tr>`).join('')}</table>` : '<p class="sub">还没有到期可结算的扫盘批次。</p>';
    html += `<p class="sub">待到期/缺数据批次：${p.pending}。这是插件“上线后”真正的向前检验，比任何历史回测都更可信，但需要积累数月。</p>`;
    if (lr.viewsOut && lr.viewsOut.length) html += `<details><summary>我看过的单品之后怎么样（最近 ${lr.viewsOut.length} 条）</summary><table><tr><th>日期</th><th>商品</th><th>周期</th><th>当时分位</th><th>之后净收益</th></tr>${lr.viewsOut.map(v => `<tr><td>${esc(v.day)}</td><td>${esc((v.name || v.id).slice(0, 18))}</td><td>${v.h}日</td><td>${fin(v.pct) ? 'P' + num(v.pct, 0) : '—'}</td><td>${v.matured ? spc(v.net) : '<small>未到期</small>'}</td></tr>`).join('')}</table></details>`;
    return html;
  }
  function settingsBlock() {
    return `<div class="grid3"><label><small>往返成本 %</small><br><input id="setFee" type="number" min="0" max="10" step="0.1" value="${(cfg.fee * 100).toFixed(1)}" style="width:90px"></label>` +
      `<label><small>组合 TopN</small><br><input id="setTop" type="number" min="3" max="50" value="${cfg.topN}" style="width:90px"></label>` +
      `<label><small>大盘闸门阈值</small><br><input id="setGate" type="number" min="0" max="100" value="${cfg.gate}" style="width:90px"></label>` +
      `<label><small>可交易：30日中位量≥</small><br><input id="setLiq" type="number" min="0" max="100" step="1" value="${cfg.minLiq}" style="width:90px"></label>` +
      `<label><small>可交易：零成交比例≤</small><br><input id="setZv" type="number" min="0" max="1" step="0.05" value="${cfg.maxZeroVol}" style="width:90px"></label>` +
      `<label><small>回测/训练采样间隔（天）</small><br><select id="setStep">${[2, 3, 5].map(s => `<option value="${s}" ${cfg.step === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label></div>` +
      `<div class="row"><label class="ck"><input type="checkbox" id="setLog" ${cfg.logSignals ? 'checked' : ''}>记录扫盘截面与单品查看（用于纸面跟踪）</label><button id="setSave">保存设置</button></div>` +
      `<small>默认成本 1% = 悠悠有品卖家手续费 1%（2.5 起所有价格都是悠悠口径）。如果还要算提现费、挂单降价或等待成交的损失，请调高。</small>`;
  }
  function explainBlock() {
    const row = h => { const o = B.models['h' + h].oos; return `<tr><td>${h}日</td><td>${sn(o.ic)}</td><td>${num(o.t, 1)}</td><td>${pc(o.posRate, 0)}</td><td>${o.ci ? '[' + sn(o.ci[0]) + ', ' + sn(o.ci[1]) + ']' : '—'}</td><td>${spc(o.topMinusBottom)}</td><td>${spc(o.quintiles[4].avgExcess)}</td><td>${pc(o.quintiles[4].beatRate, 0)}</td></tr>`; };
    const w = B.models.h14.features.slice().sort((a, b) => Math.abs(b.w) - Math.abs(a.w));
    const c = B.compare || {}, ev = B.evalUniverse || {}, ch = B.choice || {};
    const cmp = k => HS.map(h => sn(c[k] && c[k]['h' + h] ? c[k]['h' + h].ic : null)).join(' / ');
    return `<p class="sub">内置 factor-2.4 选品模型：12 个因子，岭回归（λ=${B.models.h14.lambda}），每 30 天扩窗重训的滚动样本外检验（${esc(B.models.h14.oos.firstDay)} 起）。<b>检验范围 = 默认筛选规则</b>（${esc(B.rulesText || F.rulesText(B.rules))}）：${ev.items || B.universeItems} 件饰品，平均每天 ${num(ev.avgPerDay, 0)} 件可比（悠悠日K，数据抓取于 ${esc(B.dataFetchedAt.slice(0, 10))}）。</p>` +
      `<table><tr><th>周期</th><th>IC</th><th>t</th><th>IC&gt;0</th><th>95%CI</th><th>Q5−Q1超额</th><th>Q5超额</th><th>Q5跑赢率</th></tr>${HS.map(row).join('')}</table>` +
      (c.V1 ? `<p class="sub">训练方式对比（样本外 IC，7 / 14 / 30 日，同一段时间、同一批范围内商品）：只用范围内商品训练 ${cmp('V1')}；用全部可交易商品训练 ${cmp('V0')} → 采用<b>${ch.chosen === 'V0' ? '全部商品训练' : '范围内训练'}</b>（选择规则事先约定：除非全部商品训练的平均 IC 高出 0.005 以上，否则用范围内训练）。对照：2.3 口径（全部 ${ev.allTradableItems || '—'} 件可交易饰品，含刀/StatTrak/纪念品/其他磨损）为 ${cmp('sanityAll')}。</p>` : '') +
      `<p class="sub">14日模型的主要因子：${w.slice(0, 8).map(f => (f.w > 0 ? '＋' : '－') + esc(F.FEATURE_DEFS[f.key])).join('、')}。一句话：偏好“低波动、未深跌、处于自身区间低位、刚短期回调”的饰品，回避“刚暴涨、波动放大”的饰品。</p>` +
      `<p class="sub">对照：旧 lab-2.1 入场分、30日动量在同样检验中的 IC 为负或接近 0。大盘层：大盘状态分对指数未来收益的 IC 约 ${num(B.regimeEvidence.icIndex.h14, 2)}（样本少，仅作风险提示）。详见扩展目录中的 RESEARCH_REPORT.md（第 9 节是按筛选规则的重新验证）。</p>`;
  }
  function learnView() {
    const s = lr.stats;
    return `<h3>半自动学习</h3><div class="note warn">2.10.0 已修订组合账务；内置历史研究数字未重新计算。新增实验只在实验室运行，不会自动启用。所有收益仍为报价代理，非真实成交。</div>` + rulesLine() + `<div class="note">流程：扫盘/看单品时日K自动存入本机样本库 → 点“训练候选模型” → 插件只用<b>符合筛选规则</b>的样本（价格按当天判断），用走步验证选参数，并在<b>最后一段从未参与训练的时间</b>上检验 → 通过闸门后<b>由你确认启用</b> → 随时一键回滚或恢复内置。不会自动改动正在使用的模型。</div>` +
      `<h3>样本库</h3><div class="row"><button id="stRefresh">刷新统计</button><small>${s ? `${s.items} 件 · ${esc(s.first || '—')} → ${esc(s.last || '—')} · 今日新鲜 ${s.fresh} 件 · 占用 ${fin(s.bytes) ? (s.bytes / 1048576).toFixed(1) + 'MB' : '—'}` : '未统计'}</small></div>` +
      `<h3>当前启用</h3>${activeBlock()}` +
      `<h3>训练候选模型</h3><div class="row"><small>周期</small><select id="lrH"><option value="all" ${lr.trainH === 'all' ? 'selected' : ''}>7/14/30 全部</option>${HS.map(h => `<option value="${h}" ${lr.trainH === String(h) ? 'selected' : ''}>${h}日</option>`).join('')}</select><small>因子集</small><select id="lrSet">${Object.keys(KEYSETS).map(k => `<option value="${k}" ${cfg.featureSet === k ? 'selected' : ''}>${k}（${KEYSETS[k].length}）</option>`).join('')}</select><button id="lrRun" class="primary" ${lr.phase === 'running' ? 'disabled' : ''}>训练候选模型</button></div>` +
      (lr.phase === 'running' ? `<div class="row" style="margin-bottom:0"><span class="pill">训练中</span><small id="lrMsg">${esc(lr.msg)}</small></div><div class="bar"><i id="lrBar" style="width:${(lr.prog * 100).toFixed(1)}%"></i></div>` : '') +
      (lr.error ? `<div class="note bad">${esc(lr.error)}</div>` : '') + (lr.info ? `<div class="note">${esc(lr.info)}</div>` : '') +
      `<small>要求：至少约 120 个采样日、每日 ≥30 件符合规则的可交易商品有到期收益（建议先在“今日买点”把白名单扫一次，规则内约 ${whitelistView().kept} 件；隔天再扫只补增量）。闸门：样本外 IC≥0.02、t≥2、相对验证期衰减≤50%、测试期≥40 个采样日、不差于当前启用模型。</small>` +
      HS.map(h => resultCard(h, lr.results[h])).join('') +
      (reg.candidates.length ? `<details><summary>全部候选（${reg.candidates.length}）</summary><table><tr><th>ID</th><th>周期</th><th>测试IC</th><th>闸门</th><th></th></tr>${reg.candidates.map(m => `<tr><td style="white-space:normal">${esc(m.id)}</td><td>${modelH(m)}日</td><td>${sn(m.test && m.test.ic ? m.test.ic.mean : null)}</td><td>${m.gatesPassed ? '<span class="good">通过</span>' : '<span class="bad">未过</span>'}${m.train && m.train.rulesKey && m.train.rulesKey !== rkey() ? '<br><small class="warn">训练时规则不同</small>' : ''}</td><td>${reg.active['h' + modelH(m)] === m.id ? '<span class="pill hit">启用中</span>' : `<button data-enable="${esc(m.id)}" data-h="${modelH(m)}">启用</button> <button data-del="${esc(m.id)}">删</button>`}</td></tr>`).join('')}</table></details>` : '') +
      (reg.history.length ? `<details><summary>变更历史（${reg.history.length}）</summary>${reg.history.slice(0, 30).map(e => `<div class="sub">${esc(e.at.slice(0, 16).replace('T', ' '))} · ${e.h}日：${esc(e.from || '内置')} → ${esc(e.to || '内置')} ${esc(e.note || '')}</div>`).join('')}</details>` : '') +
      `<h3>纸面跟踪（向前检验）</h3>${paperBlock()}` +
      `<details><summary>设置</summary>${settingsBlock()}</details>` +
      `<details><summary>数据管理</summary><div class="row"><button id="exAll">导出模型/设置/记录</button><button id="exK">导出（含日K样本库）</button><button id="exBackup">导出上次导入前备份</button><label class="ck"><small>导入</small><input type="file" id="imFile" accept=".json,application/json"></label></div><div class="row"><button id="clrK" class="danger">清空日K样本库</button><button id="rstAll" class="danger">全部重置</button></div><small>数据保存在 chrome.storage.local（${ST.persistent ? '已启用持久化' : '当前为内存模式，刷新即丢失'}）。</small></details>` +
      `<details><summary>模型说明（内置默认）</summary>${explainBlock()}</details>` +
      `<div class="note warn">通过闸门只说明“在留出的那段历史里有效”，不保证未来有效；市场结构变化（如 2025-10 的合成规则更新）会让任何模型失效。启用后请观察纸面跟踪，必要时回滚。</div>`;
  }

  // ---- isolated experiment lab ------------------------------------------------
  async function refreshExperiment() { exp.state=await ST.researchState(); if(!exp.result)exp.result=exp.state.latest; }
  function experimentView() {
    const r=exp.result,st=exp.state||{};
    let html='<h3>实验室 · 仅影子运行</h3><div class="note">正式买点仍使用原模型。这里比较原内置参考、原因子重训岭回归、新因子岭回归、深度2提升树；不提供自动启用入口。新增六个因子：同类20日相对动量、同类上涨宽度、不变价、低量跳价、零量比例、近期量变化。</div>';
    html+=`<div class="row"><label>持有 <select id="expH" ${exp.busy?'disabled':''}>${[14,30].map(h=>`<option value="${h}" ${exp.h===h?'selected':''}>${h}天</option>`).join('')}</select></label><button id="expRun" class="primary" ${exp.busy?'disabled':''}>运行固定协议对照</button><button id="expStop" ${exp.busy?'':'disabled'}>取消</button></div>`;
    html+='<small>仅用本机日K，不自动拉全池历史；先在今日买点完成扫描。60/20/20时间分段，边界隔离持有期；仅验证集选参数，测试集不重拟合。Top10、同类≤30%、同系列≤10%，未选满留现金。训练每日期最多128件确定性抽样。重复看测试结果不再是独立检验。</small>';
    html+=`<p id="expMsg" class="sub">${esc(exp.message)}</p>${exp.error?`<div class="note bad">${esc(exp.error)}</div>`:''}`;
    if(r){html+=`<h3>冻结实验 ${esc(r.id)}</h3><small>数据截止 ${esc(r.provenance.asOf)} · ${r.provenance.items}件 · ${r.provenance.rows}条 · 标签覆盖：训练${pc(r.provenance.trainingLabelCoverage,1)} / 验证${pc(r.provenance.validationLabelCoverage,1)} / 测试${pc(r.provenance.testLabelCoverage,1)}<br>训练 ${esc(r.split.train[0])} → ${esc(r.split.train.at(-1))}<br>验证 ${esc(r.split.validation[0])} → ${esc(r.split.validation.at(-1))}<br>测试 ${esc(r.split.test[0])} → ${esc(r.split.test.at(-1))}</small>`;
      html+='<div class="scroll"><table><tr><th>模型</th><th>测试IC</th><th>独立窗口</th><th>净收益</th><th>日估值回撤</th><th>压力净收益</th><th>未解决退出</th></tr>'+r.reports.map(x=>`<tr><td style="white-space:normal">${esc(x.name)}</td><td>${sn(x.ic.mean)}</td><td>${x.ic.nonOverlap||0}</td><td>${spc(x.base.top.total)}</td><td>${pc(x.base.top.maxDD)}</td><td>${spc(x.stress.top.total)}</td><td>${x.base.audit.unresolved}</td></tr>`).join('')+'</table></div>';
      html+='<div class="note warn">手续费1%与3%两档，买卖各0.3%冲击是假设。没有退出报价的持仓保留未解决状态，不能用另一件商品补位；累计收益显示“—”。缺日估值沿用最近报价，报价不等于可成交。内置历史权重可能见过测试期，不作为公平胜负判据。独立窗口少于12个时，仅作探索。</div>';
      html+='<details><summary>执行诊断与冻结协议</summary>'+r.reports.map(x=>`<p class="sub">${esc(x.name)}：调仓${x.base.periods}批 · 未入场${x.base.audit.unfilled}笔 · 延迟退出${x.base.audit.delayed}笔 · 未解决${x.base.audit.unresolved}笔 · 实际跨度${x.base.top.elapsedDays}天 · 平均现金${pc(x.base.meanCashWeight,0)} · 最大3笔占已实现正利润${pc(x.base.positiveProfitTop3Share,0)}</p>`).join('')+`<small>模型SHA256 ${esc(r.provenance.modelHash)}<br>数据SHA256 ${esc(r.provenance.dataHash)}<br>浅层树为本地实现的深度2梯度提升回归树，不是LightGBM；最多30棵，树数只由验证集选择。</small></details>`;
    }
    html+=`<h3>前向数据与影子记录</h3><label class="ck"><input id="expCapture" type="checkbox" ${exp.busy?'disabled':''} ${cfg.researchCapture?'checked':''}>记录新读取的悠悠报价（本机，默认关闭）</label><p class="sub">报价${st.quotes||0}条 · 影子${st.shadows||0}批 · 冻结实验${st.experiments||0}份。此开关不增加后台轮询；下面的按钮会额外读取影子选品报价。</p><div class="row"><button id="expShadow" ${exp.busy||!r?'disabled':''}>采集报价并冻结今日影子</button><button id="expSettle" ${exp.busy?'disabled':''}>结算影子记录</button><button id="expExport">单独导出研究JSON</button><button id="expClear" class="danger" ${exp.busy?'disabled':''}>清空研究档案</button></div><small>影子快照每实验/信号日只保留第一份，不回写后来的价格；没有当时报价就保持未定价。结算按实际采集的在售价入场，用之后日K作退出代理，不与历史测试拼成收益曲线。未做相关性聚类，仅固定同类/同系列限额。影子与实验组合不执行正式大盘闸门，仅附记大盘状态；弱市记录也不是买入建议。</small>`;
    if(exp.outcomes){html+='<details open><summary>前向批次结果（不年化、不复利）</summary><div class="scroll"><table><tr><th>记录日/模型</th><th>净收益</th><th>待退出</th><th>缺买价</th></tr>'+exp.outcomes.slice(-30).flatMap(x=>x.arms.map(a=>`<tr><td style="white-space:normal">${esc(x.capturedAt.slice(0,10))}<br>${esc(a.name)}</td><td>${spc(a.net)}</td><td>${a.pending}</td><td>${a.missingAsk}</td></tr>`)).join('')+'</table></div></details>';}
    return html+'<div class="note warn">普通模型/持仓备份不包含研究档案，请使用上方专用导出；复现训练还需另存含日K的普通备份。采集只覆盖已读取的单品、正式/影子选品，并非无偏全市场供需面板。最多10份实验、200批影子、20000条报价，达到上限拒绝新增，不静默删除。研究JSON目前仅供归档/外部复核，不支持在界面重新导入或启用。</div>';
  }
  function experimentProgress(message,fraction) { exp.message=message+' · '+Math.round(fraction*100)+'%';const el=root.getElementById('expMsg');if(el)el.textContent=exp.message; }
  async function runExperiment() {
    if(exp.busy||scanBusy()||busy||lr.phase==='running'||bt.phase==='running'){exp.error='请先等待扫描、单品或其他研究任务完成';render();return;}
    const opts={h:exp.h,topN:10,rules:F.normRules(cfg.rules),tradable:{minLiq:cfg.minLiq,maxZeroVol:cfg.maxZeroVol}};
    exp.busy=true;exp.error='';exp.ctrl=new AbortController();render();
    try {
      const all=await ST.allK(),dir=await ST.directory(),allowed=new Set(S.resolvePlan(WL.ITEMS,dir).items.map(it=>String(it.id))),items=all.filter(it=>allowed.has(String(it.id)));
      if(items.length<30)throw Error('本机白名单日K不足30件，请先完成扫描。');
      const market=await ST.getMarket();if(!market||!market.series.ok)throw Error('缺少本机大盘历史，请先完成扫描。');
      const P=await F.buildPanelAsync(items,market.series,{keys:B.keys,step:3,horizons:[opts.h],lag:1,skipLab:true,minItemsPerDay:30,rules:opts.rules,tradable:opts.tradable},(a,b)=>experimentProgress('构建历史截面',.15*a/b),exp.ctrl.signal);
      const result=await EM.run(P,B.models['h'+opts.h],B.keys,{...opts,signal:exp.ctrl.signal,onProgress:experimentProgress});
      if(exp.ctrl.signal.aborted)throw Error('实验已取消');
      exp.result=await ST.saveExperiment(result);await refreshExperiment();exp.message='已冻结并保存。正式模型未修改；先看独立窗口和诊断，不按单一收益选模型。';
    } catch(e){exp.error=e.message;}finally{exp.busy=false;exp.ctrl=null;render();}
  }
  async function captureShadow() {
    if(exp.busy||scanBusy())return;
    if(!cfg.researchCapture){exp.error='请先开启本机研究采集，再采集影子报价。';render();return;}
    if(!scanComplete()||!scan.cross||!BY.fresh(scan.cross.day,BY.bjDay())){exp.error='请在本页完成同规则、当前决策日的完整扫描。';render();return;}
    const result=exp.result;if(!result){exp.error='请先运行并冻结一个实验。';render();return;}
    exp.busy=true;exp.error='';exp.ctrl=new AbortController();render();
    try {
      const generation=scan.generation,day=F.dayNumOf(scan.cross.day),items=scan.rows.filter(r=>scan.series.has(String(r.id))).map(r=>({id:String(r.id),name:r.name,family:r.family,series:scan.series.get(String(r.id))}));
      const P=F.buildPanel(items,mkt&&mkt.series,{keys:B.keys,step:1,horizons:[result.h],startDay:day,endDay:day,minItemsPerDay:30,rules:F.normRules(cfg.rules),tradable:{minLiq:cfg.minLiq,maxZeroVol:cfg.maxZeroVol},skipLab:true});
      const provisional=await EM.shadow(P,result,[],exp.ctrl.signal),existing=(await ST.shadowRecords()).find(x=>x.experimentId===result.id&&x.day===provisional.day);
      if(existing){exp.message='该实验今天已有首份影子快照，未覆盖、未补写后来的报价。';return;}
      const ids=[...new Set(provisional.arms.flatMap(a=>a.picks.map(p=>p.id)))].slice(0,60),observations=[];
      net.setBudget(exp.ctrl.signal,60);
      for(let n=0;n<ids.length;n++){
        const id=ids[n];let q=quotes.get(id);
        if(!q||!q.ok||!q.at||Date.now()-Date.parse(q.at)>S.DEFAULTS.quoteTtlMs){try{const y=S.youpinQuote(await apiRetry('/v1/market/facade/quote/detail_price_compare',{id},exp.ctrl.signal,2));q={ok:y.ok,price:y.ok?y.price:null,count:y.ok?y.count:null,at:new Date().toISOString(),day:BY.bjDay()};quotes.set(id,q);}catch(e){if(exp.ctrl.signal.aborted||e.budget)throw e;q=null;}}
        if(q&&q.ok){const r=scan.rows[scan.rowIdx.get(id)];observations.push({id,observedAt:q.at,ask:q.price,count:q.count>=0?q.count:null,close:r&&fin(r.close)?r.close:null,signalDay:scan.cross.day});}
        experimentProgress('影子报价 '+(n+1)+'/'+ids.length,(n+1)/Math.max(1,ids.length));await sleep(150);
      }
      if(exp.ctrl.signal.aborted||generation!==scan.generation)throw Error('扫描已变更，未冻结影子');
      const snap=await EM.shadow(P,result,Array.from(quotes,([id,q])=>({id,...q})),exp.ctrl.signal);snap.marketScore=liveRegime(scan.cross.day)?.score??null;snap.gateAllowed=snap.marketScore!==null&&snap.marketScore>=cfg.gate;
      await ST.addResearchQuotes(observations);await ST.addShadow(snap);await refreshExperiment();exp.message='首份影子已冻结，仅记录，不下单。缺少买入报价的商品不会用未来报价补填。';
    }catch(e){exp.error=e.message;}finally{exp.busy=false;exp.ctrl=null;render();}
  }
  async function settleResearch() {
    if(exp.busy)return;exp.busy=true;exp.error='';render();
    try{const records=await ST.shadowRecords(),ids=[...new Set(records.flatMap(s=>s.arms.flatMap(a=>a.picks.map(p=>p.id))))],data=await ST.getKMany(ids),map=new Map(Array.from(data,([id,r])=>[id,r&&r.series]));exp.outcomes=records.map(s=>EM.settleShadow(s,map));exp.message='仅用当前本机日K结算；没有新数据请先扫描。结果为独立影子批次，不代表账户收益。';}catch(e){exp.error=e.message;}finally{exp.busy=false;render();}
  }

  // ---- render -----------------------------------------------------------------
  function render() {
    const canItem = !!identity;
    if (!canItem && tab === 'item') tab = 'buy';
    if (!opened) {
      root.innerHTML = `<style>${css}</style><button class="launch" id="open">◈ 饰品买点 ${VERSION} · ${canItem ? '单品买点' : '今日买点'}</button>`;
      bind();
      return;
    }
    const tabs = [['buy', '今日买点'], canItem ? ['item', '单品'] : null, ['hold', '我的持仓'], ['adv', '高级']].filter(Boolean);
    const on = t => (t === 'adv' ? isAdv(tab) : tab === t);
    const body = !ready ? '<p class="sub">读取本地数据…</p>' : tab === 'buy' ? buyView() : tab === 'item' ? itemView() : tab === 'hold' ? holdView() :
      advNav() + (tab === 'scan' ? scanView() : tab === 'bt' ? btView() : tab === 'exp' ? experimentView() : learnView());
    root.innerHTML = `<style>${css}</style><section class="panel"><header><div><small>MARKET LENS LAB ${VERSION} · 研究用途 · 不自动交易</small><h2>饰品买点</h2>` +
      `<div class="tabs">${tabs.map(t => `<button class="tab ${on(t[0]) ? 'on' : ''}" data-tab="${t[0]}">${t[1]}</button>`).join('')}</div>` +
      `</div><button id="close">收起</button></header><div class="body">${manualView()}${body}</div></section>`;
    bind();
  }
  function updateProgress() {
    const t = root.getElementById('progText'), b = root.getElementById('progBar');
    const p = scan.progress;
    if (t) t.textContent = progressText();
    if (b) b.style.width = (p.total ? Math.min(100, p.done / p.total * 100) : 0).toFixed(1) + '%';
  }
  // Throttled live refresh of the results block while a scan runs (the rest
  // of the panel, including inputs, is left alone).
  function liveRender(force) {
    const now = Date.now(), every = S.DEFAULTS.liveMs;
    if (!force && now - scan.liveAt < every) {
      if (!scan.liveTimer) scan.liveTimer = setTimeout(() => { scan.liveTimer = null; liveRender(true); }, every - (now - scan.liveAt) + 10);
      return;
    }
    scan.liveAt = now;
    if (scan.liveTimer) { clearTimeout(scan.liveTimer); scan.liveTimer = null; }
    applyCross(false);
    const el = root.getElementById('liveResults');
    if (!el) return;
    el.innerHTML = tab === 'buy' ? liveBuyHtml() : tab === 'scan' ? liveScanHtml() : '';
    bindLive(el);
  }
  // Handlers for the live block (also used by bind() for the whole panel).
  function bindLive(scope) {
    scope.querySelectorAll('[data-manual-id]').forEach(e=>e.addEventListener('click',()=>{const r=scan.rows.find(x=>String(x.id)===e.dataset.manualId);if(r){const rec=currentRec();openManual(r,signalFor(r,rec,rec&&rec.picks.find(p=>String(p.id)===String(r.id))).summary+'；自主买入，非模型推荐。');}}));
    scope.querySelectorAll('[data-buy]').forEach(e => e.addEventListener('click', () => recordBuyFromScan(e.dataset.buy)));
    const on = (id, ev, fn) => { const e = scope.querySelector('#' + id); if (e) e.addEventListener(ev, fn); };
    on('learningBox','toggle',e=>{learningOpen=e.target.open;});
    for(const [id,action] of [['learningCapture','capture'],['learningSettle','settle'],['learningJson','json'],['learningCsv','csv'],['learningClear','clear']])on(id,'click',()=>learningAction(action));
    on('sortKey', 'change', e => { scan.sortKey = e.target.value; liveRender(true); });
    on('sortDir', 'click', () => { scan.sortDir = scan.sortDir === 'desc' ? 'asc' : 'desc'; liveRender(true); });
    on('showMore', 'click', () => { scan.shown += 300; liveRender(true); });
    on('quoteRefresh', 'click', () => quotePicks(true));
    scope.querySelectorAll('.hsel button').forEach(e => e.addEventListener('click', () => setH(Number(e.dataset.h))));
  }
  function setProg(obj, msg, frac, ids) {
    obj.msg = msg; obj.prog = frac;
    const m = root.getElementById(ids[0]), b = root.getElementById(ids[1]);
    if (m) m.textContent = msg;
    if (b) b.style.width = (frac * 100).toFixed(1) + '%';
  }

  function bind() {
    const on = (id, ev, fn) => { const e = root.getElementById(id); if (e) e.addEventListener(ev, fn); };
    const all = (sel, fn) => root.querySelectorAll(sel).forEach(fn);
    on('open', 'click', () => { opened = true; render(); if (tab === 'item' && identity && !payload && !busy) loadItem(); });
    on('close', 'click', () => { opened = false; render(); });
    all('[data-tab]', e => e.addEventListener('click', () => {
      const t = e.dataset.tab;
      tab = t === 'adv' ? advTab : t;
      if (isAdv(tab)) advTab = tab;
      render();
      if (tab === 'item' && identity && !payload && !busy) loadItem();
      if (tab === 'exp') refreshExperiment().then(render).catch(e => { exp.error=e.message; render(); });
      if (tab === 'learn' && !lr.stats) refreshStats();
      if (tab === 'hold') loadHoldings().then(render);
    }));
    bindLive(root);   // 记为已买入 / 排序 / 持有周期 / 刷新在售价 (shared with the live block)
    // 今日买点
    all('.bsel button', e => e.addEventListener('click', () => { setH(Number(e.dataset.bh)); }));
    on('buyManual','click',()=>openManual(null));on('holdManual','click',()=>openManual(null));
    on('itemManual','click',()=>openManual(identity?{id:identity.id,name:fields?.title||''}:null,root.getElementById('verdict')?.innerText||'单品判断未取得，自主买入，非模型推荐。'));
    on('manualCancel','click',()=>{if(!manual.busy){manual.open=false;render();}});on('manualForm','submit',saveManual);
    all('[data-manual]',e=>e.addEventListener('input',()=>{manual.draft[e.dataset.manual]=e.value;}));
    on('entryStudyBox','toggle',e=>{entryStudyOpen=e.target.open;});on('entryCapture','click',captureEntry);on('entryExport','click',exportEntries);
    on('entryClear','click',async()=>{entryStudyOpen=true;if(!ask('仅清空入场A/B/C档案，不清持仓、模型或日K。此操作不能撤销，请先导出。继续？'))return;try{await ST.clearEntryStudies();entryMessage='入场对照档案已清空，持仓和模型未改动。';}catch(e){entryMessage=e.message;}render();});
    for(const [attr,key] of [['hbf','buyFee'],['hsf','sellFee']])all('[data-'+attr+']',e=>e.addEventListener('change',()=>{const v=e.value===''&&key==='sellFee'?null:Number(e.value);if(v!==null&&(!Number.isFinite(v)||v<0)){e.value=e.defaultValue;return;}editHolding(e.dataset[attr],{[key]:v});}));
    on('buyScan', 'click', runScan);
    on('buyGoAdv', 'click', () => { tab = advTab = 'scan'; render(); });
    on('itemBuy', 'click', recordBuyFromItem);
    on('goBuy', 'click', () => { tab = 'buy'; render(); });
    on('useCache', 'change', e => { cfg.useCache = e.target.checked; });
    // 我的持仓
    on('holdRefresh', 'click', refreshHoldPrices);
    all('[data-hsell]', e => e.addEventListener('click', () => sellHolding(e.dataset.hsell)));
    all('[data-hdel]', e => e.addEventListener('click', () => deleteHolding(e.dataset.hdel)));
    all('[data-hreopen]', e => e.addEventListener('click', () => editHolding(e.dataset.hreopen, { status: 'open', sellDay: null, sellPrice: null, sellFee:null })));
    const numIn = (sel, key) => all(sel, e => e.addEventListener('change', () => {
      const v = Number(e.value);
      if (!(v > 0)) { e.value = e.defaultValue; return; }
      editHolding(e.dataset[key], { [key === 'hbp' ? 'buyPrice' : key === 'hqty' ? 'qty' : 'sellPrice']: key === 'hqty' ? Math.round(v) : v });
    }));
    numIn('[data-hbp]', 'hbp'); numIn('[data-hqty]', 'hqty'); numIn('[data-hsp]', 'hsp');
    // item
    on('refresh', 'click', loadItem);
    on('export', 'click', exportItem);
    on('lookDate', 'change', e => { lookDate = e.target.value; look = null; });
    on('lookBtn', 'click', () => { look = lookAt(lookDate); render(); });
    on('date', 'change', e => { date = e.target.value; historical = outcomes = null; render(); });
    on('step', 'change', e => { step = e.target.value; });
    on('history', 'click', () => { historical = N.historical(payload, date); outcomes = null; render(); });
    on('outcomes', 'click', () => { outcomes = L.historicalOutcomes(payload, date); render(); });
    on('batch', 'click', async () => {
      const token = epoch; working = true; render();
      try { const b = await N.backtest(payload, { step: Number(step) }); if (token === epoch) batch = b; }
      catch (e) { if (token === epoch) itemError = e.message; }
      finally { if (token === epoch) { working = false; render(); } }
    });
    // rules
    on('goRules', 'click', () => { tab = advTab = 'scan'; rulesOpen = true; render(); });
    on('rulesBox', 'toggle', e => { rulesOpen = e.target.open; });
    on('ruSave', 'click', () => saveRules(false));
    on('ruReset', 'click', () => saveRules(true));
    // scan (速度设置 persists; 缓存开关 is per session like 2.6.1)
    on('setConc', 'change', e => { cfg.concurrency = Math.max(2, Math.min(4, Number(e.target.value) || 3)); ST.saveSettings({ concurrency: cfg.concurrency }); render(); });
    on('setDepth', 'change', e => { cfg.kDepth = Number(e.target.value) === 1440 ? 1440 : 720; ST.saveSettings({ kDepth: cfg.kDepth }); render(); });
    on('useCache2', 'change', e => { cfg.useCache = e.target.checked; });
    on('scanRun', 'click', runScan);
    on('deepReview', 'click', runDeepReview);
    on('scanPause', 'click', () => { if (scan.phase === 'deep') { scan.pause = true; scan.note = '正在暂停（等待进行中的请求结束）…'; render(); } });
    on('scanStop', 'click', () => { scan.pause = true; if (scan.abort) scan.abort.abort(); if (qs.abort) qs.abort.abort(); scan.phase = scan.rows.length ? 'done' : 'idle'; scan.note = '已手动停止，结果与日K缓存已保留。'; render(); });
    on('scanCsv', 'click', () => download('market-lens-scan-' + Date.now() + '.csv', S.toCSV(signalExportRows()), 'text/csv'));
    on('scanJson', 'click', () => download('market-lens-scan-' + Date.now() + '.json', JSON.stringify(Object.assign(S.report({
      config: { whitelist: WL.COUNT, whitelistVersion: WL.VERSION, concurrency: cfg.concurrency, kDepth: cfg.kDepth, useCache: cfg.useCache }, plan: scan.plan, modelVersion: N.VERSION, universe: scan.universe, rows: signalExportRows(),
      timing: { startedAt: scan.startedAt, finishedAt: scan.finishedAt, requests: scan.progress.requests, cached: scan.progress.cached, tail: scan.progress.tail, full: scan.progress.full },
    }), { factor: { version: F.VERSION, h: cfg.h, model: modelOf(cfg.h).id, cross: scan.cross }, rules: cfg.rules, rulesText: F.rulesText(cfg.rules), quotesAt: qs.at }), null, 2)));
    on('scanReset', 'click', () => {
      if (scanBusy()) return;
      Object.assign(scan, { phase: 'idle', universe: null, rows: [], rowIdx: new Map(), plan: null, coverage: '', resolved: null, queue: [], cursor: 0, error: '', note: '', autoPaused: '', startedAt: null, finishedAt: null, cross: null,
        progress: { done: 0, total: 0, ok: 0, fail: 0, requests: 0, cached: 0, tail: 0, full: 0, netMs: 0, netN: 0 } });
      scan.series = new Map(); quotes.clear(); Object.assign(qs, { done: 0, total: 0, at: null, msg: '' });
      render();
    });
    // backtest
    on('btH', 'change', e => { bt.h = Number(e.target.value); bt.model = bt.model === 'active' || bt.model === 'builtin' ? bt.model : 'active'; render(); });
    on('btModel', 'change', e => { bt.model = e.target.value; });
    on('btTop', 'change', e => { cfg.topN = Math.max(3, Math.min(50, Number(e.target.value) || 10)); });
    on('btFee', 'change', e => { cfg.fee = Math.max(0, Math.min(0.1, (Number(e.target.value) || 0) / 100)); });
    on('btGate', 'change', e => { bt.gate = e.target.checked; });
    on('btLab', 'change', e => { bt.lab = e.target.checked; });
    on('btWf', 'change', e => { bt.wf = e.target.checked; });
    on('btOos', 'change', e => { bt.oosOnly = e.target.checked; });
    on('btRun', 'click', runBacktest);
    on('btStop', 'click', () => { if (bt.abort) bt.abort.abort(); });
    on('btExport', 'click', () => download('market-lens-backtest-' + Date.now() + '.json', JSON.stringify(bt.result, (k, v) => (k === 'detail' ? undefined : v), 2)));
    on('expH','change',e=>{exp.h=Number(e.target.value);});
    on('expRun','click',runExperiment);
    on('expStop','click',()=>{if(exp.ctrl)exp.ctrl.abort();});
    on('expCapture','change',async e=>{cfg.researchCapture=e.target.checked;await ST.saveSettings({researchCapture:cfg.researchCapture});render();});
    on('expShadow','click',captureShadow);
    on('expSettle','click',settleResearch);
    on('expExport','click',async()=>download('market-lens-research-'+Date.now()+'.json',JSON.stringify(await ST.exportResearch())));
    on('expClear','click',async()=>{if(exp.busy||!ask('确认清空实验、报价和影子档案？请先单独导出研究JSON。不会影响正式模型或持仓。'))return;await ST.clearResearch();exp.result=null;exp.outcomes=null;await refreshExperiment();render();});
    // learn
    on('stRefresh', 'click', refreshStats);
    on('lrH', 'change', e => { lr.trainH = e.target.value; });
    on('lrSet', 'change', e => { cfg.featureSet = e.target.value; ST.saveSettings({ featureSet: cfg.featureSet }); });
    on('lrRun', 'click', runTrain);
    all('[data-enable]', e => e.addEventListener('click', () => enableModel(Number(e.dataset.h), e.dataset.enable)));
    all('[data-del]', e => e.addEventListener('click', () => deleteModel(e.dataset.del)));
    all('[data-rb]', e => e.addEventListener('click', () => regOp(() => ST.rollback(Number(e.dataset.rb)), '已回滚 ' + e.dataset.rb + ' 日模型')));
    all('[data-builtin]', e => e.addEventListener('click', () => regOp(() => ST.activate(Number(e.dataset.builtin), null, '恢复内置'), '已恢复内置 ' + e.dataset.builtin + ' 日模型')));
    on('paperRun', 'click', runPaper);
    on('setSave', 'click', saveSettingsFromDom);
    on('exBackup', 'click', async () => { try { const b = await ST.exportBackup(); if (!b) throw Error('还没有导入前备份'); download('market-lens-before-import-' + Date.now() + '.json', JSON.stringify(b)); } catch (e) { lr.error = e.message; render(); } });
    on('exAll', 'click', async () => download('market-lens-lab-data-' + Date.now() + '.json', JSON.stringify(await ST.exportAll({}), null, 1)));
    on('exK', 'click', async () => download('market-lens-lab-full-' + Date.now() + '.json', JSON.stringify(await ST.exportAll({ includeK: true }))));
    on('imFile', 'change', e => importFile(e.target.files && e.target.files[0]));
    on('clrK', 'click', async () => { if (!ask('确定清空本机日K样本库？（模型与记录保留）')) return; await ST.clearK(); bt.panel = null; bt.panelKey = ''; await refreshStats(); });
    on('rstAll', 'click', async () => { if (!ask('确定全部重置？将删除样本库、学习到的模型、设置与记录，恢复内置模型。')) return; await ST.resetAll(); await loadState(); lr.results = {}; lr.paper = null; bt.panel = null; bt.result = null; await refreshStats(); });
  }
  function setH(h) {
    if (!HS.includes(h) || cfg.h === h) return;
    cfg.h = h; ST.saveSettings({ h });
    if (series) fx = computeFactor();
    if (scan.rows.length) applyCross();
    render();
    // The picks differ per horizon: read the asks still missing for the new list (TTL-bounded, ≤ maxQuotes).
    if (scan.phase === 'done' && !qs.busy && tab === 'buy') quotePicks(false);
  }

  // ---- item mode -----------------------------------------------------------
  function computeFactor() {
    if (!series || !series.ok) return null;
    const m = mkt ? mkt.series : null;
    const i = F.lastUsableIndex(series);
    const out = { regime: i >= 0 ? liveRegime(F.dayStr(series.day0 + i)) : null, byH: {} };
    for (const h of HS) {
      const model = modelOf(h), sc = F.scoreAt(series, m, model);
      if (!sc.ok) { out.byH[h] = { ok: false, reason: sc.reason }; continue; }
      const ref = refFor(h, model), pct = ref ? F.percentileOf(sc.score, ref.sorted) : null, bucket = F.bucketOf(pct);
      out.byH[h] = { ok: true, sc, ref, pct, bucket, calib: calibFor(model, h, bucket), why: F.explain(sc.parts, 6), tradable: tradableF(sc.f) };
    }
    out.own = F.ownHistory(series, m, modelOf(cfg.h), { lookback: 365, step: 3 });
    return out;
  }
  function lookAt(str) {
    if (!series || !str) return { ok: false, reason: '请选择日期' };
    const d = F.dayNumOf(str), m = mkt ? mkt.series : null, model = modelOf(cfg.h);
    if (!(d >= series.day0 && d < series.day0 + series.n)) return { ok: false, reason: '日期不在日K范围内' };
    const sc = F.scoreAt(series, m, model, d);
    if (!sc.ok) return { ok: false, reason: sc.reason };
    const ref = refFor(cfg.h, model), own = F.ownHistory(series, m, model, { day: d, lookback: 365, step: 3 });
    const ret = {}, mret = {};
    for (const h of HS) {
      const y = F.realized(series, sc.dayNum, h, 1); ret[h] = fin(y) ? Math.exp(y) - 1 : null;
      const y2 = m ? F.realized(m, sc.dayNum, h, 1) : NaN; mret[h] = fin(y2) ? Math.exp(y2) - 1 : null;
    }
    return { ok: true, day: sc.day, score: sc.score, pct: ref ? F.percentileOf(sc.score, ref.sorted) : null, own: own.ok ? own.pct : null, ret, mret };
  }
  async function loadItem() {
    if (!identity || busy) return;
    if (controller) controller.abort();
    controller = new AbortController();
    const c = controller, token = ++epoch, id = identity.id;
    busy = true; working = false; itemError = ''; itemFetch = '';
    fields = payload = series = report = legacy = historical = outcomes = batch = fx = look = null;
    render();
    try {
      // K is cache-aware like the scan: fresh cache = no request, stale = tail merge.
      let meta = null, cached = null;
      try { meta = (await ST.kIndex())[String(id)]; if (meta && cfg.useCache) cached = await ST.getK(id); } catch (e) { /* storage unavailable */ }
      const wlItem = WL.byId(id), knownName = (wlItem && wlItem.name) || (meta && meta.name) || '';
      const [base, q, kr] = await Promise.all([
        api('/v1/market/facade/wiki/skin_detail_base_info', { id }, c.signal),
        api('/v1/market/facade/quote/detail_price_compare', { id }, c.signal),
        fetchK(String(id), meta, cached, knownName, meta ? meta.family : S.familyOf(knownName), null, c.signal),
      ]);
      if (token !== epoch) return;
      series = kr.series; itemFetch = { cache: '来自今日缓存', tail: '增量补齐', full: '完整抓取' }[kr.mode] || '';
      payload = series.ok ? payloadFromSeries(series) : { code: 200, data: [] };
      const now = Date.now(), kh = L.kchart(payload, now);
      // 2.5: snapshot changes on the youpin basis (youpin ask vs youpin daily-K closes).
      fields = L.youpinBasis(L.firepulse(base, q, id), kh);
      const yq = S.youpinQuote(q);
      quotes.set(String(id), { ok: yq.ok, price: yq.ok ? yq.price : null, count: yq.ok ? yq.count : null, reason: yq.ok ? '' : yq.reason, at: new Date().toISOString(), day: BY.bjDay() });
      if (cfg.researchCapture && yq.ok) { try { await ST.addResearchQuotes([{id:String(id),observedAt:quotes.get(String(id)).at,ask:yq.price,count:yq.count>=0?yq.count:null,close:series.ok?series.c[series.n-1]:null,signalDay:series.ok?series.lastDay:null}]); } catch(e) { itemError='研究采集未保存：'+e.message; } }
      const score = L.score(fields, kh);
      legacy = { score, entry: L.entry(fields, kh, score) };
      report = N.evaluate(payload, fields.price, now);
      try { await ensureMarket(c.signal); } catch (e) { itemError = '大盘指数读取失败（' + e.message + '），β 与大盘层暂不可用。'; }
      if (token !== epoch) return;
      if (series.ok) {
        if (knownName !== fields.title || (meta && !meta.price)) ST.putK({ id, name: fields.title, family: meta ? meta.family : S.familyOf(fields.title), price: fields.price }, series).catch(() => {});
        fx = computeFactor();
        const r = fx && fx.byH[cfg.h];
        if (cfg.logSignals && r && r.ok) ST.addView({ day: r.sc.day, id: String(id), name: fields.title, h: cfg.h, modelId: modelOf(cfg.h).id, score: r.sc.score, pct: r.pct, close: r.sc.close }).catch(() => {});
      } else itemError = itemError || ('日K不可用：' + series.reason);
    } catch (e) {
      if (token === epoch) itemError = e.name === 'AbortError' ? '请求超时，请稍后刷新。' : e.message;
    } finally { if (token === epoch) { busy = false; render(); } }
  }
  function exportItem() {
    download('market-lens-lab-' + identity.id + '-' + Date.now() + '.json', JSON.stringify({
      exportedAt: new Date().toISOString(), version: VERSION, factorVersion: F.VERSION, identity, fields, rules: cfg.rules, ruleCheck: fields ? F.ruleCheck(fields.title, fields.price, cfg.rules) : null,
      factor: fx && { regime: fx.regime, h: cfg.h, model: modelOf(cfg.h).id, byH: Object.fromEntries(HS.map(h => [h, fx.byH[h] && fx.byH[h].ok ? { score: fx.byH[h].sc.score, pct: fx.byH[h].pct, bucket: fx.byH[h].bucket, features: fx.byH[h].sc.f, why: fx.byH[h].why } : fx.byH[h]])), own: fx.own && { pct: fx.own.pct, n: fx.own.n } },
      lab21: report, legacy, historical, outcomes, batch, kPayload: payload,
    }, null, 2));
  }

  // ---- scan mode -----------------------------------------------------------
  // ① whitelist → id (directory), ② name rules (no request for excluded names,
  // holdings first), ③ cache-aware youpin K with live ranking, ④ youpin asks
  // for the recommended picks only.
  async function runScan() {
    if (scanBusy() || exp.busy) return;
    buy.msg = '';
    if (scan.phase === 'paused' && scan.universe && scan.universeRulesKey === rkey() && scan.cursor < scan.queue.length) { await runDeep(); return; }
    scan.generation++; scan.universeRulesKey = rkey();
    const runGeneration = scan.generation;
    Object.assign(scan, { phase: 'resolve', universe: null, rows: [], rowIdx: new Map(), plan: null, coverage: '', resolved: null, queue: [], cursor: 0, error: '', note: '', autoPaused: '', cross: null, finishedAt: null, startedAt: new Date().toISOString(),
      progress: { done: 0, total: 0, ok: 0, fail: 0, requests: 0, cached: 0, tail: 0, full: 0, netMs: 0, netN: 0 } });
    scan.series = new Map(); scan.pause = false; scan.abort = new AbortController();
    Object.assign(qs, { done: 0, total: 0, msg: '' });
    const sig = scan.abort.signal;
    render();
    // ① directory
    let dir = {};
    try { dir = await ST.directory(); } catch (e) { /* storage unavailable */ }
    if (runGeneration !== scan.generation) return;
    let plan = S.resolvePlan(WL.ITEMS, dir);
    if (plan.terms.length && !sig.aborted) {
      const found = await resolveMissing(plan, dir, sig);
      if (runGeneration !== scan.generation) return;
      if (Object.keys(found).length) { Object.assign(dir, found); try { await ST.putDirectory(found); } catch (e) { /* ignore */ } }
      plan = S.resolvePlan(WL.ITEMS, dir);
    }
    if (sig.aborted) { scan.phase = scan.rows.length ? 'done' : 'idle'; render(); return; }
    scan.resolved = { n: plan.items.length, missing: plan.missing.length, requiredMissing: plan.missing.filter(w => !rulesOn() || !F.ruleReasonName(w.name, cfg.rules)).length, missingNames: plan.missing.slice(0, 20).map(w => w.name) };
    // ② universe: name rules (no request for excluded names), holdings first
    const held = new Set(hold.list.filter(h => h.status !== 'sold').map(h => String(h.id)));
    const R = cfg.rules;
    scan.universe = S.buildUniverse(plan.items, { reject: row => (rulesOn() ? F.ruleReasonName(row.name, R) : null), priority: row => (held.has(String(row.id)) ? 2 : 0) });
    scan.failed = new Set(); scan.completed = new Set();
    scan.rows = scan.universe.items.map(it => S.mergeRow(it, null));
    scan.rowIdx = new Map(scan.rows.map((r, i) => [String(r.id), i]));
    scan.queue = scan.universe.items.map(it => it.id); scan.cursor = 0;
    const U = scan.universe;
    scan.note = '';
    scan.coverage = '白名单 ' + WL.COUNT + ' 件 → 已知 ID ' + plan.items.length + ' 件' + (plan.missing.length ? '（' + plan.missing.length + ' 件暂未解析到商品 ID，本次跳过）' : '') +
      (rulesOn() ? ' → 名称规则排除 ' + U.dropped.rules + ' 件（' + reasonsText(U.ruleReasons) + '，不发请求）' : '') + ' → 读取 ' + U.items.length + ' 件悠悠日K' + (held.size ? '（持仓优先）' : '') + '。';
    await runDeep();
  }
  // Targeted search for whitelist entries without an id: one request per base
  // name; every whitelist hit in the 100 fuzzy results is remembered, so later
  // terms are often already satisfied and skipped without a request.
  async function resolveMissing(plan, dir, sig) {
    const found = {}, known = Object.assign({}, dir);
    const terms = plan.terms.slice(0, S.DEFAULTS.maxResolve);
    scan.progress.total = terms.length; scan.progress.done = 0;
    scan.note = '白名单里有 ' + plan.missing.length + ' 件还没有商品 ID，先按名称检索（最多 ' + terms.length + ' 次，结果会记住，下次不再检索）。';
    render();
    const wantOf = new Map();
    for (const w of plan.missing) { const t = S.baseName(w.name) || w.name; if (!wantOf.has(t)) wantOf.set(t, []); wantOf.get(t).push(w); }
    await pool(terms, async term => {
      if ((wantOf.get(term) || []).every(w => known[w.market_hash_name])) return 'cached';
      const j = await apiRetry('/v1/market/facade/wiki/skin_search', { name: term, page: 1, page_size: 100, pc: true }, sig, S.DEFAULTS.tries);
      const add = S.absorbSearch(j && j.data && j.data.list, WL.ITEMS, known);
      Object.assign(found, add); Object.assign(known, add);
      return 'net';
    }, {
      concurrency: Math.min(2, cfg.concurrency), delayMin: 200, delayMax: 450, signal: sig, shouldStop: () => scan.pause, maxRequests: S.DEFAULTS.maxResolve,
      onTick: tk => { Object.assign(scan.progress, { done: tk.done, ok: tk.ok, fail: tk.fail }); updateProgress(); },
      onError: e => { if (!sig.aborted) scan.error = '白名单检索失败：' + e.message; },
      onStreak: e => { scan.pause = true; scan.autoPaused = '连续 ' + S.DEFAULTS.failStreak + ' 次检索失败（' + e.message + '），疑似限流；已用现有 ID 继续。'; },
    });
    scan.pause = false; scan.error = '';
    scan.progress = Object.assign(scan.progress, { done: 0, total: 0, ok: 0, fail: 0 });
    return found;
  }
  async function runDeep() {
    if (!scan.universe) { scan.error = '请先开始扫描'; render(); return; }
    const generation = scan.generation;
    const byId = new Map(scan.universe.items.map(it => [it.id, it]));
    const pending = scan.queue.filter(id => !scan.completed.has(String(id))).map(id => byId.get(id)).filter(Boolean);
    if (!pending.length) { scan.note = '扫描队列已完成。'; scan.phase = 'done'; applyCross(true); render(); return; }
    scan.pause = false; if (!scan.abort || scan.abort.signal.aborted) scan.abort = new AbortController();
    const sig = scan.abort.signal;
    const startRequests = scan.progress.requests;
    scan.phase = 'deep'; scan.error = ''; scan.autoPaused = '';
    scan.progress = Object.assign(scan.progress, { done: 0, total: pending.length, ok: 0, fail: 0 });
    render();
    net.setBudget(sig, S.DEFAULTS.maxRequests);
    try { await ensureMarket(sig); } catch (e) { scan.error = '大盘指数读取失败（' + e.message + '），β 因子将缺失。'; }
    // Plan per item from the cache index, then batch-load the cached series we will reuse.
    let idx = {};
    try { idx = cfg.useCache ? await ST.kIndex() : {}; } catch (e) { /* storage unavailable */ }
    if (generation !== scan.generation || sig.aborted) return;
    const today = todayNum();
    const plans = new Map(pending.map(it => [it.id, cfg.useCache ? S.kPlan(idx[it.id], today, { kDepth: cfg.kDepth }) : { mode: 'full', range: cfg.kDepth }]));
    const counts = { cache: 0, tail: 0, full: 0 };
    for (const p of plans.values()) counts[p.mode === 'fresh' ? 'cache' : p.mode]++;
    const est = S.estimate({ full: counts.full, tail: counts.tail }, { concurrency: cfg.concurrency, kDepth: cfg.kDepth });
    scan.plan = { counts, requests: est.requests, minutes: est.minutes };
    let cached = new Map();
    try { cached = await ST.getKMany(pending.filter(it => plans.get(it.id).mode !== 'full').map(it => it.id)); } catch (e) { /* storage unavailable */ }
    render();
    if (generation !== scan.generation || sig.aborted) return;
    const res = await pool(pending, async item => {
      const id = String(item.id);
      const kr = await fetchK(id, idx[id], cached.get(id) || null, item.name, item.family, null, sig);
      if (sig.aborted || generation !== scan.generation) throw Object.assign(Error('旧扫描已取消'), { name: 'AbortError' });
      const s = kr.series;
      if (!s || !s.ok) throw Error(s && s.reason || '日K无效');
      const lastIdx = F.lastUsableIndex(s);
      if (lastIdx < 0) throw Error('没有可用日K收盘价');
      const barDay = s.day0 + lastIdx, barDayStr = F.dayStr(barDay);
      if (!BY.fresh(barDayStr, BY.bjDay(), 3)) throw Error('日K数据已过期超过3天：' + barDayStr);
      // 允许使用前1天或前2天的有效最新K线（应对悠悠K线晚间/凌晨未落盘）
      if (!scan.decisionDay) scan.decisionDay = barDay;
      const usable = F.lastUsableIndex(s, scan.decisionDay);
      if (usable < 0) throw Error('日K在决策日 ' + F.dayStr(scan.decisionDay) + ' 无有效数据');
      if (kr.mode === 'cache') scan.progress.cached++; else { scan.progress[kr.mode]++; scan.progress.netMs += kr.ms; scan.progress.netN++; }
      let deep;
      if (s.ok) { const k = payloadFromSeries(s, 220); let price = null, err = ''; try { price = N.lastClose(k, Date.now()); } catch (e) { err = e.message; } deep = price === null ? { ok: false, reason: err || '缺少可用收盘价' } : N.evaluate(k, price, Date.now()); }
      else deep = { ok: false, reason: s.reason || '日K无效' };
      const row = S.mergeRow(item, deep);
      const decDay = scan.decisionDay || (todayNum() - 1);
      row.volumeEvidence=VA.audit(s,decDay);
      row.fetch = { cache: '缓存', tail: '增量', full: '完整' }[kr.mode];
      if (s.ok) { scan.series.set(id, s); row.lastDay = s.lastDay; }
      const q = quotes.get(id);
      if (q && q.ok) { row.ask = q.price; row.askCount = q.count; row.askDay = q.day; }
      const i = scan.rowIdx.get(id);
      if (i !== undefined) scan.rows[i] = row; else { scan.rowIdx.set(id, scan.rows.length); scan.rows.push(row); }
      scan.completed.add(id); scan.failed.delete(id);
      liveRender(false);
      return kr.mode === 'cache' ? 'cached' : 'net';
    }, {
      concurrency: cfg.concurrency, delayMin: S.DEFAULTS.delayMin, delayMax: S.DEFAULTS.delayMax, signal: sig,
      shouldStop: () => scan.pause, maxRequests: S.DEFAULTS.maxRequests, requestBase: startRequests, failStreak: S.DEFAULTS.failStreak,
      onTick: tk => { if (generation !== scan.generation) return; scan.cursor = scan.completed.size; Object.assign(scan.progress, { done: tk.done, ok: tk.ok, fail: tk.fail }); updateProgress(); },
      onError: (e, item) => { if (generation !== scan.generation) return; scan.failed.add(String(item.id)); if (!sig.aborted) scan.error = '日K请求失败：' + e.message; },
      onStreak: e => { if (generation !== scan.generation) return; scan.pause = true; scan.autoPaused = '连续 ' + S.DEFAULTS.failStreak + ' 次日K请求失败（' + e.message + '），已自动暂停，疑似限流。已完成的结果保留，可稍后点“继续扫描”。'; },
    });
    if (generation !== scan.generation) return;
    try { await ST.flushIdx(); } catch (e) { /* ignore */ }
    const left = scan.queue.length - scan.cursor;
    if (res.stopped === 'budget' && left === 0) res.stopped = '';
    if (res.stopped === 'streak' || res.stopped === 'paused' || res.stopped === 'aborted' || res.stopped === 'budget') scan.phase = 'paused';
    if (res.stopped === 'aborted') scan.note = '已停止，剩余 ' + left + ' 件未扫描；结果保留。';
    else if (res.stopped === 'budget') scan.note = '已达本批请求上限 ' + S.DEFAULTS.maxRequests + '，剩余 ' + left + ' 件；点“继续扫描”跑下一批。';
    else if (res.stopped === 'streak') scan.note = '自动暂停，剩余 ' + left + ' 件未扫描。';
    else if (res.stopped === 'paused') scan.note = '已暂停，剩余 ' + left + ' 件；点“继续扫描”接着跑。';
    else {
      const secs = scan.startedAt ? (Date.now() - Date.parse(scan.startedAt)) / 1000 : null;
      scan.note = '扫描完成：' + res.ok + ' 件成功（缓存 ' + scan.progress.cached + ' · 增量 ' + scan.progress.tail + ' · 完整 ' + scan.progress.full + '）、' + res.fail + ' 件失败，日K请求 ' + scan.progress.requests + ' 次' + (secs !== null ? '，用时 ' + (secs < 90 ? Math.round(secs) + ' 秒' : (secs / 60).toFixed(1) + ' 分钟') : '') + '。';
      scan.phase = 'done'; scan.finishedAt = new Date().toISOString();
    }
    if (scan.liveTimer) { clearTimeout(scan.liveTimer); scan.liveTimer = null; }
    if (left > 0) { scan.phase = 'paused'; scan.note += ' 仍有 ' + left + ' 件待补扫，请点继续扫描。'; }
    applyCross(scan.phase === 'done' && left === 0);
    lr.stats = null;
    if (hold.list.length) loadHoldings().catch(() => {});
    render();
    // ④ youpin asks for the picks (only after a completed scan; a manual button covers the rest)
    if (scan.phase === 'done' && !sig.aborted) await quotePicks(false);
  }
  // Youpin ask (detail_price_compare) for the recommended picks of the current
  // horizon — 2.6.1 fetched one per scanned item (~800 requests); 2.9 fetches
  // at most maxQuotes, newest first, and reuses asks younger than quoteTtlMs.
  async function quotePicks(force) {
    if (qs.busy || scanBusy()) return;
    const rec = currentRec();
    if (!rec || !rec.picks.length) return;
    const now = Date.now();
    const want = rec.picks.map(p => String(p.id)).filter(id => { const q = quotes.get(id); return force || !q || !q.at || now - Date.parse(q.at) > S.DEFAULTS.quoteTtlMs; }).slice(0, S.DEFAULTS.maxQuotes);
    if (!want.length) { liveRender(true); return; }
    qs.busy = true; qs.done = 0; qs.total = want.length; qs.msg = ''; qs.abort = new AbortController();
    const prevPhase = scan.phase;
    if (scan.phase === 'done') scan.phase = 'quote';
    const sig = qs.abort.signal;
    liveRender(true); updateProgress();
    let fail = 0;
    await pool(want, async id => {
      const j = await apiRetry('/v1/market/facade/quote/detail_price_compare', { id }, sig, 2);
      const yq = S.youpinQuote(j);
      quotes.set(id, { ok: yq.ok, price: yq.ok ? yq.price : null, count: yq.ok ? yq.count : null, reason: yq.ok ? '' : yq.reason, at: new Date().toISOString(), day: BY.bjDay() });
      const i = scan.rowIdx.get(id);
      if (i !== undefined && yq.ok) { const r = scan.rows[i]; r.ask = yq.price; r.askCount = yq.count; r.askDay = BY.bjDay(); }
      if (cfg.researchCapture && yq.ok) { const r=scan.rows[i]; try { await ST.addResearchQuotes([{id:String(id),observedAt:quotes.get(id).at,ask:yq.price,count:yq.count>=0?yq.count:null,close:r&&fin(r.close)?r.close:null,signalDay:r?r.day:null}]); } catch(e) { qs.msg='研究采集未保存：'+e.message; } }
      return 'net';
    }, {
      concurrency: Math.min(2, cfg.concurrency), delayMin: S.DEFAULTS.delayMin, delayMax: S.DEFAULTS.delayMax, signal: sig, maxRequests: S.DEFAULTS.maxQuotes + 5, requestBase: scan.progress.requests,
      onTick: tk => { qs.done = tk.done; fail = tk.fail; updateProgress(); liveRender(false); },
      onStreak: e => { qs.msg = '悠悠报价连续失败（' + e.message + '），已停止读取在售价。'; },
    });
    qs.busy = false; qs.at = new Date().toISOString(); qs.abort = null;
    if (fail && !qs.msg) qs.msg = fail + ' 件在售价读取失败，可点“刷新在售价”重试。';
    if (scan.phase === 'quote') scan.phase = prevPhase;
    if (scan.liveTimer) { clearTimeout(scan.liveTimer); scan.liveTimer = null; }
    render();
  }
  // Per-row scores are computed once per (series, rules, models, tradability
  // settings) and reused by the throttled live renders.
  function rowSignals(r, s, m, R, on) {
    const decision = scan.decisionDay || (todayNum() - 1);
    const key = decision + '|' + s.lastDay + '|' + s.n + '|' + (mkt ? mkt.fetchedAt : '') + '|' + rkey() + '|' + HS.map(h => modelOf(h).id).join(',') + '|' + cfg.minLiq + '/' + cfg.maxZeroVol;
    if (r._sig === key) return;
    r._sig = key;
    r.tradable = false; r.selNote = ''; r.ruleCode = null; r.day = null; r.close = null;
    for (const h of HS) {
      const sc = F.scoreAt(s, m, modelOf(h), decision);
      if (sc.ok && (sc.dayNum !== decision || !BY.fresh(sc.day, BY.bjDay()) || sc.coverage < .9)) { sc.ok = false; sc.reason = '信号日期不一致、过期或因子覆盖不足90%'; }
      r['fs' + h] = sc.ok ? sc.score : null;
      if(!r.factorEvidence)r.factorEvidence={};r.factorEvidence[h]={day:sc.day||null,ok:sc.ok,coverage:sc.coverage??null,features:sc.f||null,parts:sc.parts||[],reason:sc.reason||null};
      r['why' + h] = sc.ok ? F.explain(sc.parts, 6).filter(w => w.contrib > 0).slice(0, 3).map(w => w.text) : [];
      if (sc.ok) { r.tradable = tradableF(sc.f); r.close = sc.close; r.day = sc.day; }
      else r.selNote = sc.reason;
    }
    if (!r.day) { const i = F.lastUsableIndex(s); if (i >= 0) { r.close = s.c[i]; r.day = F.dayStr(s.day0 + i); } }
    if (on) r.ruleCode = F.ruleReasonName(r.name, R) || F.ruleReasonPrice(fin(r.close) ? r.close : r.price, R);
    if (r.ruleCode) r.selNote = '规则外·' + F.RULE_REASONS[r.ruleCode] + (fin(r.close) && (r.ruleCode === 'cheap' || r.ruleCode === 'expensive') ? ' ¥' + num(r.close, 2) : '');
    else if (r['fs' + cfg.h] !== null && !r.tradable) r.selNote = '成交太少';
    r.limit = fin(r.close) ? Math.round(r.close * (1 + BY.DEFAULTS.tol) * 100) / 100 : null;
  }
  // Score every deep-scanned item for all horizons, rank the tradable ones that
  // pass the filter rules (name + latest close) against each other, persist the
  // cross-section (single-item reference) and a paper-tracking snapshot.
  function applyCross(persist) {
    const m = mkt ? mkt.series : null;
    const rows = scan.rows.filter(r => scan.series.has(String(r.id)));
    if (!rows.length) return;
    const R = cfg.rules, on = rulesOn();
    let lastDay = F.dayStr(scan.decisionDay || (todayNum() - 1));
    for (const r of rows) { rowSignals(r, scan.series.get(String(r.id)), m, R, on); }
    const cross = {};
    for (const h of HS) {
      const ok = rows.filter(r => r.day === lastDay && r.tradable && !r.ruleCode && fin(r['fs' + h]));
      const sorted = ok.map(r => r['fs' + h]).sort((a, b) => a - b);
      for (const r of rows) r['sel' + h] = r.day === lastDay && r.tradable && !r.ruleCode && fin(r['fs' + h]) && sorted.length >= 10 ? F.percentileOf(r['fs' + h], sorted) : null;
      cross[h] = { schema: 2, complete: scanComplete(), day: lastDay, n: sorted.length, sorted: sorted.map(x => Math.round(x * 1e4) / 1e4), modelId: modelOf(h).id, rulesKey: rkey() };
      if (persist && cross[h].complete && liveRegime(lastDay) && sorted.length >= 30) {
        xsec[h] = cross[h];
        ST.putXsec(h, cross[h]).catch(() => {});
        if (cfg.logSignals) ST.addSnapshot({ day: lastDay, h, modelId: modelOf(h).id, rulesKey: rkey(), n: ok.length, items: ok.map(r => [String(r.id), Math.round(r['fs' + h] * 1e4) / 1e4, r.close]) }).catch(() => {});
      }
    }
    for (const r of scan.rows) { r.selPct = fin(r['sel' + cfg.h]) ? r['sel' + cfg.h] : null; r.selQ = F.bucketOf(r.selPct); }
    scan.cross = { day: lastDay, n: cross[cfg.h].n, h: cfg.h, out: rows.filter(r => r.ruleCode).length };
  }

  // ---- backtest ---------------------------------------------------------------
  async function getPanel(obj, ids, needLab, signal) {
    setProg(obj, '读取本机样本库…', 0.02, ids);
    const items = (await ST.allK({ onProgress: (d, t) => setProg(obj, '读取样本库 ' + d + '/' + t, 0.02 + 0.08 * d / t, ids) })).filter(x => x.series.n >= F.FEATURE_MIN_ROWS + 30);
    const R = rulesOn() ? cfg.rules : null;
    const nOk = R ? items.filter(x => !F.ruleReasonName(x.name, R)).length : items.length;
    if (nOk < 40) throw Error((R ? '按筛选规则（' + F.rulesText(R) + '），' : '') + '本机样本库只有 ' + nOk + ' 件可用商品' + (R ? '（共 ' + items.length + ' 件）' : '') + '，需要 ≥40。请先到“今日买点”把白名单扫描一次' + (R ? '，或放宽筛选规则' : '') + '。');
    try { await ensureMarket(signal); } catch (e) { obj.msg = '大盘指数不可用（' + e.message + '），β 因子缺失；若启用闸门则缺指数日期保持现金'; }
    const lastDay = items.reduce((a, x) => (x.series.lastDay > a ? x.series.lastDay : a), '');
    const key = JSON.stringify({ n: items.length, lastDay, step: cfg.step, lab: needLab, liq: cfg.minLiq, zv: cfg.maxZeroVol, m: mkt && mkt.fetchedAt, versions: items.map(x=>[x.id,x.fetchedAt,x.series.lastDay,x.series.n]), rules: rkey() });
    if (bt.panel && bt.panelKey === key) return bt.panel;
    const keys = needLab ? PANEL_KEYS.concat(['labEntry']) : PANEL_KEYS;
    const p = await F.buildPanelAsync(items, mkt ? mkt.series : null, { step: cfg.step, horizons: HS, keys, tradable: { minLiq: cfg.minLiq, maxZeroVol: cfg.maxZeroVol }, minItemsPerDay: 20, rules: R },
      (d, t) => setProg(obj, '计算因子 ' + d + '/' + t + ' 件', 0.1 + 0.6 * d / t, ids), signal);
    bt.panel = p; bt.panelKey = key;
    return p;
  }
  async function runBacktest() {
    if (bt.phase === 'running' || exp.busy) return;
    bt.phase = 'running'; bt.error = ''; bt.abort = new AbortController();
    ST.saveSettings({ fee: cfg.fee, topN: cfg.topN });
    render();
    const ids = ['btMsg', 'btBar'];
    try {
      const P = await getPanel(bt, ids, bt.lab, bt.abort.signal);
      const h = bt.h;
      const cutoff = bt.oosOnly ? F.dayNumOf(B.dataFetchedAt) : -Infinity;
      const days = P.days.filter(d => d > cutoff);
      if (days.length < 10) throw Error(bt.oosOnly ? '内置模型训练截止后的采样日还太少（' + days.length + '），需要继续积累数据。' : '可用采样日太少（每个采样日需要 ≥20 件符合规则的可交易商品）' + (rulesOn() ? '，可放宽筛选规则或多扫一些商品' : ''));
      const sub = Object.assign({}, P, { days });
      const prim = bt.model === 'active' ? modelOf(h) : bt.model === 'builtin' ? B.models['h' + h] : reg.candidates.find(m => m.id === bt.model) || modelOf(h);
      const list = [[(bt.model === 'active' ? '当前启用' : bt.model === 'builtin' ? '内置默认' : '候选') + '·' + (isBuiltin(prim) ? '内置' : prim.id.slice(0, 18)), F.modelScorer(P, prim)]];
      if (prim.id !== B.models['h' + h].id) list.push(['内置默认', F.modelScorer(P, B.models['h' + h])]);
      if (P.keys.includes('labEntry')) list.push(['lab-2.1入场', F.featFn(P, 'labEntry')]);
      list.push(['30日动量', F.featFn(P, 'mom30')]);
      let wfFits = 0, wfFirst = null;
      if (bt.wf) {
        setProg(bt, '滚动训练中…', 0.75, ids);
        await sleep(20);
        const wf = F.walkForward(P, { h, keys: prim.features.map(f => f.key), lambda: prim.lambda || 30, every: 30, minTrainDays: Math.round(240 / P.step) });
        if (wf.fits.length) { list.splice(1, 0, ['滚动训练（同因子）', wf.scorer]); wfFits = wf.fits.length; wfFirst = wf.firstDay; }
      }
      const gate = bt.gate ? d => { const m=mkt&&mkt.series,g=m?F.marketRegime(m,d):null,i=m?d-m.day0:-1; return !!(g&&m.real[i]&&g.score>=cfg.gate); } : null;
      const models = [];
      for (let k = 0; k < list.length; k++) {
        if (bt.abort.signal.aborted) throw Object.assign(Error('已取消'), { name: 'AbortError' });
        setProg(bt, '评估 ' + list[k][0], 0.8 + 0.2 * k / list.length, ids);
        await sleep(10);
        const fn = list[k][1];
        const ic = F.crossIC(sub, fn, h, { minN: 20 });
        const q = F.quantiles(sub, fn, h, { q: 5, cost: cfg.fee, minN: 25 });
        const pf = F.portfolioSim(sub, fn, { h, topN: cfg.topN, cost: cfg.fee, gate, minN: 25 });
        models.push({ name: list[k][0], ic: { mean: ic.mean, t: ic.t, posRate: ic.posRate, byYear: ic.byYear, n: ic.n }, q, pf, ci: F.bootstrapMeanCI(ic.series.map(s => s.ic), Math.max(5, Math.round(h / P.step))) });
      }
      const years = Array.from(new Set(days.map(d => F.dayStr(d).slice(0, 4)))).sort();
      bt.result = { h, cost: cfg.fee, topN: cfg.topN, gate: !!gate, step: P.step, items: P.nItems || P.items.length, rules: rulesOn() ? F.rulesText(cfg.rules) : '未启用', ruleStats: P.ruleStats, rows: P.rows.length, days: days.length, first: F.dayStr(days[0]), last: F.dayStr(days[days.length - 1]), models, years, wfFits, wfFirst, at: new Date().toISOString() };
      bt.phase = 'done';
    } catch (e) {
      bt.phase = 'idle'; bt.error = e.name === 'AbortError' ? '已取消' : e.message;
    }
    render();
  }

  // ---- learning ---------------------------------------------------------------
  async function refreshStats() {
    const idx = await ST.kIndex(), vals = Object.values(idx);
    const now = Date.now();
    lr.stats = { items: vals.length, fresh: vals.filter(v => ST.isFresh(v, now)).length, first: null, last: vals.reduce((a, v) => (v.lastDay > a ? v.lastDay : a), ''), bytes: await ST.bytesInUse() };
    if (vals.length) { const firsts = []; for (const v of vals) if (v.lastDay && v.n) firsts.push(F.dayStr(F.dayNumOf(v.lastDay) - v.n + 1)); firsts.sort(); lr.stats.first = firsts[0]; }
    if (tab === 'learn') render();
  }
  async function runTrain() {
    if (lr.phase === 'running' || exp.busy) return;
    lr.phase = 'running'; lr.error = ''; lr.info = '';
    render();
    const ids = ['lrMsg', 'lrBar'], ctrl = new AbortController();
    try {
      const P = await getPanel(lr, ids, bt.lab, ctrl.signal);
      const hs = lr.trainH === 'all' ? HS : [Number(lr.trainH)];
      const keys = KEYSETS[cfg.featureSet] || KEYSETS.LEAN;
      for (let k = 0; k < hs.length; k++) {
        const h = hs[k];
        setProg(lr, '训练 ' + h + ' 日模型（走步验证 + 留出测试）…', 0.72 + 0.28 * k / hs.length, ids);
        await sleep(30);
        // The builtin model was fitted on data that covers most of any holdout
        // window a user can build today, so comparing against it there would
        // be in-sample for the builtin. It is shown as a labelled reference row
        // and the "not worse than active" gate is skipped while builtin is active.
        const act = modelOf(h), actBuiltin = isBuiltin(act);
        const baselines = { ['内置默认（测试期多为其训练样本内，仅参考）']: F.modelScorer(P, B.models['h' + h]) };
        if (P.keys.includes('labEntry')) baselines['lab-2.1入场'] = F.featFn(P, 'labEntry');
        const r = F.train(P, { h, keys, lambdas: [3, 30, 300], folds: 4, active: actBuiltin ? null : act, baselines });
        if (r.ok && actBuiltin) {
          const g = r.gates.find(x => x.name === '不差于当前启用模型');
          if (g) g.name = '不差于当前启用模型（当前为内置：其训练期覆盖测试期，无法公平比较，跳过）';
        }
        if (r.ok) {
          r.model.id += '-' + cfg.featureSet.toLowerCase() + '-' + Date.now().toString(36).slice(-4);
          r.model.h = h; r.model.featureSet = cfg.featureSet; r.model.lambda = r.selection.best.lambda;
          await ST.addCandidate(r.model);
        }
        lr.results[h] = r;
      }
      reg = await ST.registry();
      lr.info = '训练完成。候选模型已保存，但尚未启用——请查看留出测试成绩与闸门后再决定。';
    } catch (e) { lr.error = e.message; }
    lr.phase = 'idle';
    render();
  }
  async function regOp(fn, msg) {
    try { reg = await fn(); lr.info = msg; lr.error = ''; }
    catch (e) { lr.error = e.message; }
    reg = await ST.registry();
    if (series) fx = computeFactor();
    if (scan.rows.length) applyCross();
    render();
  }
  function enableModel(h, id) {
    const m = reg.candidates.find(x => x.id === id);
    if (!m) return;
    if (!m.gatesPassed && !ask('该模型没有通过全部闸门（样本外成绩不足以证明有效）。仍要启用吗？可随时回滚。')) return;
    if (m.gatesPassed && !ask('启用 ' + id + ' 作为 ' + h + ' 日模型？可随时回滚或恢复内置。')) return;
    regOp(() => ST.activate(h, id, m.gatesPassed ? '启用（闸门通过）' : '强制启用（闸门未过）'), '已启用 ' + id);
  }
  function deleteModel(id) {
    if (!ask('删除候选模型 ' + id + '？')) return;
    regOp(() => ST.removeCandidate(id), '已删除 ' + id);
    for (const h of HS) if (lr.results[h] && lr.results[h].model && lr.results[h].model.id === id) delete lr.results[h];
  }
  async function runPaper() {
    try {
      const snaps = await ST.snapshots(), views = (await ST.views()).slice(0, 60);
      const need = new Set(snaps.flatMap(s => s.items.map(i => String(i[0]))).concat(views.map(v => String(v.id))));
      const map = new Map();
      for (const id of need) { const c = await ST.getK(id); if (c) map.set(id, c.series); }
      lr.paper = F.paperTrack(snaps, map, { cost: cfg.fee });
      lr.viewsOut = F.viewOutcomes(views, map, { cost: cfg.fee });
      lr.error = '';
    } catch (e) { lr.error = '纸面跟踪失败：' + e.message; }
    render();
  }
  async function saveSettingsFromDom() {
    const v = id => root.getElementById(id);
    const patch = {
      fee: Math.max(0, Math.min(0.1, (Number(v('setFee').value) || 0) / 100)),
      topN: Math.max(3, Math.min(50, Math.round(Number(v('setTop').value) || 10))),
      gate: Math.max(0, Math.min(100, Number(v('setGate').value) || 0)),
      minLiq: Math.max(0, Number(v('setLiq').value) || 0),
      maxZeroVol: Math.max(0, Math.min(1, Number(v('setZv').value))),
      step: Number(v('setStep').value) || 3,
      logSignals: !!v('setLog').checked,
    };
    cfg = Object.assign(cfg, await ST.saveSettings(patch));
    cfg.rules = F.normRules(cfg.rules);   // stored rules may be null (= defaults): never let a settings save switch the rules off
    bt.panel = null; bt.panelKey = '';
    if (series) fx = computeFactor();
    if (scan.rows.length) applyCross();
    lr.info = '设置已保存。';
    render();
  }
  function importFile(file) {
    if (!file) return;
    if (file.size > 48 * 1024 * 1024) { lr.error = '导入文件超过48MB限制'; render(); return; }
    if (scanBusy() || qs.busy || busy || hold.busy || lr.phase === 'running' || bt.phase === 'running' || exp.busy) { lr.error = '请先停止扫描、训练或刷新，再导入数据'; render(); return; }
    if (!ask('导入将替换文件中提供的设置、模型或持仓。校验通过后会保留一份导入前备份；是否继续？')) return;
    const fr = new FileReader();
    fr.onload = async () => {
      try { const n = await ST.importAll(JSON.parse(fr.result)); scan.series.clear(); scan.rows = []; scan.queue = []; scan.failed.clear(); scan.completed.clear(); scan.cross = null; scan.phase = 'idle'; quotes.clear(); mkt = null; fields = series = payload = fx = null; bt.panel = null; bt.panelKey = ''; await loadState(); lr.info = '已导入 ' + n + ' 项数据。'; lr.error = ''; }
      catch (e) { lr.error = '导入失败：' + e.message; }
      await refreshStats();
      render();
    };
    fr.onerror = () => { lr.error = '读取导入文件失败'; render(); };
    fr.readAsText(file);
  }

  // ---- state & routing ----------------------------------------------------------
  async function loadState() {
    try {
      cfg = Object.assign({ useCache: true }, await ST.settings());
      cfg.rules = F.normRules(cfg.rules);
      cfg.concurrency = Math.max(2, Math.min(4, Number(cfg.concurrency) || 3));
      cfg.kDepth = Number(cfg.kDepth) === 1440 ? 1440 : 720;
      reg = await ST.registry();
      for (const h of HS) { const x = await ST.getXsec(h); if (x) xsec[h] = x; else delete xsec[h]; }
      const m = await ST.getMarket(); mkt = m || null;
      await loadHoldings();
    } catch (e) { buy.msg = '本地存储加载失败：' + e.message; lr.error = buy.msg; }
    ready = true;
  }
  function route(first) {
    const next = L.route(location.href);
    if (!first) {
      if (next && identity && next.key === identity.key) return;
      if (!next && !identity) return;
    }
    if (identity && !next) { identity = null; if (tab === 'item') tab = 'buy'; render(); return; }
    epoch++;
    if (controller) controller.abort();
    identity = next;
    fields = payload = series = report = legacy = historical = outcomes = batch = fx = look = null;
    date = ''; lookDate = ''; itemError = ''; itemFetch = ''; busy = working = false;
    if (identity) tab = 'item';
    render();
    if (opened && identity) loadItem();
  }
  let storageRefreshTimer = null;
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !['settings','registry','holdings','dataRevision','market','xsec:h7','xsec:h14','xsec:h30'].some(k => changes[k])) return;
    if (changes.dataRevision) {
      if (exp.ctrl) exp.ctrl.abort();
      if (scan.abort) scan.abort.abort(); if (qs.abort) qs.abort.abort(); if (controller) controller.abort();
      scan.generation++; scan.abort = null;
      exp.result=null; exp.state=null; exp.outcomes=null;
      epoch++; busy = false; scan.phase = 'idle'; scan.series.clear(); scan.rows = []; scan.queue = []; scan.failed.clear(); scan.completed.clear(); scan.cross = null;
      fields = payload = series = fx = null; quotes.clear(); hold.prices = {}; hold.priceDay = {}; bt.panel = null; bt.panelKey = '';
    }
    clearTimeout(storageRefreshTimer);
    storageRefreshTimer = setTimeout(async () => { await loadState(); if (series) fx = computeFactor(); if (scan.rows.length) applyCross(false); if (opened) render(); }, 150);
  });
  loadState().then(() => { if (opened) render(); if (opened && identity && !payload && !busy) loadItem(); });
  route(true);
  setInterval(() => route(false), 800);
  let signalAgeSignature='';
  setInterval(()=>{
    if(!opened || scanBusy() || (tab!=='buy'&&tab!=='scan') || !scan.rows.length)return;
    const rec=currentRec(),signature=JSON.stringify([BY.bjDay(),rec&&rec.blocked,...scan.rows.map(r=>signalFor(r,rec,rec&&rec.picks.find(p=>String(p.id)===String(r.id))).code)]);
    if(signature===signalAgeSignature)return;signalAgeSignature=signature;
    const el=root.getElementById('liveResults');if(el){el.innerHTML=tab==='buy'?liveBuyHtml():liveScanHtml();bindLive(el);}
  },1000);
})();
