/* Market Lens Lab storage (store-2.9.0 · 2.6.1 data model + 2.8 speed paths).
 * chrome.storage.local when available (manifest "storage" + "unlimitedStorage"),
 * otherwise an in-memory Map (tests / preview). Everything stays on this
 * computer; nothing is uploaded. All writes are serialized through one queue so
 * concurrent scan workers cannot clobber the index. */
(function (root) {
  'use strict';
  const VERSION = 'store-2.9.0';
  const DAY = 86400000;
  const area = (typeof chrome !== 'undefined' && chrome && chrome.storage && chrome.storage.local) ? chrome.storage.local : null;
  const mem = new Map();
  const clone = v => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
  let chain = Promise.resolve();
  const enqueue = fn => (chain = chain.then(fn, fn));

  async function rawGet(keys) {
    if (area) return (await area.get(keys)) || {};
    const out = {};
    for (const k of (Array.isArray(keys) ? keys : [keys])) if (mem.has(k)) out[k] = clone(mem.get(k));
    return out;
  }
  async function rawSet(obj) {
    if (area) return area.set(obj);
    for (const k of Object.keys(obj)) mem.set(k, clone(obj[k]));
  }
  async function rawRemove(keys) {
    if (area) return area.remove(keys);
    for (const k of (Array.isArray(keys) ? keys : [keys])) mem.delete(k);
  }
  async function get(key, dflt) { const r = await rawGet(key); return r[key] === undefined ? clone(dflt) : r[key]; }
  const set = (key, val) => enqueue(() => rawSet({ [key]: val }));
  // Atomic read-modify-write through the same queue (never call set() inside fn).
  const mutate = (key, dflt, fn) => enqueue(async () => {
    const cur = (await rawGet(key))[key];
    const next = fn(cur === undefined ? clone(dflt) : cur);
    await rawSet({ [key]: next });
    return next;
  });
  async function bytesInUse() {
    if (area && area.getBytesInUse) { try { return await area.getBytesInUse(null); } catch (e) { return null; } }
    let n = 0; for (const [k, v] of mem) n += k.length + JSON.stringify(v).length; return n;
  }

  // ---- typed-array packing --------------------------------------------------
  function b64(u8) {
    let s = '';
    for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return btoa(s);
  }
  function unb64(str) {
    const s = atob(str), u8 = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i);
    return u8;
  }
  const f32 = a => b64(new Uint8Array(Float32Array.from(a).buffer));
  const unf32 = s => Float64Array.from(new Float32Array(unb64(s).buffer));
  const dayStr = d => new Date(d * DAY).toISOString().slice(0, 10);
  function packSeries(s) {
    if (!s || !s.ok) return null;
    return { day0: s.day0, n: s.n, o: f32(s.o), h: f32(s.h), l: f32(s.l), c: f32(s.c), v: f32(s.v), real: b64(Uint8Array.from(s.real)), stale: b64(new Uint8Array(Uint16Array.from(s.stale).buffer)) };
  }
  function unpackSeries(p) {
    if (!p || !p.n) return { ok: false, reason: '缓存损坏' };
    const s = { ok: true, day0: p.day0, n: p.n, o: unf32(p.o), h: unf32(p.h), l: unf32(p.l), c: unf32(p.c), v: unf32(p.v), real: unb64(p.real), stale: new Uint16Array(unb64(p.stale).buffer), dropped: 0 };
    if (s.c.length !== s.n || s.real.length !== s.n) return { ok: false, reason: '缓存长度不一致' };
    s.firstDay = dayStr(s.day0); s.lastDay = dayStr(s.day0 + s.n - 1);
    return s;
  }

  // ---- K-line cache -----------------------------------------------------------
  // key 'k:<id>' -> {id,name,family,fetchedAt,lastDay,pack};  'kidx' -> {id: meta}
  let idxCache = null, idxDirty = false, idxTimer = null;
  async function loadIdx() { if (!idxCache) idxCache = await get('kidx', {}); return idxCache; }
  // Public view is a copy: callers must never mutate the shared cache.
  async function kIndex() { return Object.assign({}, await loadIdx()); }
  // The index is one object holding every item; rewriting it after each of
  // hundreds of scan writes is pure amplification. Writes are coalesced: the
  // record goes to storage immediately, the index at most every 600 ms and
  // always on flushIdx() (called when a scan batch ends).
  function scheduleIdxFlush() {
    idxDirty = true;
    if (idxTimer) return;
    idxTimer = setTimeout(() => { idxTimer = null; flushIdx().catch(() => {}); }, 600);
  }
  function flushIdx() {
    if (idxTimer) { clearTimeout(idxTimer); idxTimer = null; }
    if (!idxDirty || !idxCache) { idxDirty = false; return Promise.resolve(); }
    idxDirty = false;
    const snapshot = idxCache;
    return enqueue(() => rawSet({ kidx: snapshot }));
  }
  async function putK(meta, series) {
    const pack = packSeries(series);
    if (!pack || !meta || !meta.id) return false;
    const id = String(meta.id);
    const rec = { id, name: meta.name || '', family: meta.family || '', fetchedAt: new Date().toISOString(), lastDay: series.lastDay, pack };
    await loadIdx();
    await enqueue(async () => {
      idxCache[id] = { name: rec.name, family: rec.family, lastDay: rec.lastDay, fetchedAt: rec.fetchedAt, n: series.n, price: meta.price || null };
      await rawSet({ ['k:' + id]: rec });
      scheduleIdxFlush();
    });
    return true;
  }
  const recToK = (id, rec) => {
    if (!rec) return null;
    const series = unpackSeries(rec.pack);
    return series.ok ? { id: rec.id || id, name: rec.name, family: rec.family, fetchedAt: rec.fetchedAt, series } : null;
  };
  async function getK(id) {
    const r = await rawGet('k:' + id);
    return recToK(String(id), r['k:' + id]);
  }
  // Batch read (one storage round-trip per 50 ids) -> Map(id -> record|null).
  async function getKMany(ids, onProgress) {
    const out = new Map(), list = Array.from(new Set((ids || []).map(String)));
    for (let i = 0; i < list.length; i += 50) {
      const chunk = list.slice(i, i + 50), r = await rawGet(chunk.map(id => 'k:' + id));
      for (const id of chunk) out.set(id, recToK(id, r['k:' + id]));
      if (onProgress) onProgress(Math.min(list.length, i + 50), list.length);
    }
    return out;
  }
  // Fresh = contains the latest completed UTC day (data only changes once a day).
  function isFresh(meta, now) {
    if (!meta || !meta.lastDay) return false;
    const want = dayStr(Math.floor((now || Date.now()) / DAY) - 1);
    return meta.lastDay >= want;
  }
  async function allK(opts) {
    const o = opts || {};
    const idx = await kIndex(), ids = Object.keys(idx);
    const out = [];
    for (let i = 0; i < ids.length; i += 50) {
      const chunk = ids.slice(i, i + 50), r = await rawGet(chunk.map(id => 'k:' + id));
      for (const id of chunk) {
        const rec = r['k:' + id]; if (!rec) continue;
        const series = unpackSeries(rec.pack);
        if (series.ok) out.push({ id, name: rec.name, family: rec.family, fetchedAt: rec.fetchedAt, series });
      }
      if (o.onProgress) o.onProgress(Math.min(ids.length, i + 50), ids.length);
    }
    return out;
  }
  async function removeK(ids) {
    await loadIdx();
    if (idxTimer) { clearTimeout(idxTimer); idxTimer = null; }
    idxDirty = false;
    await enqueue(async () => {
      for (const id of ids) delete idxCache[id];
      await rawRemove(ids.map(id => 'k:' + id));
      await rawSet({ kidx: idxCache });
    });
  }
  async function clearK() { const ids = Object.keys(await kIndex()); await removeK(ids); }

  // ---- market index cache ---------------------------------------------------
  async function putMarket(series) { if (series && series.ok) await set('market', { fetchedAt: new Date().toISOString(), lastDay: series.lastDay, pack: packSeries(series) }); }
  async function getMarket() { const r = await get('market', null); if (!r) return null; const s = unpackSeries(r.pack); return s.ok ? { fetchedAt: r.fetchedAt, lastDay: r.lastDay, series: s } : null; }

  // ---- settings -------------------------------------------------------------
  // rules: null = the default filter rules (MarketLensFactor.DEFAULT_RULES,
  // normalised by the panel with F.normRules).
  // fee: 1% round trip = 悠悠有品 seller fee. Change it in 高级 → 学习 → 设置 if
  // your real cost (spread, withdrawal, waiting to sell) is higher.
  // concurrency: parallel K requests during a scan (2–4). kDepth: days fetched
  // the first time an item is seen (later refreshes fetch only the missing tail).
  const DEFAULT_SETTINGS = { h: 30, fee: 0.01, topN: 10, gate: 30, minLiq: 2, maxZeroVol: 0.5, step: 3, logSignals: true, featureSet: 'LEAN', rules: null, concurrency: 3, kDepth: 720 };
  const OLD_DEFAULT_FEE = 0.02;
  // One-time migration: settings saved by ≤2.4 / 2.7 still carry the old 2% default.
  // Move them to 1% once (flag feeV25); a later manual 2% is left alone.
  async function settings() {
    let cur = await get('settings', {});
    if (cur && !cur.feeV25 && Object.keys(cur).length) {
      cur = await mutate('settings', {}, c => Object.assign({}, c, c.fee === OLD_DEFAULT_FEE ? { fee: DEFAULT_SETTINGS.fee } : {}, { feeV25: true }));
    }
    return Object.assign({}, DEFAULT_SETTINGS, cur);
  }
  async function saveSettings(patch) { const s = await mutate('settings', {}, cur => Object.assign({}, cur, patch || {}, { feeV25: true })); return Object.assign({}, DEFAULT_SETTINGS, s); }

  // ---- whitelist directory ------------------------------------------------
  // market_hash_name -> FirePulse item id learned at runtime (the shipped
  // whitelist already carries ids; this only holds additions / corrections).
  const directory = () => get('wdir', {});
  const putDirectory = entries => mutate('wdir', {}, cur => Object.assign({}, cur, entries || {}));

  // ---- model registry -------------------------------------------------------
  // active[h] = null means "builtin". Candidates are full model objects.
  const MAX_CANDIDATES = 12, MAX_HISTORY = 60;
  const normReg = r => ({ active: Object.assign({ h7: null, h14: null, h30: null }, (r && r.active) || {}), candidates: (r && r.candidates) || [], history: (r && r.history) || [] });
  async function registry() { return normReg(await get('registry', {})); }
  const mutateReg = fn => mutate('registry', {}, cur => { const reg = normReg(cur); fn(reg); return reg; }).then(normReg);
  function addCandidate(model) {
    return mutateReg(reg => {
      reg.candidates = reg.candidates.filter(m => m.id !== model.id);
      reg.candidates.unshift(model);
      const activeIds = new Set(Object.values(reg.active).filter(Boolean));
      while (reg.candidates.length > MAX_CANDIDATES) {
        let k = reg.candidates.length - 1;
        while (k >= 0 && activeIds.has(reg.candidates[k].id)) k--;   // oldest non-active
        if (k < 0) break;
        reg.candidates.splice(k, 1);
      }
    });
  }
  function activate(h, id, note) {
    return mutateReg(reg => {
      const key = 'h' + h;
      if (id && !reg.candidates.some(m => m.id === id)) throw new Error('找不到候选模型 ' + id);
      const from = reg.active[key];
      if (from === id) return;
      reg.active[key] = id;
      reg.history.unshift({ at: new Date().toISOString(), h, from, to: id, note: note || '' });
      reg.history = reg.history.slice(0, MAX_HISTORY);
    });
  }
  // Undo the most recent change for horizon h (repeatable: walks back in history).
  function rollback(h) {
    return mutateReg(reg => {
      const last = reg.history.find(e => e.h === h && !e.undone);
      if (!last) throw new Error(h + '日模型没有可回滚的记录');
      if (last.from && !reg.candidates.some(m => m.id === last.from)) throw new Error('上一个模型已被删除，无法回滚；可以“恢复内置”。');
      last.undone = true;
      reg.active['h' + h] = last.from;
      reg.history.unshift({ at: new Date().toISOString(), h, from: last.to, to: last.from, note: '回滚', undone: true });
      reg.history = reg.history.slice(0, MAX_HISTORY);
    });
  }
  function removeCandidate(id) {
    return mutateReg(reg => {
      if (Object.values(reg.active).includes(id)) throw new Error('该模型正在使用，请先切换或恢复内置。');
      reg.candidates = reg.candidates.filter(m => m.id !== id);
    });
  }

  // ---- signal snapshots (paper tracking) and item views ------------------------
  const MAX_SNAPS = 120, MAX_VIEWS = 600;
  function addSnapshot(snap) { // {day,h,modelId,items:[[id,score,close]]}
    return mutate('snaps', [], arr => {
      const k = arr.findIndex(x => x.day === snap.day && x.h === snap.h && x.modelId === snap.modelId);
      if (k >= 0) arr.splice(k, 1);
      arr.unshift(Object.assign({ at: new Date().toISOString() }, snap));
      return arr.slice(0, MAX_SNAPS);
    });
  }
  const snapshots = () => get('snaps', []);
  function addView(v) { // {day,id,name,h,modelId,score,pct,close}
    return mutate('views', [], arr => {
      const k = arr.findIndex(x => x.day === v.day && x.id === v.id && x.h === v.h);
      if (k >= 0) arr.splice(k, 1);
      arr.unshift(Object.assign({ at: new Date().toISOString() }, v));
      return arr.slice(0, MAX_VIEWS);
    });
  }
  const views = () => get('views', []);
  // ---- holdings (2.6 · 我的持仓) ------------------------------------------------
  // Manual buy/sell records kept on this computer only. Nothing is traded.
  // {hid, id, name, buyDay, buyPrice, qty, h, sellBy, pctAtBuy, modelId,
  //  status: 'open'|'sold', sellDay, sellPrice, createdAt}
  const MAX_HOLDINGS = 500;
  const round2 = v => Math.round(v * 100) / 100;
  const newHid = () => 'h' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  // 2.7 / 2.8 kept trades as ledger `lots` ({key,id,name,price,quantity,at,
  // targetDays,status,soldPrice,soldAt}). Convert them once (flag
  // 'holdingsFrom28') so a user coming from those versions keeps the records;
  // the old key stays untouched as a backup.
  function holdingsFromLots(list) {
    const out = [];
    for (const x of Array.isArray(list) ? list : []) {
      if (!x || !/^\d+$/.test(String(x.id))) continue;
      const price = Number(x.price), qty = Number(x.quantity) > 0 ? Math.round(Number(x.quantity)) : 1;
      if (!Number.isFinite(price) || price <= 0) continue;
      const day = iso => (iso && !isNaN(Date.parse(iso)) ? new Date(Date.parse(iso) + 8 * 3600000).toISOString().slice(0, 10) : null);
      const buyDay = day(x.at) || new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 10);
      const h = [7, 14, 30].includes(Number(x.targetDays)) ? Number(x.targetDays) : 30;
      const sold = x.status === 'sold' && Number.isFinite(Number(x.soldPrice)) && Number(x.soldPrice) > 0;
      out.push({ hid: 'h28-' + String(x.key || Math.random().toString(36).slice(2, 10)), id: String(x.id), name: String(x.name || '商品 ' + x.id).slice(0, 200), url: null,
        buyDay, buyPrice: round2(price), qty, h, sellBy: new Date(Date.parse(buyDay + 'T00:00:00Z') + h * DAY).toISOString().slice(0, 10),
        pctAtBuy: null, modelId: null, status: sold ? 'sold' : 'open', sellDay: sold ? (day(x.soldAt) || buyDay) : null, sellPrice: sold ? round2(Number(x.soldPrice)) : null,
        createdAt: x.at && !isNaN(Date.parse(x.at)) ? new Date(x.at).toISOString() : new Date().toISOString() });
    }
    return out;
  }
  async function holdings() {
    let l = await get('holdings', []);
    if (!Array.isArray(l)) l = [];
    if (await get('holdingsFrom28', false)) return l;
    const old = await get('lots', null);
    if (Array.isArray(old) && old.length) {
      const have = new Set(l.map(x => x.hid)), add = holdingsFromLots(old).filter(x => !have.has(x.hid));
      if (add.length) { l = l.concat(add).slice(0, MAX_HOLDINGS); await enqueue(() => rawSet({ holdings: l, holdingsFrom28: true })); return l; }
    }
    await enqueue(() => rawSet({ holdingsFrom28: true }));
    return l;
  }
  function addHolding(rec) {
    return mutate('holdings', [], cur => {
      const list = Array.isArray(cur) ? cur : [];
      const h = Object.assign({ qty: 1, status: 'open', createdAt: new Date().toISOString() }, rec || {}, { hid: newHid() });
      return [h].concat(list).slice(0, MAX_HOLDINGS);
    }).then(l => l[0]);
  }
  function updateHolding(hid, patch) {
    return mutate('holdings', [], cur => (Array.isArray(cur) ? cur : []).map(h => (h.hid === hid ? Object.assign({}, h, patch || {}, { hid }) : h)));
  }
  function removeHolding(hid) { return mutate('holdings', [], cur => (Array.isArray(cur) ? cur : []).filter(h => h.hid !== hid)); }
  // Latest cross-section per horizon (single-item percentile reference).
  const putXsec = (h, x) => set('xsec:h' + h, x);
  const getXsec = h => get('xsec:h' + h, null);

  // ---- export / import ------------------------------------------------------
  async function exportAll(opts) {
    const o = opts || {};
    const out = { app: 'market-lens-lab', store: VERSION, exportedAt: new Date().toISOString(), settings: await settings(), registry: await registry(), snaps: await snapshots(), views: await views(), holdings: await holdings(), wdir: await directory() };
    if (o.includeK) {
      const idx = await kIndex(), ids = Object.keys(idx), recs = {};
      for (let i = 0; i < ids.length; i += 50) Object.assign(recs, await rawGet(ids.slice(i, i + 50).map(id => 'k:' + id)));
      out.kidx = clone(idx); out.k = recs; out.market = await get('market', null);
    }
    return out;
  }
  async function importAll(obj) {
    if (!obj || obj.app !== 'market-lens-lab') throw new Error('不是 Market Lens Lab 导出的文件');
    const reg = obj.registry || {};
    for (const m of reg.candidates || []) {
      if (!m || typeof m.id !== 'string' || !Array.isArray(m.features) || !m.features.every(f => f && typeof f.key === 'string' && Number.isFinite(f.w))) throw new Error('模型结构无效：' + (m && m.id));
    }
    const writes = {};
    if (obj.settings) writes.settings = Object.assign({}, DEFAULT_SETTINGS, obj.settings);
    if (obj.registry) writes.registry = { active: Object.assign({ h7: null, h14: null, h30: null }, reg.active || {}), candidates: reg.candidates || [], history: reg.history || [] };
    if (Array.isArray(obj.snaps)) writes.snaps = obj.snaps.slice(0, MAX_SNAPS);
    if (Array.isArray(obj.views)) writes.views = obj.views.slice(0, MAX_VIEWS);
    if (Array.isArray(obj.holdings)) writes.holdings = obj.holdings.filter(h => h && typeof h.hid === 'string' && typeof h.id === 'string').slice(0, MAX_HOLDINGS);
    else if (Array.isArray(obj.lots)) writes.holdings = holdingsFromLots(obj.lots.slice(0, 10000)).slice(0, MAX_HOLDINGS);   // 2.7 / 2.8 export file
    if (writes.holdings) writes.holdingsFrom28 = true;
    if (obj.k && obj.kidx) { Object.assign(writes, obj.k); writes.kidx = obj.kidx; if (idxTimer) { clearTimeout(idxTimer); idxTimer = null; } idxDirty = false; idxCache = null; }
    if (obj.market) writes.market = obj.market;
    if (obj.wdir && typeof obj.wdir === 'object') writes.wdir = Object.fromEntries(Object.entries(obj.wdir).filter(e => /^\d+$/.test(String(e[1]))).slice(0, 5000));
    await enqueue(() => rawSet(writes));
    idxCache = null;
    return Object.keys(writes).length;
  }
  async function resetAll() {
    const keys = ['settings', 'registry', 'snaps', 'views', 'holdings', 'holdingsFrom28', 'lots', 'lotsFrom26', 'market', 'wdir', 'xsec:h7', 'xsec:h14', 'xsec:h30'];
    await clearK();
    await enqueue(() => rawRemove(keys));
  }

  const api = {
    VERSION, persistent: !!area, DEFAULT_SETTINGS, get, set, bytesInUse,
    packSeries, unpackSeries, putK, getK, getKMany, flushIdx, allK, kIndex, isFresh, removeK, clearK, putMarket, getMarket, directory, putDirectory,
    settings, saveSettings, registry, addCandidate, activate, rollback, removeCandidate,
    addSnapshot, snapshots, addView, views, holdings, holdingsFromLots, addHolding, updateHolding, removeHolding, putXsec, getXsec, exportAll, importAll, resetAll,
    _mem: mem, _resetCache: () => { idxCache = null; },
  };
  root.MarketLensStore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
