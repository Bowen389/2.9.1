/* Market Lens Scanner — pure helpers (scan-2.9.0, 2.6.1 line).
   2.9: the scan universe is the fixed whitelist (全部.csv, 816 items). Discovery
   by keyword paging and the per-item youpin quote round of 2.6.1 are gone:
   every whitelist entry ships with its FirePulse id, and the few that do not
   are resolved by a targeted search (one request per base name, results cached
   in the local directory). Prices used for rules and ranking always come from
   悠悠有品 daily K; the youpin ask (detail_price_compare, youpinQuote) is only
   fetched for the recommended picks after the scan, so 2.6.1's "在售价 vs
   买入价上限" check survives at a few dozen requests instead of ~800.
   The old 31-point coarse screen is kept only for tests / reference. */
(function (root) {
  'use strict';
  const VERSION = 'scan-2.9.0';
  const SITE = 'https://firepulse.com.cn';
  const clip = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const avg = a => a.reduce((s, x) => s + x, 0) / a.length;
  const median = a => { const s = a.slice().sort((x, y) => x - y), i = Math.floor(s.length / 2); return s.length % 2 ? s[i] : (s[i - 1] + s[i]) / 2; };
  const sigmoid = x => (1 + Math.tanh(x)) / 2;
  const num = (v, d = 1) => (typeof v === 'number' && Number.isFinite(v) ? v.toFixed(d) : '');

  const DEFAULT_EXCLUDE = ['印花', '贴纸', '武器箱', '通行证', '补丁', '音乐盒', '收藏包', '钥匙', '布章', '徽章', '挂件', '姓名牌'];
  // Request pacing. concurrency / jitter are the *defaults*; the panel lets the
  // user pick 2–4 parallel requests. tries/backoff apply to 429 and 5xx only.
  // maxResolve: cap on directory look-ups per scan (each is one search call).
  // maxQuotes: youpin asks fetched for the recommended picks after a scan;
  // quoteTtlMs: an ask younger than this is reused instead of re-requested.
  const DEFAULTS = { concurrency: 3, delayMin: 150, delayMax: 350, maxRequests: 1500, tries: 3, failStreak: 10, cooldownMs: 8000, maxResolve: 150,
    kDepth: 720, kDepthMax: 1440, kTailPad: 45, kTailMin: 60, liveMs: 1500, maxQuotes: 60, quoteTtlMs: 20 * 60000, candidateThreshold: 65, minSellCount: 1 };
  const BRANCH_NAMES = { reversal: '止跌转折型', pullback: '趋势回撤型', breakout: '突破适配型' };
  // Observed request costs (seconds) used for the pre-scan time estimate.
  const COST = { full: 2.2, full720: 1.4, tail: 0.9, search: 1.6, quote: 1.0 };   // full = 1440 天, full720 = 720 天
  // Youpin listing depth -> 0–100 tradability proxy (2.6.1), NOT a price signal.
  const liquidityOf = cnt => 100 * Math.sqrt(clip(Math.log(1 + (Number.isFinite(cnt) ? Math.max(0, cnt) : 0)) / Math.log(5001)));
  // detail_price_compare -> the single 悠悠有品 sell row. Never substitutes
  // another platform: no youpin row / price 0 (no listing) => not usable.
  function youpinQuote(json) {
    const fail = reason => ({ ok: false, reason });
    if (!json || json.code !== 200 || !json.data) return fail('悠悠报价响应无效');
    const rows = (Array.isArray(json.data.sell) ? json.data.sell : []).filter(r => r && r.platform_key === 'youpin');
    if (rows.length !== 1) return fail(rows.length ? '悠悠报价不唯一' : '悠悠无报价');
    const y = rows[0];
    const price = Number(y.price);
    if (!Number.isFinite(price) || price <= 0) return fail('悠悠当前无在售');
    const count = Number(y.count);
    const trend = (Array.isArray(y.trend) ? y.trend : []).map(Number).filter(x => Number.isFinite(x) && x > 0);
    const chg7 = trend.length >= 2 ? price / trend[0] - 1 : null;
    const fee = Number(y.trade_fee);
    return {
      ok: true, platform: 'youpin', price, count: Number.isFinite(count) ? count : null,
      liquidity: liquidityOf(count), chg7, points: trend.length, tradeFee: Number.isFinite(fee) ? fee : null,
    };
  }

  function itemUrl(id) { return SITE + '/cs2/' + id; }

  // -- whitelist resolution ----------------------------------------------------
  const WEAR_RE = /\s*[(（]\s*(崭新出厂|略有磨损|久经沙场|破损不堪|战痕累累)\s*[)）]\s*$/;
  // Chinese base name = 中文名 without the wear suffix ("AK-47 | 水栽竹"). The
  // search API ranks exact skin matches first, so one call per base name
  // returns every wear of that skin (plus ~95 fuzzy neighbours that often
  // resolve other whitelist entries for free).
  const baseName = name => String(name || '').replace(WEAR_RE, '').trim();
  // Split the whitelist into resolved items and the search terms still needed.
  // wl: [{market_hash_name, name, id?}], dir: {market_hash_name: id} overrides.
  function resolvePlan(wl, dir) {
    const d = dir || {};
    const items = [], missing = [], terms = [], seenTerm = new Set();
    for (const w of wl || []) {
      const id = String(d[w.market_hash_name] || w.id || '');
      if (/^\d+$/.test(id)) { items.push({ id, name: w.name, hash: w.market_hash_name, family: familyOf(w.name) }); continue; }
      missing.push(w);
      const t = baseName(w.name) || w.name;
      if (t && !seenTerm.has(t)) { seenTerm.add(t); terms.push(t); }
    }
    return { items, missing, terms };
  }
  // Absorb one search response: every row whose market_hash_name (or Chinese
  // name) is a whitelist entry yields {hash: id}. Returns the new entries only.
  function absorbSearch(list, wl, known) {
    const byHash = new Map(), byName = new Map();
    for (const w of wl || []) { byHash.set(norm(w.market_hash_name), w); byName.set(norm(w.name), w); }
    const out = {};
    for (const row of Array.isArray(list) ? list : []) {
      const id = String(row && row.id !== undefined && row.id !== null ? row.id : '');
      if (!/^\d+$/.test(id)) continue;
      const w = byHash.get(norm(row.market_hash_name)) || byName.get(norm(row.name));
      if (!w) continue;
      const have = known && (known[w.market_hash_name] || w.id);
      if (!have) out[w.market_hash_name] = id;
    }
    return out;
  }
  const norm = v => String(v == null ? '' : v).replace(/\s+/g, ' ').trim();
  // Family = text before the first "|" ("AK-47", "运动手套（★）", agent name).
  function familyOf(name) { const s = String(name || ''); const i = s.indexOf('|'); return (i > 0 ? s.slice(0, i) : s).trim() || '未分类'; }

  // -- K refresh planning ---------------------------------------------------------
  // Decide what to fetch for one item given its cache meta (kidx entry).
  //   fresh  -> nothing (contains the latest completed day)
  //   tail   -> short window covering the gap since the cache (+ pad, so the
  //             feed's late revisions of recent bars are picked up too)
  //   full   -> first sight (or cache too old to bridge): kDepth days
  function kPlan(meta, todayNum, opts) {
    const o = Object.assign({}, DEFAULTS, opts || {});
    if (!meta || !meta.lastDay || !Number.isFinite(meta.n)) return { mode: 'full', range: o.kDepth };
    const last = Math.round(Date.parse(meta.lastDay + 'T00:00:00Z') / 86400000);
    const behind = todayNum - 1 - last;           // completed days missing from the cache
    if (!Number.isFinite(behind)) return { mode: 'full', range: o.kDepth };
    if (behind <= 0) return { mode: 'fresh', range: 0 };
    const range = Math.max(o.kTailMin, behind + o.kTailPad);
    if (range >= o.kDepth || meta.n < 30) return { mode: 'full', range: o.kDepth };
    return { mode: 'tail', range };
  }
  // Time estimate for a scan: counts of each request kind -> minutes.
  function estimate(counts, opts) {
    const o = Object.assign({}, DEFAULTS, opts || {});
    const c = Object.assign({ full: 0, tail: 0, search: 0 }, counts || {});
    const jitter = (o.delayMin + o.delayMax) / 2000, fullCost = o.kDepth && o.kDepth <= 720 ? COST.full720 : COST.full;
    const secs = (c.full * (fullCost + jitter) + c.tail * (COST.tail + jitter) + c.search * (COST.search + jitter)) / Math.max(1, o.concurrency);
    return { requests: c.full + c.tail + c.search, minutes: secs / 60, minutesLow: secs * 0.7 / 60, minutesHigh: secs * 1.5 / 60 };
  }

  // -- coarse screen (reference only; not used by the panel since 2.5) ----------
  function coarse(row) {
    const fail = reason => ({ ok: false, reason });
    if (!row || typeof row !== 'object') return fail('清单行缺失');
    const id = String(row.id === undefined || row.id === null ? '' : row.id);
    if (!/^\d+$/.test(id)) return fail('商品ID无效');
    const raw = Array.isArray(row.trend) ? row.trend : [];
    if (raw.length < 8) return fail('清单价格序列不足8点');
    const series = raw.map(Number);
    if (!series.every(x => Number.isFinite(x) && x > 0)) return fail('清单价格序列含无效值');
    const price = Number(row.price) > 0 ? Number(row.price) : series[series.length - 1];
    const closes = series.slice(0, -1);
    if (closes.length < 20) return fail('收盘点数不足20');
    const len = closes.length;
    const rets = [];
    for (let i = Math.max(1, len - 30); i < len; i++) rets.push(Math.log(closes[i] / closes[i - 1]));
    const med = median(rets), mad = median(rets.map(r => Math.abs(r - med)));
    const sigma = Math.max(0.005, 1.4826 * mad);
    const sq = h => sigma * Math.sqrt(h);
    const z7 = clip(Math.log(price / closes[len - 7]) / sq(7), -4, 4);
    const zLong = clip(Math.log(price / closes[0]) / sq(len), -4, 4);
    const trend = 100 * sigmoid((0.4 * z7 + 0.6 * zLong) / 2);
    const last20 = closes.slice(-20);
    const high20 = Math.max.apply(null, last20), low20 = Math.min.apply(null, last20);
    const ma5 = avg(closes.slice(-5)), ma20 = avg(last20);
    const dd = (high20 - price) / high20;
    const position = clip((price - low20) / Math.max(high20 - low20, price * 0.001));
    const rebound = Math.log(price / low20) / sigma;
    const depth = Math.log(high20 / low20) / sigma;
    const olderLow = Math.min.apply(null, closes.slice(-20, -3)), recentLow = Math.min.apply(null, closes.slice(-3));
    const stabilization = sigmoid(Math.log(recentLow / olderLow) / sigma);
    const r3 = Math.log(price / closes[len - 3]) / sq(3);
    const prior3 = Math.log(closes[len - 3] / closes[len - 6]) / sq(3);
    const acceleration = sigmoid((r3 - prior3) / 2);
    const recovery = sigmoid(r3);
    const confirmed = r3 > 0 && price >= ma5 && rebound >= 0.5;
    const gate = clip((trend - 35) / 35);
    const sellCount = Number(row.sell_count);
    const hasSupply = Number.isFinite(sellCount) && sellCount >= DEFAULTS.minSellCount;
    const liquidity = 100 * Math.sqrt(clip(Math.log(1 + (Number.isFinite(sellCount) ? Math.max(0, sellCount) : 0)) / Math.log(5001)));
    const liqGate = 0.35 + 0.65 * clip(liquidity / 50);
    const pullLocation = Math.exp(-0.5 * Math.pow((dd / sigma - 1.5) / 2, 2));
    const maDist = Math.log(price / ma20) / sigma;
    const pullback = 100 * gate * liqGate * (0.65 * pullLocation + 0.35 * recovery) * Math.exp(-Math.max(0, -maDist - 3) / 3);
    const breakDistance = Math.log(price / high20) / sigma;
    const breakLocation = sigmoid(2 * breakDistance) * Math.exp(-Math.max(0, breakDistance - 2) / 3);
    const breakout = 100 * gate * liqGate * (0.65 * breakLocation + 0.35 * 0.5);
    const context = clip((depth - 1) / 3);
    const reversalRaw = 100 * (0.20 * (1 - position) + 0.25 * recovery + 0.20 * stabilization + 0.20 * acceleration + 0.15 * 0.5) * (0.35 + 0.65 * context) * (0.5 + 0.5 * stabilization) * liqGate;
    const reversal = confirmed ? reversalRaw : Math.min(59, reversalRaw);
    const branches = { reversal, pullback, breakout };
    const branch = Object.keys(branches).sort((a, b) => branches[b] - branches[a])[0];
    const eligible = hasSupply && liquidity >= 20;
    const entry = eligible ? branches[branch] : Math.min(39, branches[branch]);
    return { ok: true, id, entry, branch, branchName: BRANCH_NAMES[branch], trend, pullback, breakout, reversal, liquidity, eligible, confirmed,
      status: !eligible ? '证据不足 / 暂缓' : entry >= DEFAULTS.candidateThreshold ? '可关注 / ' + BRANCH_NAMES[branch] : entry >= 40 ? '等待确认' : '暂缓',
      reasons: [], risks: ['粗筛缺少成交量数据', '清单价非悠悠口径'], features: { sigma, sellCount: Number.isFinite(sellCount) ? sellCount : null, points: len + 1 } };
  }

  // -- universe ------------------------------------------------------------------
  // rows: resolved items [{id,name,family,...}]; opts.reject(row) -> reason|null
  // (name rules). opts.priority(row) -> number, larger first (holdings first).
  // Families are interleaved so one weapon cannot monopolise the queue head.
  function buildUniverse(rows, opts) {
    const o = Object.assign({ target: Number.MAX_SAFE_INTEGER, reject: null, priority: null }, opts || {});
    const seen = new Map();
    const dropped = { duplicate: 0, rules: 0, invalid: 0 };
    const ruleReasons = {};
    const list = Array.isArray(rows) ? rows : [];
    for (const row of list) {
      const id = String((row && row.id) || '');
      if (!/^\d+$/.test(id)) { dropped.invalid++; continue; }
      if (seen.has(id)) { dropped.duplicate++; continue; }
      const name = String(row.name || '');
      if (typeof o.reject === 'function') {
        const why = o.reject(row);
        if (why) { dropped.rules++; ruleReasons[why] = (ruleReasons[why] || 0) + 1; seen.set(id, null); continue; }
      }
      seen.set(id, { id, name, hash: row.hash || row.market_hash_name || '', family: row.family || familyOf(name),
        row: Object.assign({ platform_key: 'youpin', price: null, rarity: '' }, row.row || {}), coarse: {},
        prio: typeof o.priority === 'function' ? Number(o.priority(row)) || 0 : 0 });
    }
    const all = Array.from(seen.values()).filter(Boolean);
    const first = all.filter(x => x.prio > 0).sort((a, b) => b.prio - a.prio);
    const rest = all.filter(x => !(x.prio > 0));
    const byFamily = new Map();
    for (const it of rest) { if (!byFamily.has(it.family)) byFamily.set(it.family, []); byFamily.get(it.family).push(it); }
    const queues = Array.from(byFamily.entries()).sort((a, b) => b[1].length - a[1].length).map(e => ({ family: e[0], items: e[1], i: 0 }));
    const items = first.slice();
    let guard = 0;
    while (items.length < o.target && guard++ < 100000) {
      let progressed = false;
      for (const q of queues) {
        if (q.i < q.items.length) { items.push(q.items[q.i++]); progressed = true; if (items.length >= o.target) break; }
      }
      if (!progressed) break;
    }
    const familyCounts = {};
    for (const it of items) familyCounts[it.family] = (familyCounts[it.family] || 0) + 1;
    return { items, dropped, ruleReasons, totalRows: list.length, unique: all.length, familyCounts, target: o.target, builtAt: new Date().toISOString() };
  }

  // -- merge / export --------------------------------------------------------
  function mergeRow(item, deep) {
    const d = deep && deep.ok ? deep : null;
    return {
      id: item.id, name: item.name, family: item.family, url: itemUrl(item.id), hash: item.hash || '',
      platform: 'youpin', price: Number(item.row && item.row.price) || null, rarity: (item.row && item.row.rarity) || '',
      deepOk: !!d, deepReason: d ? '' : String((deep && deep.reason) || '未精算'),
      deepEntry: d ? d.entry : null, deepBranch: d ? d.branchName : '', deepStatus: d ? d.status : '',
      deepTrend: d ? d.trend : null, deepPullback: d ? d.pullback : null, deepBreakout: d ? d.breakout : null,
      deepReversal: d ? d.reversal : null, deepLiquidity: d ? d.liquidity : null,
      relativeVolume: d ? d.relativeVolume : null, eligible: d ? d.eligible : null,
      reasons: d ? d.reasons : [], risks: d ? d.risks : [],
      invalidationPrice: d && d.invalidation ? d.invalidation.price : null,
      sigma: d && d.features ? d.features.sigma : null,
    };
  }

  const CSV_COLUMNS = [
    ['name', '商品'], ['hash', 'market_hash_name'], ['family', '类别'], ['id', 'ID'],
    ['selPct', '选品分百分位'], ['selQ', '档'], ['close', '悠悠日K收盘'], ['limit', '买入价上限'], ['ask', '悠悠在售价'], ['askCount', '悠悠在售数'], ['askDay', '在售价读取日'],
    ['fs7', '7日原始分'], ['fs14', '14日原始分'], ['fs30', '30日原始分'], ['tradable', '可交易'], ['selNote', '说明'], ['lastDay', '日K截至'], ['fetch', '本次数据来源'],
    ['deepEntry', 'lab-2.1入场分'], ['deepBranch', '分支'], ['deepStatus', 'lab-2.1状态'], ['deepLiquidity', '流动性'], ['relativeVolume', '相对量'], ['deepReason', '精算失败原因'], ['url', '链接'],
  ];

  function toCSV(rows) {
    const cell = v => {
      if (v === null || v === undefined) return '';
      if (typeof v === 'number') return Number.isFinite(v) ? String(Math.round(v * 1000) / 1000) : '';
      if (Array.isArray(v)) return v.join('；');
      if (typeof v === 'boolean') return v ? '是' : '否';
      return String(v);
    };
    const lines = [CSV_COLUMNS.map(c => c[1]).join(',')];
    for (const r of rows || []) lines.push(CSV_COLUMNS.map(c => '"' + cell(r[c[0]]).replace(/"/g, '""') + '"').join(','));
    return '\uFEFF' + lines.join('\r\n');
  }

  function sortRows(rows, key, dir) {
    const s = dir === 'asc' ? 1 : -1;
    return (rows || []).slice().sort((a, b) => {
      const x = a[key], y = b[key];
      const nx = typeof x === 'number' && Number.isFinite(x), ny = typeof y === 'number' && Number.isFinite(y);
      if (nx && ny) return (x - y) * s;
      if (nx) return -1;
      if (ny) return 1;
      return String(x === null || x === undefined ? '' : x).localeCompare(String(y === null || y === undefined ? '' : y), 'zh') * s;
    });
  }

  function summarize(rows) {
    const list = rows || [];
    const deep = list.filter(r => r.deepOk);
    const failedReasons = {};
    for (const r of list.filter(x => !x.deepOk && x.deepReason && x.deepReason !== '未精算')) failedReasons[r.deepReason] = (failedReasons[r.deepReason] || 0) + 1;
    const byQ = {};
    for (const r of list) if (r.selQ) byQ['Q' + r.selQ] = (byQ['Q' + r.selQ] || 0) + 1;
    return { total: list.length, deep: deep.length, failed: list.length - deep.length, failedReasons, byQ,
      ranked: list.filter(r => typeof r.selPct === 'number' && Number.isFinite(r.selPct)).length, picks: list.filter(r => typeof r.selPct === 'number' && r.selPct >= 80).length,
      scanned: list.filter(r => r.lastDay).length, pending: list.filter(r => !r.lastDay && !r.deepReason).length };
  }

  function report(scan) {
    return {
      version: VERSION, model: (scan && scan.modelVersion) || '', generatedAt: new Date().toISOString(),
      site: SITE, config: scan && scan.config, timing: scan && scan.timing,
      universe: scan && scan.universe ? { totalRows: scan.universe.totalRows, unique: scan.universe.unique, kept: scan.universe.items.length, dropped: scan.universe.dropped, ruleReasons: scan.universe.ruleReasons || {}, familyCounts: scan.universe.familyCounts } : null,
      summary: summarize(scan && scan.rows), rows: scan && scan.rows,
      caveat: '扫描范围为固定白名单（全部.csv）；选品分与价格复核使用悠悠有品日K收盘，悠悠在售价只对买点清单读取。选品分只比较同批商品的相对强弱，不预测涨跌。日K随附成交量的平台范围未核实；真实成交、手续费与7天交易锁需另行核对。',
    };
  }

  const api = {
    VERSION, SITE, DEFAULT_EXCLUDE, DEFAULTS, COST, BRANCH_NAMES, CSV_COLUMNS,
    itemUrl, baseName, familyOf, resolvePlan, absorbSearch, kPlan, estimate, youpinQuote, liquidityOf,
    coarse, buildUniverse, mergeRow, toCSV, sortRows, summarize, report, num,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.MarketLensScanner = api;
})(typeof self !== 'undefined' ? self : typeof globalThis !== 'undefined' ? globalThis : this);
