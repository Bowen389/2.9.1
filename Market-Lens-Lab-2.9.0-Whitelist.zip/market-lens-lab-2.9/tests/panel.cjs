// DOM test for the 2.9 flow: npm install --no-save jsdom@24 ; node tests/panel.cjs
// 2.9 = 2.6.1 product on the 2.8 pipeline. Covers: whitelist → id (shipped +
// one runtime search), cache-aware K fetch (full / same-day cache hit /
// incremental tail merge), concurrency, live progressive 今日买点 list (P80
// picks), youpin asks only for the picks after the scan, auto-pause on a
// failure streak + resume, rule re-rank without requests, 记为已买入 → 我的持仓
// (2.6.1 holdings model, K close as 现价, cache-aware refresh), advanced scan
// table + CSV, and the item page verdict with cache-aware K + youpinBasis.
'use strict';
const { JSDOM } = require('jsdom'), fs = require('fs'), path = require('path'), assert = require('node:assert/strict');
const DAY = 86400000, END = Math.floor(Date.now() / DAY) * DAY; // start of the current UTC day
const FILES = ['legacy-core.js', 'lab-core.js', 'whitelist.js', 'scanner-core.js', 'factor-core.js', 'model-builtin.js', 'store.js', 'buy-core.js', 'panel.js'];
const SRC = FILES.map(f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8'));
const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'manifest.json'), 'utf8'));
const windows = [];
let t = 0;
const test = async (n, f) => { await f(); t++; console.log('PASS', n); };
const wait = ms => new Promise(r => setTimeout(r, ms));
const txt = root => root.textContent;
const plain = v => JSON.parse(JSON.stringify(v)); // cross-realm objects (jsdom window) vs node's deepEqual
async function waitFor(root, pred, label, ms) {
  const t0 = Date.now();
  while (Date.now() - t0 < (ms || 30000)) { if (pred()) return; await wait(40); }
  throw Error('等待超时：' + label + '；当前文本片段：' + txt(root).slice(0, 400));
}
const hash = s => { let h = 7; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; };
// Continuous daily bars for the last `n` days ending with the in-progress
// current UTC day (which the model must ignore). Price is a deterministic
// function of (seed, calendar day) so a short window agrees with a long one.
function kRows(seed, n) {
  const out = [];
  const base = 60 + (seed % 17) * 25;
  for (let i = 0; i < n; i++) {
    const ts = END - (n - 1 - i) * DAY, d = ts / DAY;
    let s = ((seed ^ (d * 2654435761)) >>> 0) || 1;
    const r = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
    const p = base * Math.exp(0.15 * Math.sin(d / 9 + seed % 7) + 0.05 * Math.sin(d / 3.3 + seed % 5) + (r() - 0.5) * 0.04);
    const v = 40 + ((d + seed) % 25);
    out.push([String(ts / 1000), p * 0.998, p, p * 0.985, p * 1.012, v, v * p]);
  }
  return out;
}
function marketRows(n) {
  const out = []; let p = 1000;
  for (let i = 0; i < n; i++) { p *= Math.exp(0.02 * Math.sin(i / 11) * 0.3); out.push([String((END - (n - i) * DAY - 8 * 3600000) / 1000), p, p, p, p, 1, 1]); }
  out.push([String(Math.floor(Date.now() / 1000)), p, p, p, p, 1, 1]);
  return out;
}
const MISSING = { market_hash_name: 'AK-47 | Test Missing (Factory New)', name: 'AK-47 | 测试缺失 (崭新出厂)', id: '' };
const MISSING2 = { market_hash_name: 'AK-47 | Test Missing (Minimal Wear)', name: 'AK-47 | 测试缺失 (略有磨损)', id: '' };
function boot(url, opts) {
  const o = Object.assign({ items: 40, kDelay: 0, title: '测试 <商品>' }, opts || {});
  const mock = { failK: false, kDelay: o.kDelay, askOf: id => 100 + (hash(id) % 200) };
  const dom = new JSDOM('<h1>FirePulse</h1>', { url, runScripts: 'outside-only' }), w = dom.window;
  windows.push(w);
  w.URL.createObjectURL = () => 'blob:mock';
  w.URL.revokeObjectURL = () => { };
  w.confirm = () => true;
  const downloads = [];
  w.HTMLAnchorElement.prototype.click = function () { downloads.push(this.download); };
  const calls = { search: 0, k: 0, base: 0, quote: 0, market: 0, kRanges: [], searchTerms: [], quoteIds: [], maxInflight: 0 };
  let inflight = 0;
  const ok = data => ({ ok: true, status: 200, text: async () => JSON.stringify({ code: 200, data }) });
  w.fetch = async (u, init) => {
    const body = init && init.body ? JSON.parse(init.body) : {};
    if (u.includes('skin_search')) {
      calls.search++; calls.searchTerms.push(body.name);
      return ok({ total: 100, list: [
        { id: 777001, name: MISSING.name, market_hash_name: MISSING.market_hash_name, price: 300 },
        { id: 777002, name: MISSING2.name, market_hash_name: MISSING2.market_hash_name, price: 250 },
        { id: 777003, name: 'AK-47 | 测试缺失 (久经沙场)', market_hash_name: 'AK-47 | Test Missing (Field-Tested)', price: 200 },
      ] });
    }
    if (u.includes('skin_k_chart')) {
      calls.k++; calls.kRanges.push(body.date_range);
      inflight++; calls.maxInflight = Math.max(calls.maxInflight, inflight);
      if (mock.kDelay) await wait(mock.kDelay);
      inflight--;
      if (mock.failK) return { ok: false, status: 500, text: async () => '' };
      return ok(kRows(hash(body.id), Math.min(body.date_range, 800)));
    }
    if (u.includes('category/k/data')) { calls.market++; return ok(marketRows(820)); }
    if (u.includes('skin_detail_base_info')) { calls.base++; return ok({ id: String(body.id), list: [{ id: String(body.id) }], name: o.title }); }
    if (u.includes('detail_price_compare')) { calls.quote++; calls.quoteIds.push(String(body.id)); return ok({ sell: [{ platform_key: 'youpin', price: mock.askOf(String(body.id)), count: 12, trend: [100, 101] }, { platform_key: 'buff', price: 1 }], today_ratio: 1, week_ratio: 2, month_ratio: 4, trade_count_24: 90 }); }
    throw Error('unexpected url ' + u);
  };
  for (const s of SRC) w.eval(s);
  // Shrink the whitelist for speed and append two entries without an id.
  const WL = w.MarketLensWhitelist;
  WL.ITEMS.splice(o.items);
  WL.ITEMS.push(Object.assign({}, MISSING), Object.assign({}, MISSING2));
  // One name the default rules exclude (久经沙场 gun): must never be requested.
  WL.ITEMS.push({ market_hash_name: 'M4A4 | Asiimov (Field-Tested)', name: 'M4A4 | 二西莫夫 (久经沙场)', id: '999001' });
  const D = w.MarketLensScanner.DEFAULTS;
  D.delayMin = 0; D.delayMax = 1; D.tries = 1; D.failStreak = 10; D.cooldownMs = 5; D.liveMs = 40;
  return { dom, w, mock, calls, downloads, ST: w.MarketLensStore, F: w.MarketLensFactor, BY: w.MarketLensBuy, WL, root: w.document.getElementById('market-lens-lab').shadowRoot };
}
const setVal = (w, el, v) => { el.value = v; el.dispatchEvent(new w.Event('change')); };
const setChk = (w, el, v) => { el.checked = v; el.dispatchEvent(new w.Event('change')); };
const clickTab = (root, id) => root.querySelector('[data-tab="' + id + '"]').click();
const progress = root => (root.getElementById('progText') || { textContent: '' }).textContent;

async function scanFlow() {
  const { w, root, calls, downloads, ST, F, BY, WL, mock } = boot('https://firepulse.com.cn/home', { items: 40, kDelay: 12 });
  const rules = F.normRules(F.DEFAULT_RULES);
  const kept = WL.ITEMS.filter(x => !F.ruleReasonName(x.name, rules)).length;
  const excluded = WL.ITEMS.length - kept;
  await test('manifest 2.9.0 = 2.6.1 script list (no buy-point.js / ledger.js); version shown', () => {
    assert.equal(manifest.version, '2.9.0');
    assert.deepEqual(manifest.content_scripts[0].js, FILES);
    assert(txt(root).includes('2.9'));
  });
  await test('non-item page: launch button offers 今日买点; tabs 今日买点 / 我的持仓 / 高级', () => {
    const b = root.getElementById('open'); assert(b && b.textContent.includes('今日买点'));
    b.click();
  });
  await wait(30);
  await test('buy tab (2.6.1 wording): usage note, 持有周期 14/30, whitelist counts, no requests before the click', () => {
    const s = txt(root);
    assert(s.includes('用法：① 点“开始扫描”')); assert(s.includes('记为已买入')); assert(s.includes('所有价格均为悠悠有品口径'));
    assert(s.includes('白名单 ' + WL.ITEMS.length + ' 件（按筛选规则 ' + kept + ' 件）'));
    assert(root.getElementById('bh14') && root.getElementById('bh30'), '14/30 day selector');
    assert(!s.includes('内置样本池') && !s.includes('关键词全市场'), '2.6.1 sources are gone');
    assert.equal(calls.k + calls.search + calls.market + calls.quote, 0);
    assert(root.querySelector('[data-tab="buy"]') && root.querySelector('[data-tab="hold"]') && root.querySelector('[data-tab="adv"]'));
    assert(!root.querySelector('[data-tab="item"]'));
  });
  root.getElementById('buyScan').click();
  await waitFor(root, () => txt(root).includes('② 买点清单'), '边扫边出结果', 8000);
  await test('scan: 今日买点 list (P80 picks) appears while the scan is still running (progressive)', () => {
    const s = txt(root);
    assert(s.includes('扫描进行中：清单随数据到达实时更新'));
    assert(/买点 \d+ 件（选品分 ≥ P80）/.test(s), s.slice(0, 300));
    assert(progress(root).includes('/ ' + kept), 'progress total should be the in-rule count, got: ' + progress(root));
    assert(calls.k < kept, 'still running');
    assert.equal(calls.quote, 0, 'no youpin ask during the K phase');
  });
  await waitFor(root, () => txt(root).includes('扫描完成'), '扫描完成', 20000);
  await test('scan: one search resolved both missing wears; every in-rule item fetched once at 720 days; excluded names never requested', async () => {
    assert.equal(calls.search, 1); assert.deepEqual(calls.searchTerms, ['AK-47 | 测试缺失']);
    assert.equal(calls.k, kept); assert(calls.kRanges.every(r => r === 720), 'first sight = kDepth');
    assert.equal(excluded, 1); assert(!(await ST.kIndex())['999001'], 'rule-excluded name must not be fetched');
    assert.equal(calls.market, 1);
    assert(txt(root).includes('名称规则排除 ' + excluded + ' 件'));
    assert(txt(root).includes('完整 ' + kept));
  });
  await test('scan: runtime-resolved ids are persisted in the directory and used as scan items', async () => {
    assert.deepEqual(plain(await ST.directory()), { [MISSING.market_hash_name]: '777001', [MISSING2.market_hash_name]: '777002' });
    const idx = await ST.kIndex(); assert(idx['777001'] && idx['777002'], 'resolved items were scanned and cached');
    assert.equal(Object.keys(idx).length, kept);
  });
  await test('scan: three parallel requests were in flight (concurrency 3 default)', () => { assert.equal(calls.maxInflight, 3); });
  await waitFor(root, () => txt(root).includes('悠悠在售价已读取'), '买点在售价', 8000);
  let picks;
  await test('after the scan: youpin asks fetched only for the P80 picks (not per scanned item), shown next to 买入价上限', () => {
    const s = txt(root);
    const nPicks = Number((s.match(/买点 (\d+) 件（选品分 ≥ P80）/) || [])[1]);
    assert(nPicks >= 1 && nPicks < kept, 'picks ' + nPicks);
    assert.equal(calls.quote, nPicks, 'one ask per pick');
    picks = Array.from(root.querySelectorAll('#liveResults [data-buy]')).map(e => e.dataset.buy);
    assert.equal(picks.length, nPicks);
    assert(s.includes('悠悠在售价已读取 ' + nPicks + ' / ' + nPicks + ' 件'));
    assert(s.includes('可买') || s.includes('高于上限'));
    assert(s.includes('买入价上限') && s.includes('信号日') && s.includes('首选'));
    assert(root.getElementById('quoteRefresh'), 'manual refresh button');
  });
  await test('ask vs limit: an ask above 收盘 +2% is flagged 高于上限, below is 可买', () => {
    const rows = Array.from(root.querySelectorAll('#liveResults table tr')).slice(1);
    let checked = 0;
    for (const tr of rows) {
      const tds = tr.querySelectorAll('td'); if (tds.length < 5) continue;
      const limit = Number(tds[3].textContent.replace('¥', '')), askTxt = tds[4].textContent, ask = Number((askTxt.match(/¥([\d.]+)/) || [])[1]);
      if (!ask) continue;
      assert.equal(askTxt.includes('高于上限'), ask > limit, askTxt + ' vs ' + limit); checked++;
    }
    assert(checked >= 1);
  });
  const k1 = calls.k, q1 = calls.quote;
  root.getElementById('buyScan').click();
  await waitFor(root, () => txt(root).includes('扫描完成') && progress(root).includes('缓存 ' + kept), '同日重扫全部命中缓存', 8000);
  await wait(80);
  await test('rescan same day: zero K requests, all cache hits, no search; recent asks reused (TTL)', () => {
    assert.equal(calls.k, k1); assert.equal(calls.search, 1);
    assert(txt(root).includes('缓存 ' + kept + ' · 增量 0 · 完整 0'));
    assert.equal(calls.quote, q1, 'asks younger than quoteTtlMs are not re-requested');
  });
  // Age the cache by 10 days → tail fetch of 60 days merged into the cache.
  const idx = await ST.kIndex();
  const before = {};
  for (const id of Object.keys(idx)) { const rec = await ST.getK(id); before[id] = rec.series.n; await ST.putK({ id, name: rec.name, family: rec.family }, F.truncate(rec.series, rec.series.day0 + rec.series.n - 11)); }
  await ST.flushIdx();
  calls.kRanges.length = 0;
  root.getElementById('buyScan').click();
  await waitFor(root, () => txt(root).includes('扫描完成') && progress(root).includes('增量 ' + kept), '增量补齐', 8000);
  await test('rescan next days: only a 60-day tail per item, merged back to the full length', async () => {
    assert.equal(calls.k, k1 + kept);
    assert(calls.kRanges.every(r => r === 60), 'tail range should be max(60, 10+45)=60, got ' + calls.kRanges.slice(0, 5));
    const id = Object.keys(idx)[0], rec = await ST.getK(id);
    assert.equal(rec.series.n, before[id], 'merged series length equals the original full fetch');
    assert.equal(rec.series.lastDay, new Date(END - DAY).toISOString().slice(0, 10));
    assert(txt(root).includes('缓存 0 · 增量 ' + kept + ' · 完整 0'));
  });
  await test('buy tab: switching the holding period (14/30) re-ranks without requests', async () => {
    const k = calls.k;
    const q = calls.quote;
    root.getElementById('bh14').click(); await wait(30);
    assert(txt(root).includes('买点清单 · 持有 14 天')); assert.equal(calls.k, k);
    await waitFor(root, () => !txt(root).includes('正在读取买点商品'), '14 日在售价', 6000);
    const n14 = root.querySelectorAll('#liveResults [data-buy]').length;
    assert(calls.quote >= q && calls.quote <= q + n14, 'only the asks missing for the 14-day picks are read');
    root.getElementById('bh30').click(); await wait(30);
    assert(txt(root).includes('买点清单 · 持有 30 天'));
  });
  await test('manual 刷新在售价 re-requests the asks of the current picks (bounded)', async () => {
    // switching 14 → 30 above auto-read the asks still missing for each list; wait until idle
    await waitFor(root, () => !txt(root).includes('正在读取买点商品') && root.getElementById('quoteRefresh') && !root.getElementById('quoteRefresh').disabled, '在售价空闲', 6000);
    const q = calls.quote, n = root.querySelectorAll('#liveResults [data-buy]').length;
    root.getElementById('quoteRefresh').click();
    await waitFor(root, () => calls.quote >= q + n && !txt(root).includes('正在读取买点商品'), '在售价刷新', 6000);
    assert.equal(calls.quote, q + n);
  });
  // 记为已买入 from the picks → 我的持仓 (2.6.1 holdings): price = youpin ask when read, else K close.
  const buyBtn = root.querySelector('#liveResults [data-buy]');
  const pickId = buyBtn.dataset.buy;
  buyBtn.click();
  await waitFor(root, () => txt(root).includes('已记入“我的持仓”'), '记为已买入', 3000);
  await test('记为已买入: saves a 2.6.1 holding {buyDay, buyPrice = ask, qty 1, h 30, sellBy}, button turns into 已在持仓', async () => {
    const hs = await ST.holdings(); assert.equal(hs.length, 1);
    const h = hs[0];
    assert.equal(h.id, pickId); assert.equal(h.h, 30); assert.equal(h.qty, 1); assert.equal(h.status, 'open');
    assert.equal(h.buyPrice, mock.askOf(pickId), 'default price = youpin ask read for this pick');
    assert.equal(h.sellBy, BY.addDays(h.buyDay, 30)); assert(typeof h.hid === 'string' && h.hid.length > 3);
    assert(Number.isFinite(h.pctAtBuy) && h.pctAtBuy >= 80, 'pctAtBuy is the P80+ score');
    assert(txt(root).includes('建议持有到 ' + h.sellBy));
    assert(!Array.from(root.querySelectorAll('#liveResults [data-buy]')).some(e => e.dataset.buy === pickId), 'pick now shows 已在持仓');
  });
  clickTab(root, 'hold'); await wait(60);
  await test('我的持仓 (2.6.1 view): open lot with 现价 = latest youpin K close (no request), editable price/qty, 到期 date', async () => {
    const s = txt(root);
    assert(s.includes('我的持仓')); assert(s.includes('持有中'));
    assert(root.querySelector('[data-hbp]') && root.querySelector('[data-hqty]') && root.querySelector('[data-hsell]') && root.querySelector('[data-hdel]'));
    assert(root.getElementById('holdRefresh'));
    assert(!s.includes('—元') && /现价|最近收盘/.test(s));
  });
  await test('我的持仓: 刷新现价 is cache-aware (same-day cache → 0 K requests)', async () => {
    const k = calls.k;
    root.getElementById('holdRefresh').click();
    await waitFor(root, () => txt(root).includes('现价已更新'), '现价刷新', 5000);
    assert.equal(calls.k, k); assert(txt(root).includes('用今日缓存，未发请求'));
  });
  await test('我的持仓: edit qty, mark sold (default sell price = K close), reopen, delete', async () => {
    setVal(w, root.querySelector('[data-hqty]'), '3'); await wait(40);
    assert.equal((await ST.holdings())[0].qty, 3);
    root.querySelector('[data-hsell]').click(); await wait(60);
    let h = (await ST.holdings())[0]; assert.equal(h.status, 'sold'); assert(h.sellPrice > 0); assert.equal(h.sellDay, BY.bjDay());
    assert(txt(root).includes('已标记卖出'));
    root.querySelector('[data-hreopen]').click(); await wait(60);
    h = (await ST.holdings())[0]; assert.equal(h.status, 'open'); assert.equal(h.sellPrice, null);
    root.querySelector('[data-hdel]').click(); await wait(60);
    assert.equal((await ST.holdings()).length, 0); assert(txt(root).includes('已删除'));
  });
  // Advanced → scan table, sort, CSV.
  clickTab(root, 'adv'); await wait(20);
  await test('advanced scan view (2.6.1 columns + 来源/在售价): table, coverage note, speed settings, CSV/JSON export', async () => {
    const s = txt(root);
    assert(s.includes('市场扫盘')); assert(s.includes('速度设置')); assert(s.includes('旧入场')); assert(s.includes('lab-2.1 状态'));
    assert(root.querySelectorAll('#liveResults table tr').length > 5);
    assert(s.includes('已精算 ' + kept)); assert(s.includes('选品分参与排名'));
    assert(!root.getElementById('kw') && !root.getElementById('scanPool'), 'no keyword textarea / pool button');
    root.getElementById('scanCsv').click(); await wait(20);
    assert(downloads.some(d => /market-lens-scan-.*\.csv$/.test(d)));
    root.getElementById('scanJson').click(); await wait(20);
    assert(downloads.some(d => /market-lens-scan-.*\.json$/.test(d)));
  });
  await test('rules: turning off the wear filter re-ranks instantly without any request', async () => {
    const k = calls.k;
    root.getElementById('goRules') && root.getElementById('goRules').click(); await wait(10);
    setChk(w, root.getElementById('ruOn'), false);
    root.getElementById('ruSave').click(); await wait(60);
    assert(txt(root).includes('已保存')); assert.equal(calls.k, k);
    setChk(w, root.getElementById('ruOn'), true); root.getElementById('ruSave').click(); await wait(30);
  });
  await test('speed settings: concurrency / depth persist', async () => {
    setVal(w, root.getElementById('setConc'), '4'); await wait(20);
    assert.equal((await ST.settings()).concurrency, 4);
    setVal(w, root.getElementById('setDepth'), '1440'); await wait(20);
    assert.equal((await ST.settings()).kDepth, 1440);
    setVal(w, root.getElementById('setDepth'), '720'); await wait(10);
  });
  // Failure streak → auto pause → resume.
  await test('resilience: 10 consecutive failures auto-pause, resume finishes the queue', async () => {
    root.getElementById('scanReset').click(); await wait(10);
    const idx2 = await ST.kIndex();
    for (const id of Object.keys(idx2)) { const rec = await ST.getK(id); await ST.putK({ id, name: rec.name, family: rec.family }, F.truncate(rec.series, rec.series.day0 + rec.series.n - 6)); }
    await ST.flushIdx();
    mock.failK = true;
    root.getElementById('scanRun').click();
    await waitFor(root, () => txt(root).includes('已自动暂停'), '自动暂停', 8000);
    assert(txt(root).includes('继续扫描'));
    const failedSoFar = Number((progress(root).match(/失败 (\d+)/) || [])[1]);
    assert(failedSoFar >= 10 && failedSoFar < kept, 'paused early, got ' + failedSoFar);
    mock.failK = false;
    root.getElementById('scanRun').click();
    await waitFor(root, () => txt(root).includes('扫描完成'), '继续后完成', 10000);
  });
  await test('paper tracking snapshot recorded per horizon (2.6.1 format: items only)', async () => {
    const snaps = await ST.snapshots(); assert(snaps.length >= 3);
    assert(snaps[0].items.length >= 10); assert.equal(snaps[0].buyItems, undefined);
  });
  await test('learn tab: sample statistics reflect the scanned whitelist; 2.6.1 default cost 1%', async () => {
    clickTab(root, 'learn'); await wait(60);
    assert(txt(root).includes('半自动学习'));
    root.getElementById('stRefresh').click(); await wait(60);
    assert(new RegExp(kept + ' 件').test(txt(root)));
    assert.equal((await ST.settings()).fee, 0.01);
  });
  await test('store: a 2.8 export (lots) imports as 2.6.1 holdings', async () => {
    const n = await ST.importAll({ app: 'market-lens-lab', lots: [{ key: 'lot-x', id: '123', name: 'X', price: 10, quantity: 2, at: '2026-09-20T04:00:00.000Z', targetDays: 14, status: 'open' }] });
    assert(n >= 1);
    const hs = await ST.holdings(); assert.equal(hs.length, 1); assert.equal(hs[0].id, '123'); assert.equal(hs[0].qty, 2); assert.equal(hs[0].h, 14); assert.equal(hs[0].buyDay, '2026-09-20');
  });
}

async function itemPage() {
  const { w, root, calls, ST, WL } = boot('https://firepulse.com.cn/cs2/' + require('../whitelist.js').ITEMS[1].id, { items: 5 });
  const id = WL.ITEMS[1].id;
  await test('item page: launch button offers 单品买点', () => assert(root.getElementById('open').textContent.includes('单品买点')));
  root.getElementById('open').click();
  await waitFor(root, () => txt(root).includes('买点结论'), '单品买点结论', 8000);
  await test('item (2.6.1 view): verdict card + ①②③ factor cards + lab-2.1 details; K fetched once at 720 days and cached; youpin basis', async () => {
    const s = txt(root);
    assert(s.includes('买点结论 · 持有 30 天')); assert(s.includes('② 选品分')); assert(s.includes('① 大盘环境')); assert(s.includes('lab-2.1 历史日期验证'));
    assert(s.includes('悠悠在售报价 ¥')); assert(s.includes('日K完整抓取'));
    assert.equal(calls.k, 1); assert.equal(calls.kRanges[0], 720); assert.equal(calls.base, 1); assert.equal(calls.quote, 1);
    assert((await ST.kIndex())[id], 'K cached');
    assert(!s.includes('不在白名单'));
  });
  await test('item: 刷新数据 reuses the same-day cache (no K request)', async () => {
    root.getElementById('refresh').click();
    await waitFor(root, () => txt(root).includes('日K来自今日缓存'), '缓存命中', 5000);
    assert.equal(calls.k, 1); assert.equal(calls.base, 2);
  });
  await test('item: 记为已买入 records the live youpin ask into 我的持仓 (2.6.1 flow)', async () => {
    assert(root.querySelector('[data-tab="item"]') && root.querySelector('[data-tab="buy"]') && root.querySelector('[data-tab="hold"]'));
    const btn = root.getElementById('itemBuy');
    if (btn) {
      btn.click(); await wait(40);
      const hs = await ST.holdings(); assert.equal(hs.length, 1); assert.equal(hs[0].id, String(id)); assert(hs[0].buyPrice > 0);
      assert(txt(root).includes('已在“我的持仓”里'));
    } else assert(txt(root).includes('买点结论'), 'verdict is not a buy → no button (allowed)');
  });
  await test('item: 今日买点 tab reachable from an item page and scan works there too', async () => {
    clickTab(root, 'buy'); await wait(20);
    assert(txt(root).includes('今日买点'));
    root.getElementById('buyScan').click();
    await waitFor(root, () => txt(root).includes('扫描完成'), '扫描完成', 8000);
    assert(txt(root).includes('缓存 1'), 'the item just viewed is a cache hit inside the scan');
  });
  const kBefore = calls.k, baseBefore = calls.base;
  w.history.pushState({}, '', '/cs2/456');
  await waitFor(root, () => calls.base > baseBefore, 'SPA 切换后重新读取', 5000);
  await test('item: SPA switch reloads the new item (not in the whitelist → labelled, K fetched fresh)', async () => {
    await waitFor(root, () => txt(root).includes('买点结论 · 持有'), '新商品结论', 5000);
    assert.equal(calls.k, kBefore + 1); assert(txt(root).includes('不在白名单'));
  });
}

(async () => {
  try {
    await scanFlow();
    await itemPage();
    console.log(`${t} tests passed`);
  } catch (e) { console.error('FAIL', e && e.stack || e); process.exitCode = 1; }
  finally { for (const w of windows) w.close(); }
})();
