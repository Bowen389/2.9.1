// node tests/factor.cjs — factor-core / store / builtin model unit tests (no DOM).
'use strict';
const assert = require('node:assert/strict');
const F = require('../factor-core.js');
const N = require('../lab-core.js');
const B = require('../model-builtin.js');
const ST = require('../store.js');
const DAY = 86400000;
let passed = 0;
const pending = [];
const test = (name, fn) => pending.push([name, fn]);

function rnd(seed) { let s = seed >>> 0 || 1; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
// Synthetic item K: [t_sec, o, c, l, h, v, turnover] at 00:00 UTC.
function itemRows(seed, n, start, opts) {
  const o = opts || {}, r = rnd(seed), out = [];
  let p = 50 + seed % 200, recent = [];
  for (let i = 0; i < n; i++) {
    const shock = (r() - 0.5) * 0.06;
    const rev = o.revert ? -o.revert * recent.reduce((a, b) => a + b, 0) : 0;
    const ret = 0.0003 + shock + rev;
    recent.push(ret); if (recent.length > 5) recent.shift();
    p *= Math.exp(ret);
    const v = Math.floor(r() * 30) + 3;
    out.push([String((start + i * DAY) / 1000), p * 0.999, p, p * 0.99, p * 1.01, v, v * p]);
  }
  return out;
}
// Market rows stamped at 16:00 UTC of the previous UTC day (= 00:00 Beijing).
function marketRows(n, start) {
  const r = rnd(424242), out = []; let p = 1000;
  for (let i = 0; i < n; i++) { p *= Math.exp((r() - 0.5) * 0.02); out.push([String((start + i * DAY - 8 * 3600000) / 1000), p, p, p, p, 1, 1]); }
  return out;
}
const START = Date.UTC(2024, 0, 1), NDAYS = 700, END = START + NDAYS * DAY;
const market = F.toSeries(marketRows(NDAYS, START), { cols: 'market', end: END });

test('toSeries: item bars keep their UTC date, index bars (16:00 UTC) map to the Beijing date', () => {
  const s = F.toSeries(itemRows(1, 10, START), { end: START + 10 * DAY });
  assert.equal(s.firstDay, '2024-01-01');
  assert.equal(market.firstDay, '2024-01-01', 'index bar stamped 2023-12-31T16:00Z is the 2024-01-01 Beijing bar');
  assert.equal(market.lastDay, F.dayStr(F.dayNumOf('2024-01-01') + NDAYS - 1));
});
test('toSeries: in-progress bar (t >= end) excluded; gaps filled and flagged stale', () => {
  const rows = itemRows(2, 30, START).filter((r, i) => i !== 10);
  const s = F.toSeries(rows, { end: START + 29 * DAY });
  assert.equal(s.n, 29);
  assert.equal(s.real[10], 0); assert.equal(s.stale[10], 1); assert.equal(s.c[10], s.c[9]); assert.equal(s.v[10], 0);
});
test('featuresAt: corrupting the future does not change features (no look-ahead)', () => {
  const rows = itemRows(3, NDAYS, START);
  const s1 = F.toSeries(rows, { end: END }), i = 400;
  const bad = rows.map((r, k) => (k > i ? [r[0], 1, 9999, 1, 10000, 99999, 1] : r));
  const s2 = F.toSeries(bad, { end: END });
  assert.deepEqual(F.featuresAt(s1, i, market), F.featuresAt(s2, i, market));
});
test('labBranches reproduces lab-core evaluate exactly on gap-free data', () => {
  const rows = itemRows(4, 300, START), s = F.toSeries(rows, { end: START + 300 * DAY });
  for (const i of [120, 200, 299]) {
    const ev = N.evaluate({ code: 200, data: rows.slice(0, i + 1) }, rows[i][2], START + (i + 1) * DAY);
    const lb = F.labBranches(s, i, rows[i][2]);
    for (const k of ['entry', 'reversal', 'pullback', 'breakout', 'trend', 'liquidity']) assert.equal(lb[k], ev[k], k + ' @' + i);
  }
});
const items = Array.from({ length: 60 }, (_, k) => ({ id: 'i' + k, name: 'item ' + k, family: 'f' + (k % 5), series: F.toSeries(itemRows(100 + k, NDAYS, START, { revert: 0.35 }), { end: END }) }));
const keys = F.FEATURE_KEYS.filter(k => !k.startsWith('lab'));
let panel = null;
test('buildPanelAsync returns exactly the same rows as buildPanel', async () => {
  const a = F.buildPanel(items.slice(0, 8), market, { step: 3, keys });
  const b = await F.buildPanelAsync(items.slice(0, 8), market, { step: 3, keys });
  assert.equal(a.rows.length, b.rows.length);
  for (let r = 0; r < a.rows.length; r++) { assert.equal(a.rows[r].d, b.rows[r].d); assert.deepEqual(Array.from(a.rows[r].x), Array.from(b.rows[r].x)); }
});
test('panel targets: y[h] = ln(C[t+1+h] / C[t+1]) (entry the day after the signal)', () => {
  panel = F.buildPanel(items, market, { step: 2, keys });
  const row = panel.rows[500], s = items[row.it].series, i = row.d - s.day0;
  assert.ok(Math.abs(row.y[14] - Math.log(s.c[i + 15] / s.c[i + 1])) < 1e-12);
  const last = panel.rows.filter(r => r.it === 0).pop();
  assert.ok(Number.isNaN(last.y[30]), 'targets beyond the data must be NaN');
});
test('crossIC finds the planted short-term reversal (mom7 negative) and t is on non-overlapping days', () => {
  const ic = F.crossIC(panel, F.featFn(panel, 'mom7'), 7);
  assert.ok(ic.mean < -0.02 && ic.t < -2, 'expected significantly negative IC, got ' + ic.mean + ' t ' + ic.t);
  assert.ok(ic.nonOverlap < ic.n);
});
test('ridge on demeaned normal equations recovers a planted linear signal', () => {
  const P = { keys: ['a', 'b', 'c'], lag: 1, step: 1, horizons: [7], rows: [], byDay: new Map(), days: [] };
  const r = rnd(9);
  for (let d = 0; d < 150; d++) {
    const ids = [];
    for (let k = 0; k < 40; k++) {
      const a = r() - 0.5, b = r() - 0.5, c = r() - 0.5;
      ids.push(P.rows.length);
      P.rows.push({ d, it: k, x: Float32Array.from([a, b, c]), y: { 7: 0.8 * a - 0.4 * b + 0.05 * (r() - 0.5) }, ym: { 7: 0 } });
    }
    P.byDay.set(d, ids); P.days.push(d);
  }
  const st = F.fitStats(P, P.rows.map((_, i) => i), P.keys);
  const w = F.ridge(F.normalEq(P, P.days, P.keys, st, 7), 1);
  assert.ok(w[0] > 0 && w[1] < 0 && Math.abs(w[2]) < Math.abs(w[1]) / 3, 'weights ' + w.map(x => x.toFixed(3)));
});
test('train(): purge gap between dev and test, gates reported, model scores finite', () => {
  const r = F.train(panel, { h: 7, keys: B.keys, lambdas: [3, 30], folds: 3 });
  assert.equal(r.ok, true, r.reason);
  const purge = Math.ceil((7 + panel.lag) / panel.step);
  const matured = panel.days.filter(d => (panel.byDay.get(d) || []).filter(x => Number.isFinite(panel.rows[x].y[7])).length >= 30);
  const testFirst = F.dayNumOf(r.model.train.testFirst), idx = matured.indexOf(testFirst);
  assert.ok(idx > purge, 'test window must start after the purge gap');
  assert.equal(r.gates.length, 5);
  assert.ok(r.model.features.every(f => Number.isFinite(f.w)));
  assert.ok(Math.abs(r.model.features.reduce((s, f) => s + Math.abs(f.w), 0) - 1) < 1e-9);
  assert.ok(r.test.ic.mean > 0, 'planted reversal should give positive holdout IC, got ' + r.test.ic.mean);
});
test('train(): the model records the filter rules it was trained under', () => {
  const pr = F.buildPanel(items, market, { step: 2, keys, rules: F.DEFAULT_RULES });
  assert.equal(pr.nItems, items.length, 'synthetic items are "other" type priced ¥50+ → all inside the rules');
  const r = F.train(pr, { h: 7, keys: B.keys, lambdas: [30], folds: 3 });
  assert.equal(r.ok, true, r.reason);
  assert.equal(r.model.train.rulesKey, F.rulesKey(F.DEFAULT_RULES));
  assert.deepEqual(r.model.train.rules, F.normRules(F.DEFAULT_RULES));
  assert.equal(r.model.train.items, pr.nItems);
  const r0 = F.train(panel, { h: 7, keys: B.keys, lambdas: [30], folds: 3 });
  assert.equal(r0.model.train.rulesKey, 'off');
});
test('walkForward(): every OOS score comes from a fit that ended before it (no leakage)', () => {
  const wf = F.walkForward(panel, { h: 7, keys: B.keys, every: 60, minTrainDays: 120 });
  assert.ok(wf.fits.length >= 2);
  const first = F.dayNumOf(wf.firstDay);
  for (const row of panel.rows) if (row.d < first) assert.ok(Number.isNaN(wf.scorer(row)), 'no OOS score before the first refit');
  for (let k = 1; k < wf.fits.length; k++) assert.ok(wf.fits[k].trainDays > wf.fits[k - 1].trainDays, 'expanding window');
});
test('portfolioSim: gate=false keeps the top book in cash; universe benchmark unaffected', () => {
  const fn = F.featFn(panel, 'mom7');
  const a = F.portfolioSim(panel, x => -fn(x), { h: 14, topN: 5, gate: () => false });
  const b = F.portfolioSim(panel, x => -fn(x), { h: 14, topN: 5 });
  assert.equal(a.top.total, 0); assert.equal(a.inCash, a.periods);
  assert.equal(a.universe.total, b.universe.total);
  assert.ok(b.top.pickWinRate >= 0 && b.top.pickWinRate <= 1);
});
test('paperTrack: matured snapshot evaluated, fresh snapshot pending', () => {
  const byId = new Map(items.map(x => [x.id, x.series]));
  const d = F.dayStr(items[0].series.day0 + 500);
  const snapOld = { day: d, h: 7, modelId: 'm', items: items.map(x => [x.id, -F.featuresAt(x.series, 500, market).f.mom7, 0]) };
  const snapNew = { day: F.dayStr(items[0].series.day0 + NDAYS - 3), h: 7, modelId: 'm', items: snapOld.items };
  const p = F.paperTrack([snapNew, snapOld], byId, { cost: 0.02 });
  assert.equal(p.pending, 1);
  assert.equal(p.summary.length, 1); assert.equal(p.summary[0].snaps, 1);
  assert.ok(Number.isFinite(p.summary[0].ic));
});
test('percentileOf / bucketOf / explain', () => {
  const ref = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  assert.equal(F.percentileOf(0, ref), 0); assert.equal(F.percentileOf(11, ref), 100); assert.equal(F.percentileOf(5, ref), 45);
  assert.equal(F.bucketOf(0), 1); assert.equal(F.bucketOf(99.9), 5); assert.equal(F.bucketOf(100), 5); assert.equal(F.bucketOf(null), null);
  const ex = F.explain([{ key: 'ma20dist', z: -2, contrib: 0.3, w: -0.15, x: -2 }, { key: 'volLvl', z: 1, contrib: -0.12, w: -0.12, x: -3 }], 5);
  assert.equal(ex[0].text, '低于MA20（短期回调）'); assert.equal(ex[0].sign, '+');
  assert.equal(ex[1].text, '波动高'); assert.equal(ex[1].sign, '−');
});
test('builtin models: structure, normalized weights, sorted reference, pool', () => {
  assert.deepEqual(Object.keys(B.models), ['h7', 'h14', 'h30']);
  for (const h of [7, 14, 30]) {
    const m = B.models['h' + h];
    assert.equal(m.h, h); assert.equal(m.features.length, 12); assert.equal(m.source, 'builtin');
    assert.ok(Math.abs(m.features.reduce((s, f) => s + Math.abs(f.w), 0) - 1) < 1e-3);
    const r = m.reference.sorted; for (let i = 1; i < r.length; i++) assert.ok(r[i] >= r[i - 1]);
    assert.equal(m.oos.quintiles.length, 5);
    assert.ok(m.oos.ic > 0.05, 'shipped OOS IC ' + m.oos.ic);
  }
  assert.ok(B.pool.length >= 200 && B.pool.every(p => typeof p.id === 'string' && p.name && p.price > 0));
  // lab-2.4: validated inside the default filter rules
  assert.deepEqual(B.rules, F.normRules(F.DEFAULT_RULES)); assert.equal(B.rulesKey, F.rulesKey(F.DEFAULT_RULES));
  const inRules = B.pool.filter(p => F.ruleCheck(p.name, p.price, B.rules).ok);
  assert.ok(inRules.length >= 100 && inRules.length <= 150, 'pool inside default rules: ' + inRules.length);
  for (const h of [7, 14, 30]) {
    const m = B.models['h' + h];
    assert.equal(m.oos.universe, 'rules'); assert.equal(m.reference.rulesKey, B.rulesKey);
    assert.ok(m.reference.n >= 50, 'reference cross-section size');
    assert.ok(m.oos.quintiles.every(q => 'medExcess' in q));
    assert.ok(/^builtin24-/.test(m.id));
  }
  assert.ok(['V0', 'V1'].includes(B.choice.chosen));
  const sc = F.scoreAt(items[0].series, market, B.models.h14);
  assert.equal(sc.ok, true); assert.ok(Number.isFinite(sc.score)); assert.ok(sc.coverage > 0.9);
});
// ---- filter rules (lab-2.4) ----
test('rules: classifyName on real FirePulse / 悠悠 names', () => {
  const c = n => F.classifyName(n);
  assert.deepEqual(c('AK-47 | 黄金藤蔓 (崭新出厂)'), { kind: 'gun', wear: '崭新出厂', statTrak: false, souvenir: false });
  assert.deepEqual(c('M9 刺刀（★ StatTrak™） | 虎牙 (崭新出厂)'), { kind: 'knife', wear: '崭新出厂', statTrak: true, souvenir: false });
  assert.equal(c('爪子刀（★） | 澄澈之水 (崭新出厂)').kind, 'knife');
  assert.equal(c('爪子刀（★）').kind, 'knife');
  assert.deepEqual(c('双持贝瑞塔（纪念品） | 蔷薇 (崭新出厂)'), { kind: 'gun', wear: '崭新出厂', statTrak: false, souvenir: true });
  assert.equal(c('运动手套（★） | 迈阿密风云 (久经沙场)').kind, 'glove');
  assert.equal(c('专业手套（★） | 深红和服 (略有磨损)').kind, 'glove');
  assert.equal(c('封装的涂鸦 | 法玛斯压枪 (群青)').kind, 'other');
  assert.equal(c('SSG 08 | 橙黄镂刻（战痕累累）').wear, '战痕累累');   // full-width parentheses
  assert.equal(c('').kind, 'other'); assert.equal(c(null).kind, 'other');
});
test('rules: default rules = FN/MW guns, no knives / StatTrak / souvenir, ¥30–20000 inclusive', () => {
  const R = F.normRules(null);
  assert.deepEqual(R, { enabled: true, gunWears: ['崭新出厂', '略有磨损'], excludeKnife: true, excludeStatTrak: true, excludeSouvenir: true, priceMin: 30, priceMax: 20000, excludeWords: [] });
  const ok = (n, p) => F.ruleCheck(n, p, R).ok, code = (n, p) => F.ruleCheck(n, p, R).code;
  assert.ok(ok('AK-47 | 红线 (略有磨损)', 100));
  assert.equal(code('AK-47 | 红线 (久经沙场)', 100), 'wear');
  assert.equal(code('AK-47 | 红线 (破损不堪)', 100), 'wear');
  assert.equal(code('AK-47（StatTrak™） | 红线 (崭新出厂)', 100), 'stattrak');
  assert.equal(code('音乐盒（StatTrak™） | 某作品', 100), 'stattrak');          // StatTrak™ removed for every item type
  assert.equal(code('双持贝瑞塔（纪念品） | 蔷薇 (崭新出厂)', 100), 'souvenir');
  assert.equal(code('爪子刀（★） | 澄澈之水 (崭新出厂)', 100), 'knife');
  assert.ok(ok('运动手套（★） | 迈阿密风云 (战痕累累)', 5000), 'gloves: no wear rule, price only');
  assert.ok(ok('封装的涂鸦 | 法玛斯压枪 (群青)', 45), 'other types: price only');
  assert.ok(ok('印花 | 某战队 (全息)', 45) && ok('某某武器箱', 45));
  assert.equal(code('封装的涂鸦 | 法玛斯压枪 (群青)', 12), 'cheap');
  assert.ok(ok('AK-47 | x (崭新出厂)', 30) && ok('AK-47 | x (崭新出厂)', 20000));
  assert.equal(code('AK-47 | x (崭新出厂)', 29.99), 'cheap');
  assert.equal(code('AK-47 | x (崭新出厂)', 20000.01), 'expensive');
  assert.ok(ok('AK-47 | x (崭新出厂)', null), 'unknown price is decided later (after the daily K is known)');
  const off = F.normRules({ enabled: false });
  assert.ok(F.ruleCheck('爪子刀（★） | x (战痕累累)', 1, off).ok);
  assert.equal(F.rulesText(off), '未启用（不过滤商品）'); assert.equal(F.rulesKey(off), 'off');
  assert.equal(F.rulesText(R), '枪皮仅崭新出厂/略有磨损 · 去刀具 · 去StatTrak™ · 去纪念品 · 价格¥30–20000');
});
test('rules: normRules sanitises storage/import input; rulesKey tracks every field', () => {
  const r = F.normRules({ priceMin: '500', priceMax: '100', gunWears: ['略有磨损', '胡写'], excludeWords: '印花，贴纸  武器箱', excludeKnife: 0 });
  assert.equal(r.priceMin, 100); assert.equal(r.priceMax, 500);
  assert.deepEqual(r.gunWears, ['略有磨损']); assert.deepEqual(r.excludeWords, ['印花', '贴纸', '武器箱']); assert.equal(r.excludeKnife, false);
  assert.equal(F.normRules({ priceMax: '' }).priceMax, null); assert.equal(F.normRules({ priceMax: null }).priceMax, null);
  assert.equal(F.normRules({ priceMin: -5 }).priceMin, 0);
  assert.equal(F.ruleCheck('某某武器箱', 50, r).code, 'word');
  const base = F.rulesKey(F.DEFAULT_RULES);
  assert.equal(base, F.rulesKey(null));
  for (const patch of [{ priceMin: 31 }, { priceMax: null }, { excludeKnife: false }, { excludeStatTrak: false }, { excludeSouvenir: false }, { gunWears: ['崭新出厂'] }, { excludeWords: ['印花'] }, { enabled: false }])
    assert.notEqual(F.rulesKey(Object.assign({}, F.DEFAULT_RULES, patch)), base, JSON.stringify(patch));
  assert.ok(!F.rulesText(F.normRules({ priceMax: null, priceMin: 0 })).includes('¥'));
});
test('rules in panels: name rules drop items; the price rule is point-in-time (sample-day close)', () => {
  const mk = (id, name, rows) => ({ id, name, family: 'f', series: F.toSeries(rows, { end: END }) });
  // price path: ~20 for the first 350 days, then ~60 (crosses the ¥30 floor)
  const cross = itemRows(7, NDAYS, START).map((r, i) => { const k = i < 350 ? 20 / r[2] : 60 / r[2]; return [r[0], r[1] * k, r[2] * k, r[3] * k, r[4] * k, r[5], r[6]]; });
  const its = [
    mk('g', 'AK-47 | 测试 (崭新出厂)', cross),
    mk('k', '爪子刀（★） | 测试 (崭新出厂)', itemRows(8, NDAYS, START)),
    mk('w', 'AK-47 | 测试 (久经沙场)', itemRows(9, NDAYS, START)),
  ];
  const p = F.buildPanel(its, market, { step: 5, keys: ['mom7', 'liq'], skipLab: true, rules: F.DEFAULT_RULES });
  assert.deepEqual(new Set(p.rows.map(r => r.it)), new Set([0]), 'only the FN gun skin survives the name rules');
  assert.equal(p.nItems, 1); assert.equal(p.ruleStats.excludedItems.knife, 1); assert.equal(p.ruleStats.excludedItems.wear, 1);
  assert.ok(p.rows.length > 0 && p.rows.every(r => r.close >= 30 && r.close <= 20000), 'every kept row priced inside the range on its own day');
  const s = its[0].series;
  assert.ok(p.rows.every(r => r.d - s.day0 >= 350), 'days when the item cost ~¥20 are excluded even though it costs ~¥60 today');
  assert.ok(p.ruleStats.priceRows > 0);
  const noRules = F.buildPanel(its, market, { step: 5, keys: ['mom7', 'liq'], skipLab: true });
  assert.equal(noRules.nItems, 3); assert.equal(noRules.ruleStats, null);
});
test('quantiles: median-based excess reported next to the mean', () => {
  const p = F.buildPanel(items.slice(0, 40), market, { step: 7, keys: ['mom7', 'liq'], skipLab: true });
  const q = F.quantiles(p, F.featFn(p, 'mom7'), 14, { minN: 20 });
  assert.equal(q.groups.length, 5);
  for (const g of q.groups) assert.ok(Number.isFinite(g.medExcess), 'medExcess');
});
test('ownHistory: percentile within the item\'s own past, no future data', () => {
  const s = items[1].series;
  const o = F.ownHistory(s, market, B.models.h14, { lookback: 365, step: 3 });
  assert.equal(o.ok, true); assert.ok(o.pct >= 0 && o.pct <= 100); assert.ok(o.n > 50);
  const d = s.day0 + 450;
  const cut = F.truncate(s, d);
  assert.equal(F.ownHistory(s, market, B.models.h14, { day: d }).pct, F.ownHistory(cut, market, B.models.h14, {}).pct);
});
// ---- store (memory backend) ----
test('store: series pack/unpack round-trip (float32 precision)', () => {
  const s = items[2].series, u = ST.unpackSeries(ST.packSeries(s));
  assert.equal(u.ok, true); assert.equal(u.n, s.n); assert.equal(u.lastDay, s.lastDay);
  for (let i = 0; i < s.n; i += 37) { assert.ok(Math.abs(u.c[i] / s.c[i] - 1) < 1e-6); assert.equal(u.real[i], s.real[i]); assert.equal(u.stale[i], s.stale[i]); }
});
test('store: K cache put/get/all/isFresh', async () => {
  await ST.putK({ id: 'x1', name: 'X1', family: 'f' }, items[3].series);
  await ST.putK({ id: 'x2', name: 'X2', family: 'f' }, items[4].series);
  const got = await ST.getK('x1');
  assert.equal(got.name, 'X1'); assert.equal(got.series.n, items[3].series.n);
  assert.equal((await ST.allK()).length, 2);
  const idx = await ST.kIndex();
  assert.equal(ST.isFresh(idx.x1, END + 3600000), true, 'last complete UTC day cached'); assert.equal(ST.isFresh(idx.x1, END + DAY + 3600000), false, 'one more day completed since');
});
test('store: registry activate → rollback → builtin, history kept', async () => {
  const m1 = Object.assign({}, B.models.h14, { id: 'cand-1', source: 'trained', gatesPassed: true });
  const m2 = Object.assign({}, B.models.h14, { id: 'cand-2', source: 'trained', gatesPassed: true });
  await ST.addCandidate(m1); await ST.addCandidate(m2);
  await ST.activate(14, 'cand-1'); await ST.activate(14, 'cand-2');
  let reg = await ST.registry(); assert.equal(reg.active.h14, 'cand-2');
  reg = await ST.rollback(14); assert.equal(reg.active.h14, 'cand-1');
  reg = await ST.rollback(14); assert.equal(reg.active.h14, null, 'second rollback returns to builtin');
  await assert.rejects(() => ST.rollback(14));
  await ST.activate(14, 'cand-2');
  await assert.rejects(() => ST.removeCandidate('cand-2'), /正在使用/);
  reg = await ST.activate(14, null, '恢复内置'); assert.equal(reg.active.h14, null);
  assert.ok(reg.history.length >= 4);
  await assert.rejects(() => ST.activate(7, 'nope'), /找不到/);
});
test('store: candidate list is capped without evicting active models', async () => {
  await ST.activate(14, 'cand-1');
  for (let k = 0; k < 15; k++) await ST.addCandidate(Object.assign({}, B.models.h7, { id: 'bulk-' + k, source: 'trained' }));
  const reg = await ST.registry();
  assert.ok(reg.candidates.length <= 12); assert.ok(reg.candidates.some(m => m.id === 'cand-1'));
});
test('store: export/import round-trip and validation', async () => {
  const dump = await ST.exportAll({ includeK: true });
  assert.equal(dump.app, 'market-lens-lab'); assert.ok(dump.k['k:x1']);
  await assert.rejects(() => ST.importAll({ app: 'other' }));
  await assert.rejects(() => ST.importAll({ app: 'market-lens-lab', registry: { candidates: [{ id: 'bad', features: [{ key: 'a', w: 'x' }] }] } }), /模型结构无效/);
  await ST.resetAll();
  assert.equal((await ST.allK()).length, 0);
  await ST.importAll(dump);
  assert.equal((await ST.allK()).length, 2);
  assert.equal((await ST.registry()).active.h14, 'cand-1');
});
test('store: snapshots dedupe per day/h/model; settings merge with defaults', async () => {
  await ST.addSnapshot({ day: '2026-09-24', h: 14, modelId: 'm', items: [['a', 1, 1]] });
  await ST.addSnapshot({ day: '2026-09-24', h: 14, modelId: 'm', items: [['a', 2, 1]] });
  const s = await ST.snapshots(); assert.equal(s.length, 1); assert.equal(s[0].items[0][1], 2);
  const cfg = await ST.saveSettings({ fee: 0.025 }); assert.equal(cfg.fee, 0.025); assert.equal(cfg.h, 30);
});

test('store: concurrent read-modify-write calls do not lose updates (race regression)', async () => {
  await Promise.all([7, 14, 30].map(h => ST.addSnapshot({ day: '2026-09-20', h, modelId: 'c', items: [] })));
  assert.equal((await ST.snapshots()).filter(x => x.day === '2026-09-20').length, 3);
  await Promise.all([1, 2, 3, 4].map(k => ST.addView({ day: '2026-09-20', id: 'v' + k, h: 14 })));
  assert.equal((await ST.views()).filter(v => v.day === '2026-09-20').length, 4);
  await Promise.all([1, 2, 3].map(k => ST.addCandidate(Object.assign({}, B.models.h30, { id: 'race-' + k, source: 'trained' }))));
  const ids = (await ST.registry()).candidates.map(m => m.id);
  for (const k of [1, 2, 3]) assert.ok(ids.includes('race-' + k));
});

(async () => {
  for (const [name, fn] of pending) {
    try { await fn(); passed++; console.log('PASS', name); }
    catch (e) { console.error('FAIL', name, '\n ', e.message); process.exitCode = 1; }
  }
  console.log(`${passed}/${pending.length} tests passed`);
})();
